# OpenClaw Control UI — Design System

OpenClaw is an open-source AI assistant that runs on your own hardware and meets you in the chat channels you already use (WhatsApp, Telegram, Slack, Discord, iMessage…). The **Gateway** is the local control plane; the **Control UI** is its web dashboard (`openclaw dashboard`): a dark-first, glass-surface app built in Lit + plain CSS with a deep charcoal base, a signature coral-red accent and Instrument Sans type. Stewarded by the OpenClaw Foundation; the mascot is Molty, a space lobster 🦞 (the one place emoji is genuinely part of the brand).

This system recreates the **claw family, dark mode** of the Control UI. Light mode and the knot/dash theme families exist in source (`ui/src/styles/base.css`) but are out of scope here.

## Sources

- Codebase: attached local folder `openclaw/` (GitHub: https://github.com/openclaw/openclaw). Control UI lives in `openclaw/ui/`.
  - Tokens: `ui/src/styles/base.css` · Shell/sidebar: `ui/src/styles/layout.css`, `ui/src/components/app-sidebar-render.ts` · Primitives: `ui/src/styles/components.css`, `settings.css`, `settings-controls.css`, `hub-tabs.css`, `rail-header.css` · Chat: `ui/src/styles/chat/*.css` · Sessions: `ui/src/pages/sessions/view.ts`, `sessions.css` · Plugins: `ui/src/pages/plugins/*`, `plugins.css`.
  - The repo's own design docs: `ui/docs/design-system/{README,color-tokens,glass-surfaces,motion,accessibility,settings-design}.md` — this system follows them.
  - Icons: `ui/src/components/icons.ts` + `icons-tools.ts` · Fonts: `ui/public/fonts/` · Brand mark: `ui/public/favicon.svg`.
- Docs: https://docs.openclaw.ai · Website: https://openclaw.ai

## Content fundamentals

- **Voice:** direct, operator-grade, sentence case everywhere ("New conversation", "Setup required", "Delete selected"). Second person ("your assistant", "your devices"); the assistant is "it"/its name (Molty). No exclamation marks in UI chrome.
- **Section headings are eyebrows:** short uppercase labels (INSTALLED, RECENT, NOTIFICATIONS) — grouping by whitespace + typography, never card headers.
- **Descriptions are one line, muted, factual:** "Show a notification when a run finishes." Row titles are nouns; buttons are verbs ("Refresh", "Install", "Retry").
- **Status is text, not pills:** `● Live`, `● Queued`, `● Setup required`. Badges exist only for genuine counts.
- **Technical strings stay mono and literal:** session keys (`agent:main:direct:whatsapp:+43…`), commands (`openclaw gateway status`), versions (`v2026.9.1`), token counts (`38k`).
- **Emoji:** only the lobster 🦞 as the agent avatar fallback and in README/marketing. Never decorative emoji in chrome.
- **Copy examples from source:** "Your assistant, on your devices, in your chats." · "Yours, with no catch." · "Treat inbound messages as untrusted input." · "Learn more ↗".

## Visual foundations

- **Color:** deep charcoal base `--bg #0e1015` → `--bg-accent` → `--card #161920` → `--bg-elevated #191c24` → `--bg-hover #1f2330` (five-step depth scale). Text `#bcbcc0` (~10:1), strong `#f4f4f5`, muted `#8b8b94`. Accent coral `--accent #ff5c5c` for text/indicators/rings; **filled buttons use `--primary #d13c3c`** with white text (AA). Teal `--accent-2 #14b8a6` for direct-session tint and secondary status. Semantic ok/warn/danger/info each pair with a 8% `-subtle` tint they must stay legible on.
- **Surfaces / glass:** two tiers. Tier 1 nav chrome: `color-mix(bg 82%) + backdrop-filter blur(12px) saturate(1.6)`. Tier 2 cards/composer/popovers: `--card` or `--popover` + 1px `--border`. Rule: no fully opaque fill above other content; never nest glass >2 levels. Exactly one level of elevation in settings — a group never contains another card.
- **Type:** Instrument Sans (self-hosted, 400–700) for everything incl. display; JetBrains Mono for keys/code/values. Body 14/1.55, letter-spacing −0.01em, antialiased. Scale xs 11 · sm 12 · md 14 · lg 16; page title 26/600 −0.02em; stat 24/700 −0.03em; nav/button 13/500; eyebrow 11/600 +0.06em uppercase.
- **Spacing:** `--space-1..8` = 4 8 12 16 20 24 32 40. Settings rows pad 12/16 min-h 48; sidebar pad 10; content pad 16/20; sections 40 apart; chat turn gap 28; composer side inset 36.
- **Radii:** sm 6 (menu items, small chips) · md 10 (buttons, inputs, nav items, bubbles) · lg 14 (cards, groups, tables) · xl 20 (composer, option cards) · full (pills, avatars, dots, send). Where the engine supports `corner-shape: superellipse(1.5)`, large surfaces scale radius ×1.25 — pills/circles opt out.
- **Borders:** whisper-thin 1px `--border #1e2028`; hover `--border-strong`; active accent at 16% mix. Row dividers are `--border` at 60%.
- **Shadows:** subtle black layers (sm 0 1 2 .25 → xl 0 24 48 .5); `--shadow-glow` = accent glow. Composer is deliberately lighter than sm (0 4 16 5%). Overlays: `--overlay-shadow` + 64% border-strong.
- **Hover:** background wash, never scale — `bg-hover` at 84% for nav/icons, 78% for session rows, text-strong 7–8% inside the composer; borders step to `--border-strong`. Chips lift 1px; catalog cards lift 1px + shadow-sm.
- **Press:** `--secondary` fill on buttons, 96% bg-hover on chrome. No shrink.
- **Selection:** active nav = accent-subtle wash + accent icon + faint accent border; active session = neutral `--text` 10% fill (not an accent outline); multi-select = accent 14%.
- **Focus:** `--focus-ring` = 2px bg gap + 3px ring at 80%; inset rings inside clipped groups.
- **Motion:** fast 100ms (hover, focus), normal 180ms (menus, tabs), slow 300ms (sheets, modals). `--ease-out` cubic-bezier(.16,1,.3,1) default; `--ease-in-out` for travel; `--ease-spring` for pops. Shimmer (1.5s) on skeletons, text-shimmer (2.2s) on running tool verbs. Everything gated by prefers-reduced-motion. Settings surfaces: color transitions only, no enter animations.
- **Layout:** fixed 258px sidebar grid column + fluid content; settings column 760px (1120 wide); chat thread max 48rem; catalog 4-col grid; tables min 760. Desktop has no topbar — the sidebar owns navigation; pane headers are 48px with 28px bare-glyph actions on a shared 24px centerline.
- **Imagery:** none in chrome. Marketing uses dark webp app-art (`assets/imagery`). Provider logos sit on white chips so brands never follow the theme.
- **Transparency/blur:** only in glass chrome and popovers (8–14px blur); >16px only in modal backdrops.

## Iconography

- **System:** Lucide-style stroke icons, inlined as SVG (24 viewBox, `stroke: currentColor`, round caps/joins). Default stroke 2; 1.5 inside .btn/.nav-item/composer; 1.7 in sidebar chrome. Sizes: 16 in chrome, 14 in tables/tool rows, 18 in bordered icon buttons, 21 for send.
- **Where:** all 160 glyphs extracted verbatim to `assets/icons/icons.json` and `assets/icons/icons.js` (`ocIconSvg(name)`); React `Icon` component wraps them. Source copies in `assets/icons/source/`.
- **Provider icons:** 80 brand SVGs in `ui/public/provider-icons` (4 samples copied to `assets/provider-icons`, see ATTRIBUTION.md). Rendered on a white `--brand-logo-chip-bg` tile.
- **No icon font, no PNG icons.** Unicode used sparingly as separators ("·", "/"). Emoji only as the lobster avatar.
- **Brand mark:** `assets/brand/favicon.svg` (lobster mark) — copied, not redrawn. Wordmark is the word "OpenClaw" in Instrument Sans 600.

## Index

- `styles.css` → `tokens/{fonts,colors,typography,spacing,motion,base}.css`
- `guidelines/` — 19 foundation cards (Colors, Type, Spacing, Brand)
- `components/core/` — Icon, Button, IconButton, Input, Select, Toggle, Segmented, Chip, StatusDot, Card, Callout, Skeleton, Toast
- `components/settings/` — SettingsSection, SettingsRow (+SettingsToggleRow), PageHeader
- `components/navigation/` — NavItem, SessionRow, SectionHeader, RailHeader, HubTabs, DataTable (+PaginationButton)
- `components/chat/` — Composer (+ComposerChip, SendButton), Message, ToolRow, ChatDivider, PluginCard
- `components/_preview-loader.js` — preview-only in-browser JSX loader used by cards/kits until the bundle is compiled
- `ui_kits/control-ui/` — Chat (`index.html`), Sessions, Plugins screens + Shell
- `assets/` — fonts, brand mark, icons, provider icons, imagery
- `SKILL.md` — agent skill entry point

### Intentional additions
- `Icon` — wrapper over the source's inline icon set (source uses Lit templates).
- `DataTable` / `PaginationButton` — the source table is markup + CSS (`.data-table`), wrapped here as a component for reuse.

### Component inventory vs. source
Source families recreated: .btn (+primary/danger/ghost/active/sm/xs), .btn--icon / .sidebar-brand__icon / .rail-header__action, .input / .settings-input / .data-table-search, .settings-select, wa-switch (settings-toggle), .settings-segmented (+accent/primary/compact), .chip/.pill/.plugin-catalog-chip/.control-ui-environment-pill/.hub-tab__badge, .statusDot/.settings-status, .card/.stat/.settings-group, .callout, .skeleton, .app-toast, settings section/row/nav-row/toggle-row, .content-header/.page-title, .nav-item, .sidebar-recent-session, sidebar section header, .rail-header, .hub-tabs, .data-table, .agent-chat__input composer (+chips, send/stop), .chat-group/.chat-bubble, tool rows, .chat-divider, .plugin-catalog-card.
Not yet recreated: command palette, confirm/input dialogs, dropdown menus (Web Awesome), exec-approval card, login gate, tooltips, capacity meter, agent avatar/facepile, question card, attachments, code block, markdown table.
