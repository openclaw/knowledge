import React, { useState } from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { Button } from "../../components/core/Button.jsx";
import { IconButton } from "../../components/core/IconButton.jsx";
import { Chip } from "../../components/core/Chip.jsx";
import { Segmented } from "../../components/core/Segmented.jsx";
import { StatusDot } from "../../components/core/StatusDot.jsx";
import { PageHeader } from "../../components/settings/PageHeader.jsx";
import { HubTabs } from "../../components/navigation/HubTabs.jsx";
import { DataTable, PaginationButton } from "../../components/navigation/DataTable.jsx";
/* Knowledge v4 — adapts v3 to engineering's DESIGN_HANDOFF.md / FEEDBACK_IMPLEMENTATION.md.
   - Origins: source · user_belief (attributed speaker, never "you") · agent_inference (premise evidence shown).
   - Recent: source groups (explicit source_page), not ingests. Lifecycle changes sit in their own block; no old bodies in the feed.
   - Identity {status, context, candidates}; attribution_confidence {level, basis}; continuity {reaffirms|updates|contradicts}.
   - Commitments: owner or "Owner not identified"; "No deadline recorded". Nothing reads as task status.
   - Event time (occurred) is separate from save time; explicit PDT/UTC; date-only stays date-only.
   - Evidence: files vs citations, excerpts labelled, verification failure/unavailable states.
   - Chat hand-off = read-only copyable request (ID/revision/hash) → Open chat. Nothing is sent.
   All data below is an isolated synthetic fixture shaped like the live meeting-import vault. */
const T = {
  person: ["circleUser", "Person", "People", "var(--accent-2)", "var(--accent-2-subtle)"],
  company: ["box", "Company", "Companies", "var(--info)", "var(--info-subtle)"],
  project: ["kanban", "Project", "Projects", "var(--ok)", "var(--ok-subtle)"],
  meeting: ["users", "Meeting", "Meetings", "var(--accent)", "var(--accent-subtle)"],
  event: ["calendarClock", "Event", "Events", "var(--warn)", "var(--warn-subtle)"],
  note: ["fileText", "Note", "Notes", "var(--muted-strong)", "var(--bg-hover)"],
};
const FACET_GROUPS = [["People & things", ["person", "company"]], ["Ideas & projects", ["project", "note"]], ["Events & conversations", ["meeting", "event"]]];
const KIND = { decision: ["flag", "Decision", "Decisions"], commitment: ["listChecks", "Commitment", "Commitments"], event: ["calendarClock", "Event", "Events"], belief: ["brain", "Belief", "Beliefs"], fact: ["info", "Fact", "Facts"], preference: ["star", "Preference", "Preferences"] };
const F = {
  tx23: { name: "standup-2026-09-23.transcript.txt", role: "Derived transcript", size: "146 KB", ok: true },
  raw23: { name: "standup-2026-09-23.json", role: "Original export", size: "212 KB", ok: true },
  tx22: { name: "partner-sync-2026-09-22.transcript.txt", role: "Derived transcript", size: "58 KB", ok: true },
  tx21: { name: "all-hands-2026-09-21.transcript.txt", role: "Derived transcript", size: "131 KB", ok: true },
  gone: { name: "rotation-2026-09-20.transcript.txt", role: "Derived transcript", ok: false, fail: "File not found in the vault. The citation is kept; the excerpt can’t be shown." },
};
const E = {
  priya: { type: "person", title: "Priya Raman", identity: { status: "resolved" }, body: "Maintainer focused on release reliability and reviewing community decision-model PRs. Leads the Gateway release reliability work.", updated: "Sep 23, 5:37 PM PDT", rev: 3 },
  tomas: { type: "person", title: "Tomás Vidal", identity: { status: "resolved" }, body: "Maintainer. At the Sep 23 standup he took on combining the CI and developer-experience work into one plan.", updated: "Sep 23, 5:37 PM PDT", rev: 1 },
  kestrel: { type: "person", title: "kestrel", identity: { status: "partial", context: "Community contributor", candidates: [{ id: "kobi", basis: "Same handle is recorded as the GitHub login on Kestrel Obi’s page; both describe the plugin test harness.", cit: { f: "tx23", l: "118–121", x: "kestrel, you’re up — the harness thing? — Yeah, the test harness PR is split in two now.", sp: { label: "Speaker 7", who: "kestrel", conf: "medium", basis: "Host roll call names the handle; reply follows." } } }] }, body: "Gave an update on the plugin test harness at the Sep 23 standup. Known by this handle.", updated: "Sep 23, 5:37 PM PDT", rev: 1 },
  kobi: { type: "person", title: "Kestrel Obi", identity: { status: "resolved" }, body: "Contributor who presented the plugin test-harness proposal at the Sep 21 all hands.", updated: "Sep 22, 4:10 PM PDT", rev: 1 },
  dana: { type: "person", title: "Dana (Hexline participant)", identity: { status: "partial", context: "Hexline participant", surnameUnresolved: true }, body: "Spoke for Hexline about connector timing at the Sep 22 partner sync.", updated: "Sep 23, 5:36 PM PDT", rev: 1 },
  marcus: { type: "person", title: "Marcus Hale", identity: { status: "resolved" }, body: "Maintainer who runs the contributor-support rotation.", updated: "Sep 22, 4:10 PM PDT", rev: 2 },
  jo: { type: "person", title: "Jo Park", identity: { status: "resolved" }, body: "Listed on the Sep 23 standup roster.", updated: "Sep 23, 5:37 PM PDT", rev: 1 },
  lin: { type: "person", title: "Lin Qiao", identity: { status: "resolved" }, body: "Maintainer. Earlier linked to the Hexline partner sync; that link was withdrawn.", updated: "Sep 23, 5:50 PM PDT", rev: 2 },
  hexline: { type: "company", title: "Hexline", identity: { status: "resolved" }, body: "Partner building a gateway connector. What’s known comes from one partner sync.", updated: "Sep 23, 5:36 PM PDT", rev: 1 },
  relrel: { type: "project", title: "Gateway release reliability", identity: { status: "resolved" }, body: "Work to make gateway releases safer to upgrade, including a freeze before 2026.10 and a documented downgrade path.", updated: "Sep 23, 11:20 AM PDT", rev: 4 },
  decmodels: { type: "project", title: "Decision model integration", identity: { status: "resolved" }, body: "Optional decision-model support that plugins can call. Community PRs are reviewed against Labs conventions.", updated: "Sep 22, 4:10 PM PDT", rev: 1 },
  standup23: { type: "meeting", title: "Daily Maintainers Standup — 2026-09-23", occurred: "Wed, Sep 23, 2026 · 9:00–9:32 AM PDT", files: ["tx23", "raw23"], body: "Round-robin standup. Tomás took on a combined CI plan, Priya on PR review; the freeze date was set; nobody took the downgrade write-up.", updated: "Sep 23, 5:37 PM PDT", rev: 2, event: "ev23" },
  partner22: { type: "meeting", title: "Hexline partner sync — 2026-09-22", occurred: "Tue, Sep 22, 2026 · 6:30–7:08 PM PDT", utc: "Stored as 2026-09-23 01:30–02:08 UTC", files: ["tx22"], body: "Evening call with Hexline about connector timing relative to the release freeze.", updated: "Sep 23, 5:36 PM PDT", rev: 2 },
  allhands21: { type: "meeting", title: "Maintainer All Hands — 2026-09-21", occurred: "Mon, Sep 21, 2026 · 11:00–11:45 AM PDT", files: ["tx21"], body: "Weekly all hands. Decision models stay optional; the test-harness proposal was presented.", updated: "Sep 22, 4:10 PM PDT", rev: 2 },
  freeze: { type: "event", title: "Release freeze", occurred: "Thu, Oct 1, 2026", dateOnly: true, body: "Code freeze ahead of the 2026.10 gateway release. Only a date was recorded, no time.", updated: "Sep 23, 5:52 PM PDT", rev: 2 },
};
const sp = (label, who, conf, basis) => ({ label, who, conf, basis });
const C = [
  { id: "ci", kind: "commitment", text: "Develop the coordinated CI and developer-experience plan — 2026-09-23", origin: "source", owner: "tomas", about: ["relrel"], src: "standup23", saved: "Sep 23, 5:37 PM PDT", rev: 1,
    cits: [{ f: "tx23", l: "40–52", x: "I’ll pull the CI and dev-experience pieces into one plan so we stop doing it in three places.", sp: sp("Speaker 3", "Tomás Vidal", "medium", "Host calls on Tomás immediately before; roster matches.") }] },
  { id: "down", kind: "commitment", text: "Write up a post-upgrade downgrade path — 2026-09-23", origin: "source", owner: null, about: ["relrel"], src: "standup23", saved: "Sep 23, 5:37 PM PDT", rev: 1,
    cits: [{ f: "tx23", l: "88–97", x: "Someone should write down what a downgrade even looks like before we promise one.", sp: sp("Speaker 5", null, null, null) }] },
  { id: "prs", kind: "commitment", text: "Review community decision-model PRs against Labs conventions — 2026-09-23", origin: "source", owner: "priya", about: ["decmodels"], src: "standup23", saved: "Sep 23, 5:37 PM PDT", rev: 1,
    cits: [{ f: "tx23", l: "60–64", x: "I’ll keep going through the decision-model PRs, checking them against the Labs rules…", sp: sp("Priya Raman", "Priya Raman", "high", "Full-name transcript label and direct roll call.") }, { f: "tx23", l: "71–73", x: "…same as last week, anything touching core goes behind the Labs flag.", truncated: true, sp: sp("Priya Raman", "Priya Raman", "high", "Full-name transcript label.") }],
    continuity: [{ id: "prs21", rel: "reaffirms", basis: "Restates the Sep 21 commitment; scope unchanged." }] },
  { id: "prs21", kind: "commitment", text: "Review decision-model community PRs — 2026-09-21", origin: "source", owner: "priya", about: ["decmodels"], src: "allhands21", saved: "Sep 22, 4:10 PM PDT", rev: 1,
    cits: [{ f: "tx21", l: "202–210", x: "I can take the decision-model PRs this week.", sp: sp("Priya Raman", "Priya Raman", "high", "Full-name transcript label.") }] },
  { id: "optional", kind: "decision", text: "Keep initial decision-model functionality optional — 2026-09-21", origin: "source", owner: null, about: ["decmodels"], src: "allhands21", saved: "Sep 22, 4:10 PM PDT", rev: 1,
    cits: [{ f: "tx21", l: "65–84", x: "Nothing in core should need a decision model to work. It’s opt-in.", sp: sp("Speaker 1", "Marcus Hale", "medium", "Owner’s local microphone; host role.") }] },
  { id: "conn22", kind: "belief", text: "Hexline expects to ship the connector before the freeze — 2026-09-22", origin: "source", about: ["hexline", "freeze"], src: "partner22", saved: "Sep 23, 5:36 PM PDT", rev: 1,
    cits: [{ f: "tx22", l: "33–38", x: "We should have the connector out before your freeze, that’s the plan.", sp: sp("Dana", "Dana (Hexline participant)", "high", "Named transcript label; opens the call for Hexline.") }] },
  { id: "conn23", kind: "belief", text: "The Hexline connector is expected after the freeze — 2026-09-23", origin: "source", about: ["hexline", "freeze"], src: "standup23", saved: "Sep 23, 5:37 PM PDT", rev: 1,
    cits: [{ f: "tx23", l: "140–144", x: "Hexline’s connector is realistically landing after the freeze.", sp: sp("Priya Raman", "Priya Raman", "medium", "Transcript label; content matches prior partner call.") }],
    continuity: [{ id: "conn22", rel: "contradicts", basis: "Two accounts of connector timing from different meetings. Both are kept with their attribution." }] },
  { id: "freezeD", kind: "decision", text: "Start the release freeze on Oct 1 — 2026-09-23", origin: "source", about: ["freeze", "relrel"], src: "standup23", saved: "Sep 23, 5:52 PM PDT", rev: 2, supersedes: "freezeOld",
    cits: [{ f: "tx23", l: "130–131", x: "Freeze is October first. Not the thirtieth, the first.", sp: sp("Priya Raman", "Priya Raman", "high", "Full-name transcript label.") }] },
  { id: "freezeOld", kind: "decision", text: "Start the release freeze on Sep 30 — 2026-09-23", origin: "source", about: ["freeze", "relrel"], src: "standup23", saved: "Sep 23, 5:37 PM PDT", rev: 1, lifecycle: "superseded", replacedBy: "freezeD", at: "Sep 23, 5:52 PM PDT",
    reason: "Replaced after re-reading lines 130–131, which give Oct 1.", recorded: "correct: source lines 130-131 state 'October first'; prior value derived from line 126 ('thirtieth') which the speaker retracts.",
    cits: [{ f: "tx23", l: "126", x: "…so freeze on the thirtieth—", truncated: true, sp: sp("Priya Raman", "Priya Raman", "high", "Full-name transcript label.") }] },
  { id: "rot", kind: "commitment", text: "Publish the contributor-support rotation schedule — 2026-09-20", origin: "source", owner: "marcus", about: [], src: null, saved: "Sep 21, 9:14 AM PDT", rev: 1,
    cits: [{ f: "gone", l: "70–81", sp: sp("Speaker 2", null, null, null) }] },
  { id: "ev23", kind: "event", text: "Daily Maintainers Standup — 2026-09-23 (meeting event)", origin: "source", about: ["relrel", "decmodels", "hexline"], src: "standup23", sourceEvent: true, saved: "Sep 23, 5:37 PM PDT", rev: 1, cits: [{ f: "tx23", l: "1–10", x: "OK, let’s go round. Priya first.", sp: sp("Speaker 1", null, null, null) }] },
  { id: "ub", mixed: true, kind: "preference", text: "Priya prefers written async updates for release notes", origin: "user_belief", speaker: "Priya Raman", about: ["priya", "relrel"], src: null, saved: "Sep 23, 6:02 PM PDT", rev: 1,
    cits: [{ chat: true, x: "For release notes just write it up async, I don’t need a call.", sp: sp("Priya Raman", "Priya Raman", null, null) }] },
  { id: "inf", mixed: true, kind: "fact", text: "Hexline’s connector timing depends on the release freeze date", origin: "agent_inference", about: ["hexline", "freeze"], src: null, saved: "Sep 23, 6:02 PM PDT", rev: 1,
    reason: "Both meetings discuss the connector only relative to the freeze; neither says so directly.",
    cits: [{ f: "tx22", l: "33–38", x: "We should have the connector out before your freeze, that’s the plan.", sp: sp("Dana", "Dana (Hexline participant)", "high", "Named transcript label.") }, { f: "tx23", l: "140–144", x: "Hexline’s connector is realistically landing after the freeze.", sp: sp("Priya Raman", "Priya Raman", "medium", "Transcript label.") }] },
];
const CL = Object.fromEntries(C.map((c) => [c.id, c]));
const ATT = [
  ["priya", "standup23", "high", "Direct roll call; roster matches."], ["tomas", "standup23", "medium", "Host calls on Tomás; the update that follows matches his earlier work."],
  ["kestrel", "standup23", "medium", "Roll call names the handle only."], ["marcus", "standup23", "high", "Owner’s local microphone and host role."], ["jo", "standup23", null, null],
  ["dana", "partner22", "high", "Named transcript label; opens the call for Hexline."], ["priya", "partner22", "medium", "Addressed by name; roster lists Priya."],
  ["kobi", "allhands21", "high", "Full-name transcript label."], ["priya", "allhands21", "high", "Full-name transcript label."], ["marcus", "allhands21", "medium", "Host role; roster matches."],
].map(([who, mtg, conf, basis]) => ({ who, mtg, conf, basis }));
const LEADS = [{ from: "priya", to: "relrel", label: "leads", conf: "medium", basis: "Described as owning the release reliability work." }];
const HIST = { rLin: { kind: "relationship", title: "Lin Qiao attended Hexline partner sync — 2026-09-22", from: "lin", to: "partner22", lifecycle: "withdrawn", at: "Sep 23, 5:50 PM PDT",
  reason: "Withdrawn: the recorder label belonged to Dana, and Lin wasn’t on the call.", recorded: "withdraw: speaker label 'Lin' at lines 12-14 re-attributed to Dana per roster + content; no remaining support for attendance.", rev: 2 } };
const FEED = [
  { day: "Today", date: "Wed, Sep 23", lifecycle: [{ type: "corrected", id: "freezeD", at: "5:52 PM PDT" }, { type: "withdrawn", id: "rLin", at: "5:50 PM PDT" }],
    groups: [
      { key: "u", mixed: true, label: "Saved in conversation", sub: "Conversation not recorded", at: "6:02 PM PDT", pages: [], claims: ["ub", "inf"] },
      { key: "s23", src: "standup23", at: "5:37 PM PDT", pages: [["standup23", "New"], ["freeze", "New"], ["kestrel", "New"], ["tomas", "New"], ["jo", "New"]], claims: ["ci", "down", "prs", "conn23", "freezeD"] },
      { key: "p22", src: "partner22", at: "5:36 PM PDT", pages: [["partner22", "New"], ["dana", "New"], ["hexline", "New"]], claims: ["conn22"] },
      { key: "x", label: "Edited outside OpenClaw", sub: "Change found in the vault files", at: "11:20 AM PDT", pages: [["relrel", "Updated"]], claims: [] },
    ] },
  { day: "Yesterday", date: "Tue, Sep 22", lifecycle: [],
    groups: [{ key: "a21", src: "allhands21", at: "4:10 PM PDT", pages: [["allhands21", "New"], ["kobi", "Observed"], ["decmodels", "New"]], claims: ["prs21", "optional"] }] },
];
const eyebrow = { margin: 0, display: "flex", alignItems: "center", gap: 8, fontSize: 11, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--muted-strong)" };
const surface = { background: "var(--card)", border: "1px solid color-mix(in srgb, var(--border) 85%, transparent)", borderRadius: "var(--radius-lg)", overflow: "hidden" };
const hair = "1px solid color-mix(in srgb, var(--border) 60%, transparent)";
const tint = "color-mix(in srgb, var(--bg-hover) 45%, transparent)";
const hov = { onMouseEnter: (ev) => ev.currentTarget.style.background = "color-mix(in srgb, var(--bg-hover) 60%, transparent)", onMouseLeave: (ev) => ev.currentTarget.style.background = "transparent" };
const mono = { fontFamily: "var(--mono)", fontSize: 11 };
const hashOf = (id) => { let h = 2166136261; for (const ch of id) h = Math.imul(h ^ ch.charCodeAt(0), 16777619); return "sha256:" + (h >>> 0).toString(16).padStart(8, "0") + "…"; };
const visibleClaims = (mixed) => C.filter((c) => !c.lifecycle && (mixed || !c.mixed));
const claimsAbout = (id, mixed) => visibleClaims(mixed).filter((c) => c.about.includes(id) && !c.sourceEvent);
const ownedBy = (id, mixed) => visibleClaims(mixed).filter((c) => c.owner === id);
const attOf = (mtg) => ATT.filter((a) => a.mtg === mtg);
const incomingContinuity = (id) => C.filter((x) => (x.continuity || []).some((k) => k.id === id)).map((x) => ({ id: x.id, rel: x.continuity.find((k) => k.id === id).rel, basis: x.continuity.find((k) => k.id === id).basis }));
const REL = { reaffirms: ["Reaffirms", "Reaffirmed by", "check"], updates: ["Updates", "Updated by", "arrowRight"], contradicts: ["Conflicts with", "Conflicts with", "arrowLeftRight"] };

function Tile({ type, size = 28, muted }) {
  const [ic, , , color, bg] = T[type] || T.note;
  return <span style={{ width: size, height: size, flex: "none", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: size > 32 ? "var(--radius-md)" : "var(--radius-sm)", color: muted ? "var(--muted)" : color, background: muted ? "var(--bg-hover)" : bg }}><Icon name={ic} size={Math.round(size / 2)} /></span>;
}
function Meta({ icon, children, color = "var(--muted)", strong }) {
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color, fontSize: 12, fontWeight: strong ? 500 : 400 }}>{icon ? <Icon name={icon} size={12} /> : null}{children}</span>;
}
function Origin({ c }) {
  if (c.origin === "user_belief") return <Meta icon="messageSquare" color="var(--accent-2)" strong>Statement by {c.speaker}</Meta>;
  if (c.origin === "agent_inference") return <Meta icon="spark" color="var(--warn)" strong>Molty inferred</Meta>;
  if (c.origin === "source") return <Meta icon="paperclip" strong>From source</Meta>;
  return <Meta icon="circleQuestionMark">Origin not recorded</Meta>;
}
function Conf({ level, basis, compact }) {
  if (!level) return <Meta icon="circleQuestionMark">{compact ? "Confidence not recorded" : "Attribution confidence not recorded"}</Meta>;
  return <span title={basis || ""} style={{ display: "inline-flex", alignItems: "center", gap: 5, color: "var(--muted-strong)", fontSize: 12 }}>
    <span style={{ display: "inline-flex", gap: 2 }}>{[0, 1, 2].map((i) => <span key={i} style={{ width: 4, height: 10, borderRadius: 1, background: i < { low: 1, medium: 2, high: 3 }[level] ? "var(--muted-strong)" : "color-mix(in srgb, var(--muted) 35%, transparent)" }} />)}</span>
    {compact ? { low: "Low", medium: "Medium", high: "High" }[level] : `${{ low: "Low", medium: "Medium", high: "High" }[level]} attribution confidence`}
  </span>;
}
function Tag({ children, tone = "neutral", icon }) {
  const c = tone === "warn" ? ["var(--warn)", "var(--warn-subtle)"] : tone === "info" ? ["var(--info)", "var(--info-subtle)"] : ["var(--muted-strong)", "var(--bg-hover)"];
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "1px 7px", borderRadius: 999, fontSize: 11, fontWeight: 500, color: c[0], background: c[1], whiteSpace: "nowrap" }}>{icon ? <Icon name={icon} size={11} /> : null}{children}</span>;
}
function Link({ id, onOpen }) {
  const [h, setH] = useState(false);
  return <button type="button" onClick={(e) => { e.stopPropagation(); onOpen(id); }} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ border: 0, padding: 0, background: "none", font: "inherit", color: h ? "var(--text-strong)" : "var(--text)", textDecoration: h ? "underline" : "none", textUnderlineOffset: 2, cursor: "pointer" }}>{E[id].title}</button>;
}
function IdentityTag({ e }) {
  if (!e.identity || e.identity.status !== "partial") return null;
  return <Tag icon="shieldQuestion">{e.identity.surnameUnresolved ? "Surname unresolved" : "Identity unresolved"}</Tag>;
}

/* One cited passage. Excerpts are labelled as excerpts; speaker attribution and file verification are separate facts. */
function Excerpt({ cit, premise }) {
  const f = cit.f && F[cit.f];
  if (f && !f.ok) return <div style={{ padding: "10px 12px", borderRadius: "var(--radius-md)", border: hair, display: "grid", gap: 4 }}>
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--warn)", fontSize: 13, fontWeight: 600 }}><Icon name="alertTriangle" size={13} />Source file unavailable</span>
    <span style={{ color: "var(--text)", fontSize: 13 }}>{f.fail}</span>
    <span style={{ ...mono, color: "var(--muted)" }}>{f.name} · lines {cit.l}</span>
  </div>;
  return <figure style={{ margin: 0, padding: "10px 12px", borderRadius: "var(--radius-md)", background: "var(--bg-accent, var(--bg-hover))", border: hair, display: "grid", gap: 6 }}>
    <span style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "2px 10px", color: "var(--muted)", fontSize: 11 }}>
      <span style={{ fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>{premise ? "Premise · excerpt" : cit.chat ? "Chat message" : "Excerpt"}</span>
      {f ? <span style={mono}>{f.name} · lines {cit.l}</span> : <span>Conversation not recorded</span>}
      {cit.truncated ? <span>Truncated</span> : null}
    </span>
    <blockquote style={{ margin: 0, color: "var(--text-strong)", fontSize: 13.5, lineHeight: 1.55 }}>“{cit.x}”</blockquote>
    <figcaption style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 12px", color: "var(--muted)", fontSize: 12 }}>
      <span>Speaker: {cit.sp.who ? (cit.sp.label !== cit.sp.who ? <>recorder label “{cit.sp.label}” → <span style={{ color: "var(--text)" }}>{cit.sp.who}</span></> : <span style={{ color: "var(--text)" }}>{cit.sp.who}</span>) : <>recorder label “{cit.sp.label}” · <span style={{ color: "var(--text)" }}>not identified</span></>}</span>
      {cit.sp.who || cit.sp.conf ? <Conf level={cit.sp.conf} basis={cit.sp.basis} /> : null}
      {f ? <Meta icon="badgeCheck" color="var(--ok)">File verified</Meta> : null}
    </figcaption>
  </figure>;
}
/* Citations grouped under their file. */
function EvidenceList({ c }) {
  const byFile = []; c.cits.forEach((ct) => { const k = ct.f || "chat"; let g = byFile.find((x) => x[0] === k); if (!g) byFile.push(g = [k, []]); g[1].push(ct); });
  const inf = c.origin === "agent_inference";
  return <div style={{ display: "grid", gap: 8 }}>
    {inf ? <div style={{ padding: "10px 12px", borderRadius: "var(--radius-md)", background: "var(--warn-subtle)", fontSize: 13, lineHeight: 1.5, color: "var(--text)" }}><strong style={{ color: "var(--warn)" }}>No direct quote for this inference.</strong> {c.reason} Premises below.</div> : null}
    {byFile.length > 1 || byFile[0][1].length > 1 ? <span style={{ color: "var(--muted)", fontSize: 12 }}>{c.cits.length} citations · {byFile.length} file{byFile.length > 1 ? "s" : ""}</span> : null}
    {byFile.map(([k, list]) => <div key={k} style={{ display: "grid", gap: 6 }}>{list.map((ct, i) => <Excerpt key={i} cit={ct} premise={inf} />)}</div>)}
  </div>;
}
function Continuity({ c, onOpenClaim }) {
  const items = [...(c.continuity || []).map((k) => ({ ...k, dir: 0 })), ...incomingContinuity(c.id).map((k) => ({ ...k, dir: 1 }))];
  if (!items.length) return null;
  return <div style={{ display: "grid", gap: 6 }}>
    <span style={{ ...eyebrow, fontSize: 10 }}>Related statements</span>
    {items.map((k) => { const o = CL[k.id], r = REL[k.rel]; return <div key={k.id} style={{ display: "grid", gridTemplateColumns: "16px minmax(0,1fr) auto", gap: 10, alignItems: "start", padding: "8px 10px", borderRadius: "var(--radius-md)", border: hair }}>
      <span style={{ color: "var(--muted-strong)", paddingTop: 2 }}><Icon name={r[2]} size={13} /></span>
      <span style={{ display: "grid", gap: 2, minWidth: 0 }}>
        <span style={{ fontSize: 12, color: "var(--muted-strong)", fontWeight: 600 }}>{r[k.dir]}</span>
        <span style={{ fontSize: 13, color: "var(--text-strong)" }}>{o.text}</span>
        <span style={{ fontSize: 12, color: "var(--muted)" }}>{k.basis} {E[o.src] ? `From ${E[o.src].title}.` : ""}</span>
      </span>
      <Button size="xs" variant="ghost" onClick={() => onOpenClaim(o.id)}>Open</Button>
    </div>; })}
  </div>;
}
function Details({ c, onOpen }) {
  const rows = [];
  if (c.kind === "commitment") {
    rows.push(["Owner", c.owner ? <Link id={c.owner} onOpen={onOpen} /> : <span style={{ color: "var(--muted-strong)" }}>Owner not identified</span>]);
    rows.push(["Deadline", <span style={{ color: "var(--muted-strong)" }}>No deadline recorded</span>]);
  }
  rows.push(["Source", c.src ? <Link id={c.src} onOpen={onOpen} /> : <span style={{ color: "var(--muted-strong)" }}>{c.origin === "user_belief" ? "Conversation not recorded" : "Source page not recorded"}</span>]);
  if (c.about.length) rows.push(["About", <span>{c.about.map((a, i) => <span key={a}>{i ? ", " : ""}<Link id={a} onOpen={onOpen} /></span>)}</span>]);
  rows.push(["Saved", <span>{c.saved} · revision {c.rev}</span>]);
  return <div style={{ display: "grid", gridTemplateColumns: "72px minmax(0,1fr)", gap: "4px 12px", fontSize: 13 }}>{rows.map(([k, v]) => <React.Fragment key={k}><span style={{ color: "var(--muted)", fontSize: 12, paddingTop: 1 }}>{k}</span><span style={{ color: "var(--text)" }}>{v}</span></React.Fragment>)}</div>;
}
function ClaimRow({ c, onOpen, onOpenClaim, onHandoff, first, showAbout = true, note }) {
  const [open, setOpen] = useState(false);
  const [ic, label] = KIND[c.kind];
  const cont = (c.continuity || []).length + incomingContinuity(c.id).length;
  const conflict = [...(c.continuity || []), ...incomingContinuity(c.id)].some((k) => k.rel === "contradicts");
  const missing = c.cits.some((ct) => ct.f && !F[ct.f].ok);
  return <div style={{ borderTop: first ? 0 : hair, background: open ? tint : "transparent" }}>
    <div role="button" tabIndex={0} onClick={() => setOpen(!open)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "start", padding: "11px 14px", cursor: "pointer" }}>
      <span title={label} style={{ width: 28, height: 28, display: "inline-flex", alignItems: "center", justifyContent: "center", color: "var(--muted-strong)" }}><Icon name={ic} size={15} /></span>
      <span style={{ display: "grid", gap: 4, minWidth: 0 }}>
        <span style={{ color: "var(--text-strong)", fontSize: 14, lineHeight: 1.45, textWrap: "pretty" }}>{c.text}</span>
        <span style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 10px", color: "var(--muted)", fontSize: 12 }}>
          {note ? <Meta icon="repeat" color="var(--info)" strong>{note}</Meta> : null}
          <span>{label}</span><Origin c={c} />
          {c.kind === "commitment" ? (c.owner ? <span>Owner <span style={{ color: "var(--text)" }}>{E[c.owner].title}</span></span> : <span>Owner not identified</span>) : null}
          {showAbout && c.about.length ? <span style={{ display: "inline-flex", gap: 4 }}>About {c.about.slice(0, 2).map((a, i) => <span key={a}>{i ? ", " : ""}<Link id={a} onOpen={onOpen} /></span>)}</span> : null}
          {cont ? <Meta icon={conflict ? "arrowLeftRight" : "link"} color="var(--muted-strong)">{conflict ? "Conflicting account" : "Reaffirmed"}</Meta> : null}
          {missing ? <Meta icon="alertTriangle" color="var(--warn)">Source file unavailable</Meta> : null}
        </span>
      </span>
      <span style={{ color: "var(--muted)", paddingTop: 6, transform: open ? "rotate(180deg)" : "none", transition: "transform .15s" }}><Icon name="chevronDown" size={14} /></span>
    </div>
    {open ? <div style={{ margin: "0 14px 14px 54px", display: "grid", gap: 12 }}>
      <Details c={c} onOpen={onOpen} />
      <EvidenceList c={c} />
      <Continuity c={c} onOpenClaim={onOpenClaim} />
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        <Button size="sm" icon="fileText" onClick={() => onOpenClaim(c.id)}>Open claim</Button>
        {c.cits.some((ct) => ct.f && F[ct.f].ok) ? <Button size="sm" variant="ghost" icon="download">Original file</Button> : null}
        <Button size="sm" variant="ghost" icon="pencil" onClick={() => onHandoff("correct", c)}>Correct in chat</Button>
      </div>
    </div> : null}
  </div>;
}
function SaveRow({ id, status, onOpen, first }) {
  const e = E[id];
  const st = { New: ["plus", "var(--accent)"], Updated: ["pencil", "var(--muted-strong)"], Observed: ["eye", "var(--muted-strong)"] }[status];
  return <div role="button" onClick={() => onOpen(id)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "9px 14px", borderTop: first ? 0 : hair, cursor: "pointer" }} {...hov}>
    <Tile type={e.type} />
    <span style={{ display: "grid", gap: 2, minWidth: 0 }}>
      <span style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}><span style={{ color: "var(--text-strong)", fontSize: 14, fontWeight: 500 }}>{e.title}</span><IdentityTag e={e} /></span>
      <span style={{ display: "flex", flexWrap: "wrap", gap: "2px 10px", color: "var(--muted)", fontSize: 12 }}>
        <Meta icon={st[0]} color={st[1]} strong>{status === "Observed" ? "Observed in vault" : status}</Meta><span>{T[e.type][1]}</span>
        {e.occurred ? <Meta icon="calendarClock">{e.dateOnly ? `${e.occurred} · date only` : e.occurred.split(" · ")[0]}</Meta> : null}
      </span>
    </span>
    <Icon name="chevronRight" size={14} />
  </div>;
}
function AttendanceRow({ mtg, onOpen, first }) {
  const [open, setOpen] = useState(false);
  const list = attOf(mtg);
  const names = list.map((a) => E[a.who].title);
  return <div style={{ borderTop: first ? 0 : hair, background: open ? tint : "transparent" }}>
    <div role="button" onClick={() => setOpen(!open)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "10px 14px", cursor: "pointer" }}>
      <span style={{ width: 28, display: "inline-flex", justifyContent: "center", color: "var(--muted-strong)" }}><Icon name="link" size={15} /></span>
      <span style={{ display: "grid", gap: 2, minWidth: 0 }}>
        <span style={{ color: "var(--text-strong)", fontSize: 14 }}>{names.slice(0, 3).join(", ")}{names.length > 3 ? ` and ${names.length - 3} more` : ""} attended</span>
        <span style={{ color: "var(--muted)", fontSize: 12 }}>{list.length} attendance connections · each with its own attribution</span>
      </span>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 12 }}>{open ? "Hide" : "Show all"}<Icon name={open ? "chevronUp" : "chevronDown"} size={14} /></span>
    </div>
    {open ? <div style={{ margin: "0 14px 12px 54px", ...surface }}>{list.map((a, i) => <div key={a.who} role="button" onClick={() => onOpen(a.who)} style={{ display: "grid", gridTemplateColumns: "20px minmax(0,1fr) auto", gap: 10, alignItems: "center", padding: "8px 12px", borderTop: i ? hair : 0, cursor: "pointer" }} {...hov}>
      <Tile type="person" size={20} />
      <span style={{ display: "grid", minWidth: 0 }}><span style={{ display: "flex", gap: 8, alignItems: "center" }}><span style={{ color: "var(--text-strong)", fontSize: 13, fontWeight: 500 }}>{E[a.who].title}</span><IdentityTag e={E[a.who]} /></span>{a.basis ? <span style={{ color: "var(--muted)", fontSize: 12 }}>{a.basis}</span> : null}</span>
      <Conf level={a.conf} basis={a.basis} compact />
    </div>)}</div> : null}
  </div>;
}
function SourceGroup({ g, onOpen, onOpenClaim, onHandoff, defaultOpen }) {
  const [open, setOpen] = useState(defaultOpen);
  const m = g.src && E[g.src];
  const claims = g.claims.map((k) => CL[k]);
  const att = g.src ? attOf(g.src) : [];
  const counts = [];
  if (att.length) counts.push(`${att.length} attended`);
  Object.keys(KIND).forEach((k) => { const n = claims.filter((c) => c.kind === k).length; if (n) counts.push(`${n} ${(n > 1 ? KIND[k][2] : KIND[k][1]).toLowerCase()}`); });
  const pagesN = g.pages.filter(([id]) => id !== g.src).length;
  if (pagesN) counts.push(`${pagesN} page${pagesN > 1 ? "s" : ""}`);
  const total = g.pages.length + claims.length + att.length + (m && m.event ? 1 : 0);
  return <div style={surface}>
    <div role="button" onClick={() => setOpen(!open)} style={{ display: "grid", gridTemplateColumns: "32px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "12px 14px", cursor: "pointer", borderBottom: open ? hair : 0 }}>
      {m ? <Tile type={m.type} size={32} /> : <span style={{ width: 32, height: 32, display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: "var(--radius-sm)", background: "var(--bg-hover)", color: "var(--muted-strong)" }}><Icon name={g.mixed ? "messageSquare" : "fileText"} size={16} /></span>}
      <span style={{ display: "grid", gap: 3, minWidth: 0 }}>
        <span style={{ color: "var(--text-strong)", fontSize: 14.5, fontWeight: 600 }}>{m ? m.title : g.label}</span>
        <span style={{ display: "flex", flexWrap: "wrap", gap: "2px 12px", color: "var(--muted)", fontSize: 12 }}>
          {m ? <Meta icon="calendarClock" color="var(--text)">Occurred {m.occurred.replace(/, 2026/, "")}</Meta> : <span>{g.sub}</span>}
          <span>Saved {g.at} · {total} record{total > 1 ? "s" : ""}</span>
        </span>
        {counts.length ? <span style={{ color: "var(--muted-strong)", fontSize: 12 }}>{counts.join(" · ")}{m && m.event ? " · meeting event" : ""}</span> : null}
      </span>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 12 }}>{open ? "Collapse" : "Expand"}<Icon name={open ? "chevronUp" : "chevronDown"} size={14} /></span>
    </div>
    {open ? <div>
      {g.pages.map(([id, st], i) => <SaveRow key={id} id={id} status={st} first={i === 0} onOpen={onOpen} />)}
      {att.length ? <AttendanceRow mtg={g.src} first={!g.pages.length} onOpen={onOpen} /> : null}
      {claims.map((c, i) => <ClaimRow key={c.id} c={c} first={!g.pages.length && !att.length && i === 0} note={c.supersedes ? "Corrected" : null} onOpen={onOpen} onOpenClaim={onOpenClaim} onHandoff={onHandoff} />)}
    </div> : null}
  </div>;
}
/* Lifecycle changes: title + explicit label; no old assertion body in the feed. Plain-language effect first, verbatim audit reason behind a second disclosure. */
function LifecycleRow({ ev, first, onOpen, onOpenClaim, onOpenHist }) {
  const [open, setOpen] = useState(false);
  const [raw, setRaw] = useState(false);
  const corr = ev.type === "corrected";
  const cur = corr ? CL[ev.id] : null, h = corr ? CL[cur.supersedes] : HIST[ev.id];
  return <div style={{ borderTop: first ? 0 : hair, background: open ? tint : "transparent" }}>
    <div role="button" onClick={() => setOpen(!open)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "start", padding: "11px 14px", cursor: "pointer" }}>
      <span style={{ width: 28, display: "inline-flex", justifyContent: "center", paddingTop: 2, color: corr ? "var(--info)" : "var(--muted)" }}><Icon name={corr ? "repeat" : "archive"} size={15} /></span>
      <span style={{ display: "grid", gap: 3, minWidth: 0 }}>
        <span style={{ color: "var(--text-strong)", fontSize: 14 }}>{corr ? cur.text : h.title}</span>
        <span style={{ display: "flex", flexWrap: "wrap", gap: "2px 10px", color: "var(--muted)", fontSize: 12 }}>
          <Meta icon={corr ? "repeat" : "archive"} color={corr ? "var(--info)" : "var(--muted-strong)"} strong>{corr ? "Corrected" : "Withdrawn"}</Meta>
          <span>{corr ? KIND[cur.kind][1] : "Connection"}</span><span>{ev.at}</span>
        </span>
      </span>
      <span style={{ color: "var(--muted)", paddingTop: 4, transform: open ? "rotate(180deg)" : "none" }}><Icon name="chevronDown" size={14} /></span>
    </div>
    {open ? <div style={{ margin: "0 14px 14px 54px", display: "grid", gap: 10 }}>
      <p style={{ margin: 0, fontSize: 13, lineHeight: 1.5, color: "var(--text)" }}>{corr ? `This replaced an earlier version. ${h.reason} Search and answers now use the current version.` : `${h.reason} It no longer appears in connections, search or answers. The original and its evidence are kept in history.`}</p>
      <button type="button" onClick={() => setRaw(!raw)} style={{ ...eyebrow, fontSize: 10, border: 0, padding: 0, background: "none", cursor: "pointer", justifySelf: "start" }}>Recorded reason <Icon name={raw ? "chevronUp" : "chevronDown"} size={11} /></button>
      {raw ? <code style={{ ...mono, color: "var(--muted-strong)", padding: "8px 10px", borderRadius: "var(--radius-sm)", border: hair, whiteSpace: "pre-wrap" }}>{h.recorded}</code> : null}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {corr ? <Button size="sm" icon="fileText" onClick={() => onOpenClaim(cur.id)}>Current version</Button> : <Button size="sm" icon="circleUser" onClick={() => onOpen(h.from)}>Open {E[h.from].title}</Button>}
        <Button size="sm" variant="ghost" icon="clock" onClick={() => corr ? onOpenClaim(h.id) : onOpenHist(ev.id)}>View in history</Button>
      </div>
    </div> : null}
  </div>;
}
function Search({ onOpen, onBrowse }) {
  const [q, setQ] = useState("");
  const [focus, setFocus] = useState(false);
  const s = q.trim().toLowerCase();
  const hits = s ? Object.entries(E).filter(([, e]) => e.title.toLowerCase() === s || e.title.toLowerCase().split(/[\s(]+/).includes(s)).slice(0, 5) : [];
  return <div style={{ position: "relative" }}>
    <label style={{ position: "relative", display: "block" }}>
      <span style={{ position: "absolute", top: "50%", left: 13, transform: "translateY(-50%)", color: "var(--muted)", display: "inline-flex", pointerEvents: "none" }}><Icon name="search" size={16} strokeWidth={1.7} /></span>
      <input value={q} onChange={(e) => setQ(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setTimeout(() => setFocus(false), 150)} placeholder="Find a person, project, or anything Molty saved…" aria-label="Search knowledge"
        style={{ width: "100%", boxSizing: "border-box", minHeight: 44, padding: "8px 12px 8px 38px", border: "1px solid var(--input)", borderRadius: "var(--radius-md)", background: "var(--card)", color: "var(--text)", fontSize: 14, fontFamily: "var(--font-body)", outline: "none" }} />
      <span style={{ position: "absolute", top: "50%", right: 12, transform: "translateY(-50%)", color: "var(--muted)", ...mono, border: "1px solid var(--border)", borderRadius: 4, padding: "1px 5px" }}>/</span>
    </label>
    {focus && s ? <div style={{ ...surface, position: "absolute", zIndex: 5, top: "calc(100% + 6px)", left: 0, right: 0, boxShadow: "var(--shadow-lg)", padding: 6 }}>
      <p style={{ ...eyebrow, padding: "6px 8px" }}>Exact matches</p>
      {hits.length ? hits.map(([id, e]) => <button key={id} type="button" onMouseDown={() => onOpen(id)} style={{ display: "flex", width: "100%", alignItems: "center", gap: 10, padding: 8, border: 0, borderRadius: "var(--radius-sm)", background: "transparent", color: "var(--text)", font: "inherit", textAlign: "left", cursor: "pointer" }} {...hov}>
        <Tile type={e.type} size={24} /><span style={{ color: "var(--text-strong)", fontWeight: 500 }}>{e.title}</span><span style={{ color: "var(--muted)", fontSize: 12 }}>{T[e.type][1]}</span>
      </button>) : <p style={{ margin: 0, padding: "4px 8px 8px", color: "var(--muted)", fontSize: 12 }}>No page is named exactly “{q}”.</p>}
      <button type="button" onMouseDown={() => onBrowse(q)} style={{ display: "flex", width: "100%", alignItems: "center", gap: 10, padding: 8, border: 0, borderTop: hair, background: "transparent", color: "var(--muted-strong)", font: "inherit", fontSize: 13, textAlign: "left", cursor: "pointer" }}>
        <Icon name="search" size={14} />Search all text for “{q}” · ranked<span style={{ marginLeft: "auto" }}><Icon name="cornerDownLeft" size={13} /></span>
      </button>
    </div> : null}
  </div>;
}
function Recent({ mixed, fresh, onShowFresh, ...p }) {
  return <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
    <Search onOpen={p.onOpen} onBrowse={p.onBrowse} />
    {fresh ? <button type="button" onClick={onShowFresh} style={{ alignSelf: "center", display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 14px", borderRadius: 999, border: "1px solid var(--border)", background: "var(--card)", color: "var(--text-strong)", font: "inherit", fontSize: 13, cursor: "pointer", boxShadow: "var(--shadow-md)" }}><Icon name="arrowUp" size={13} />1 new save · Show</button> : null}
    {FEED.map((d, di) => <section key={d.day} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <h3 style={{ ...eyebrow, color: "var(--muted)" }}>{d.day} <span style={{ fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>{d.date} · saved times in PDT</span></h3>
      {di === 0 && p.showFresh ? <div style={surface}><ClaimRow c={FRESH} first onOpen={p.onOpen} onOpenClaim={p.onOpenClaim} onHandoff={p.onHandoff} note="Just saved" /></div> : null}
      {d.lifecycle.length ? <div style={surface}>
        <div style={{ padding: "8px 14px", borderBottom: hair, color: "var(--muted-strong)", fontSize: 12, fontWeight: 600, background: "color-mix(in srgb, var(--bg-hover) 35%, transparent)" }}>Corrections & withdrawals · {d.lifecycle.length}</div>
        {d.lifecycle.map((ev, i) => <LifecycleRow key={ev.id} ev={ev} first={i === 0} {...p} />)}
      </div> : null}
      {d.groups.filter((g) => mixed || !g.mixed).map((g, gi) => <SourceGroup key={g.key} g={g} defaultOpen={di === 0 && g.src === "standup23"} {...p} />)}
    </section>)}
    <div style={{ display: "flex", justifyContent: "center" }}><Button size="sm" variant="ghost" icon="clock">Load older activity</Button></div>
  </div>;
}
const FRESH = { id: "fresh", kind: "commitment", text: "Share post-release internal feedback — 2026-09-23", origin: "source", owner: null, about: ["relrel"], src: "standup23", saved: "Sep 23, 6:04 PM PDT", rev: 1, cits: [{ f: "tx23", l: "150–152", x: "Let’s collect what broke internally after the release and share it.", sp: sp("Speaker 4", null, null, null) }] };

function Browse({ mixed, initialMode, initialQuery, ...p }) {
  const [mode, setMode] = useState(initialMode || "pages");
  const [hist, setHist] = useState("current");
  const [facet, setFacet] = useState("all");
  const [kind, setKind] = useState("all");
  const [q, setQ] = useState(initialQuery || "");
  const pages = Object.entries(E).filter(([, e]) => facet === "all" || e.type === facet).filter(([, e]) => !q || e.title.toLowerCase().includes(q.toLowerCase()));
  const counts = Object.fromEntries(Object.keys(T).map((t) => [t, Object.values(E).filter((e) => e.type === t).length]));
  const hidden = 14 + Object.values(counts).filter((n) => !n).length;
  const claimsAll = C.filter((c) => (hist === "all" || !c.lifecycle) && (mixed || !c.mixed));
  const kindCounts = Object.keys(KIND).map((k) => [k, claimsAll.filter((c) => c.kind === k).length]).filter(([, n]) => n);
  const origins = [...new Set(claimsAll.map((c) => c.origin))];
  const claims = claimsAll.filter((c) => (kind === "all" || c.kind === kind) && (!q || c.text.toLowerCase().includes(q.toLowerCase())));
  const rels = [...ATT.map((a) => ({ ...a, label: "attended", to: a.mtg, from: a.who })), ...LEADS, ...(hist === "all" ? [{ ...HIST.rLin, label: "attended", conf: null, basis: HIST.rLin.reason }] : [])];
  const fBtn = (id, label, n) => { const on = facet === id; return <button key={id} type="button" onClick={() => setFacet(id)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "6px 8px", border: 0, borderRadius: "var(--radius-sm)", background: on ? "var(--accent-subtle)" : "transparent", color: on ? "var(--text-strong)" : "var(--text)", font: "inherit", fontSize: 13, textAlign: "left", cursor: "pointer" }}>{T[id] ? <Tile type={id} size={20} /> : <span style={{ width: 20 }} />}<span>{label}</span><span style={{ marginLeft: "auto", color: "var(--muted)", ...mono, fontSize: 12 }}>{n}</span></button>; };
  return <div style={{ display: "grid", gridTemplateColumns: "210px minmax(0,1fr)", gap: 24, alignItems: "start" }}>
    <nav aria-label="Types" style={{ position: "sticky", top: 0, display: "grid", gap: 14 }}>
      {mode === "claims" ? <>
        <div style={{ display: "grid", gap: 2 }}>
          <p style={{ ...eyebrow, padding: "0 8px 4px", fontSize: 10 }}>Claim kinds</p>
          {[["all", "All claims", claimsAll.length], ...kindCounts.map(([k, n]) => [k, KIND[k][2], n])].map(([k, l, n]) => <button key={k} type="button" onClick={() => setKind(k)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "6px 8px", border: 0, borderRadius: "var(--radius-sm)", background: kind === k ? "var(--accent-subtle)" : "transparent", color: "var(--text)", font: "inherit", fontSize: 13, textAlign: "left", cursor: "pointer" }}><span style={{ width: 20, display: "inline-flex", justifyContent: "center", color: "var(--muted-strong)" }}>{k !== "all" ? <Icon name={KIND[k][0]} size={14} /> : null}</span>{l}<span style={{ marginLeft: "auto", color: "var(--muted)", ...mono, fontSize: 12 }}>{n}</span></button>)}
        </div>
        <p style={{ margin: "0 8px", color: "var(--muted)", fontSize: 12, lineHeight: 1.5 }}>{origins.length === 1 ? `All ${claimsAll.length} claims are from sources.` : `${origins.length} origins: ${claimsAll.filter((c) => c.origin === "source").length} from sources, ${claimsAll.filter((c) => c.origin === "user_belief").length} user statement, ${claimsAll.filter((c) => c.origin === "agent_inference").length} inferred.`} Kinds with no claims are hidden.</p>
      </> : <>
        <div>{fBtn("all", "Everything", Object.keys(E).length)}</div>
        {FACET_GROUPS.map(([g, ids]) => { const shown = ids.filter((t) => counts[t]); return shown.length ? <div key={g} style={{ display: "grid", gap: 2 }}><p style={{ ...eyebrow, padding: "0 8px 4px", fontSize: 10 }}>{g}</p>{shown.map((t) => fBtn(t, T[t][2], counts[t]))}</div> : null; })}
        <p style={{ margin: "0 8px", color: "var(--muted)", fontSize: 12 }}>{hidden} empty types hidden</p>
      </>}
    </nav>
    <div style={surface}>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, padding: "8px 12px", borderBottom: hair }}>
        <label style={{ position: "relative", flex: "1 1 200px" }}>
          <span style={{ position: "absolute", top: "50%", left: 10, transform: "translateY(-50%)", color: "var(--muted)", display: "inline-flex" }}><Icon name="search" size={14} /></span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={mode === "claims" ? "Filter claim text" : "Filter by name or alias"} style={{ width: "100%", boxSizing: "border-box", height: 34, padding: "0 10px 0 30px", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", background: "var(--bg)", color: "var(--text)", fontSize: 13, fontFamily: "var(--font-body)", outline: "none" }} />
        </label>
        <Segmented ariaLabel="Record kind" value={mode} onChange={setMode} options={[{ value: "pages", label: "Pages" }, { value: "claims", label: "Claims" }, { value: "connections", label: "Connections" }]} />
        <Segmented ariaLabel="Lifecycle" value={hist} onChange={setHist} options={[{ value: "current", label: "Current" }, { value: "all", label: "Include history" }]} />
      </div>
      {mode === "pages" ? <DataTable sort={{ column: "updated", dir: "desc" }}
        columns={[{ key: "name", label: "Name", sortable: true }, { key: "type", label: "Type", sortable: true }, { key: "occurred", label: "Occurred" }, { key: "updated", label: "Last updated", sortable: true }]}
        rows={pages.map(([id, e]) => ({ key: id, e, onClick: () => p.onOpen(id) }))} emptyMessage="Nothing matches these filters"
        renderRow={(r, td) => <>
          <td style={td}><span style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}><Tile type={r.e.type} size={24} /><span style={{ color: "var(--text-strong)", fontWeight: 500 }}>{r.e.title}</span><IdentityTag e={r.e} /></span></td>
          <td style={{ ...td, color: "var(--muted)" }}>{T[r.e.type][1]}</td>
          <td style={{ ...td, color: r.e.occurred ? "var(--text)" : "var(--muted)", whiteSpace: "nowrap", fontSize: 12 }}>{r.e.occurred ? (r.e.dateOnly ? `${r.e.occurred.replace(", 2026", "")} · date only` : r.e.occurred.replace(", 2026", "").split("–")[0] + " PDT") : "—"}</td>
          <td style={{ ...td, color: "var(--muted)", whiteSpace: "nowrap", fontSize: 12 }}>{r.e.updated.replace(" PDT", "")}</td>
        </>}
        pagination={<><span>1–{pages.length} of {pages.length}{hist === "all" ? " · including history" : ""} · complete list</span><div style={{ display: "flex", gap: 8 }}><PaginationButton disabled>Previous</PaginationButton><PaginationButton disabled>Next</PaginationButton></div></>} />
      : mode === "claims" ? <div>
        {claims.map((c, i) => c.lifecycle ? <div key={c.id} role="button" onClick={() => p.onOpenClaim(c.id)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, padding: "11px 14px", borderTop: i ? hair : 0, cursor: "pointer" }} {...hov}>
            <span style={{ display: "inline-flex", justifyContent: "center", color: "var(--muted)", paddingTop: 2 }}><Icon name={KIND[c.kind][0]} size={14} /></span>
            <span style={{ display: "grid", gap: 3 }}><span style={{ color: "var(--muted-strong)", fontSize: 14 }}>{c.text}</span><span style={{ display: "flex", gap: 10, fontSize: 12, color: "var(--muted)" }}><Meta icon="repeat" color="var(--muted-strong)" strong>Replaced</Meta><span>{c.at}</span></span></span>
            <Icon name="chevronRight" size={14} />
          </div> : <ClaimRow key={c.id} c={c} first={i === 0} {...p} />)}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderTop: hair, color: "var(--muted)", fontSize: 12 }}><span>1–{claims.length} of {claims.length} claims · complete list</span><div style={{ display: "flex", gap: 8 }}><PaginationButton disabled>Previous</PaginationButton><PaginationButton disabled>Next</PaginationButton></div></div>
      </div>
      : <div>
        {rels.map((r, i) => <div key={i} role="button" onClick={() => p.onOpen(r.from)} style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "10px 14px", borderTop: i ? hair : 0, cursor: "pointer" }} {...hov}>
          <span style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, fontSize: 13, color: r.lifecycle ? "var(--muted-strong)" : "var(--text)" }}>
            <Tile type={E[r.from].type} size={20} muted={!!r.lifecycle} /><span style={{ fontWeight: 500 }}>{E[r.from].title}</span><span style={{ color: "var(--muted)" }}>{r.label}</span><Tile type={E[r.to].type} size={20} muted={!!r.lifecycle} /><span style={{ fontWeight: 500 }}>{E[r.to].title}</span>
            {r.lifecycle ? <Meta icon="archive" color="var(--muted-strong)" strong>Withdrawn</Meta> : null}
          </span>
          {r.lifecycle ? <span style={{ color: "var(--muted)", fontSize: 12 }}>{r.at}</span> : <Conf level={r.conf} basis={r.basis} compact />}
        </div>)}
        <div style={{ padding: "10px 14px", borderTop: hair, color: "var(--muted)", fontSize: 12 }}>1–{rels.length} of {rels.length} connections · complete list</div>
      </div>}
    </div>
  </div>;
}

function Crumb({ label, onBack }) {
  return <nav style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 13 }}>
    <button type="button" onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 4, border: 0, padding: 0, background: "none", color: "var(--muted-strong)", font: "inherit", cursor: "pointer" }}><Icon name="arrowLeft" size={14} />Knowledge</button>
    <Icon name="chevronRight" size={12} /><span>{label}</span>
  </nav>;
}
function HistoryBanner({ life, at, reason, current, onOpenClaim }) {
  const w = life === "withdrawn";
  return <div style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "12px 14px", borderRadius: "var(--radius-md)", border: hair, background: w ? "var(--bg-hover)" : "var(--info-subtle)" }}>
    <span style={{ color: w ? "var(--muted-strong)" : "var(--info)", display: "inline-flex", paddingTop: 2 }}><Icon name="clock" size={16} /></span>
    <span style={{ flex: 1, display: "grid", gap: 3, fontSize: 13, lineHeight: 1.5 }}>
      <strong style={{ color: "var(--text-strong)" }}>Viewing history · {w ? "Withdrawn" : "Replaced"} {at}</strong>
      <span style={{ color: "var(--text)" }}>{w ? "Not used in search, connections or answers." : "An earlier version. Search and answers use the current one."} {reason}</span>
    </span>
    {current ? <Button size="sm" icon="arrowRight" onClick={() => onOpenClaim(current)}>Current version</Button> : null}
  </div>;
}
function ClaimPage({ id, onOpen, onOpenClaim, onHandoff, onBack }) {
  const c = CL[id] || FRESH;
  const [ic, label] = KIND[c.kind];
  const old = !!c.lifecycle;
  const versions = c.supersedes ? [c, CL[c.supersedes]] : c.replacedBy ? [CL[c.replacedBy], c] : null;
  return <div style={{ display: "flex", flexDirection: "column", gap: 20, maxWidth: 780 }}>
    <Crumb label={old ? "Claim history" : "Claims"} onBack={onBack} />
    {old ? <HistoryBanner life={c.lifecycle} at={c.at} reason={c.reason} current={c.replacedBy} onOpenClaim={onOpenClaim} /> : null}
    <header style={{ display: "grid", gap: 8 }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted-strong)", fontSize: 12, fontWeight: 600 }}><Icon name={ic} size={14} />{label}</span>
      <h1 style={{ margin: 0, color: old ? "var(--muted-strong)" : "var(--text-strong)", fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.3, textWrap: "pretty" }}>{c.text}</h1>
      <span style={{ display: "flex", flexWrap: "wrap", gap: "4px 12px" }}><Origin c={c} /></span>
    </header>
    <div style={{ ...surface, padding: 14 }}><Details c={c} onOpen={onOpen} /></div>
    <section style={{ display: "grid", gap: 8 }}><h2 style={eyebrow}>Evidence</h2><EvidenceList c={c} /></section>
    <Continuity c={c} onOpenClaim={onOpenClaim} />
    {versions ? <section style={{ display: "grid", gap: 8 }}>
      <h2 style={eyebrow}>Versions <span style={{ color: "var(--muted)", fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>{versions.length}</span></h2>
      <div style={surface}>{versions.map((v, i) => <div key={v.id} role="button" onClick={() => v.id !== c.id && onOpenClaim(v.id)} style={{ display: "grid", gridTemplateColumns: "56px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "10px 14px", borderTop: i ? hair : 0, cursor: v.id === c.id ? "default" : "pointer", background: v.id === c.id ? tint : "transparent" }}>
        <span style={{ ...mono, color: "var(--muted)" }}>rev {v.rev}</span>
        <span style={{ display: "grid", gap: 2 }}><span style={{ fontSize: 13, color: v.lifecycle ? "var(--muted-strong)" : "var(--text-strong)" }}>{v.text}</span><span style={{ fontSize: 12, color: "var(--muted)" }}>{v.lifecycle ? `Replaced ${v.at}` : `Current · saved ${v.saved}`}</span></span>
        {v.id === c.id ? <Tag>Viewing</Tag> : <Icon name="chevronRight" size={14} />}
      </div>)}</div>
    </section> : null}
    {!old ? <div style={{ display: "flex", gap: 8 }}><Button size="sm" variant="ghost" icon="pencil" onClick={() => onHandoff("correct", c)}>Correct in chat</Button></div> : null}
  </div>;
}
function HistPage({ id, onOpen, onBack }) {
  const h = HIST[id];
  return <div style={{ display: "flex", flexDirection: "column", gap: 20, maxWidth: 780 }}>
    <Crumb label="Connection history" onBack={onBack} />
    <HistoryBanner life={h.lifecycle} at={h.at} reason={h.reason} />
    <header style={{ display: "grid", gap: 8 }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted-strong)", fontSize: 12, fontWeight: 600 }}><Icon name="link" size={14} />Connection · attended</span>
      <h1 style={{ margin: 0, color: "var(--muted-strong)", fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em" }}>{h.title}</h1>
    </header>
    <div style={{ ...surface, padding: 14, display: "grid", gridTemplateColumns: "72px minmax(0,1fr)", gap: "4px 12px", fontSize: 13 }}>
      <span style={{ color: "var(--muted)", fontSize: 12 }}>From</span><span><Link id={h.from} onOpen={onOpen} /></span>
      <span style={{ color: "var(--muted)", fontSize: 12 }}>To</span><span><Link id={h.to} onOpen={onOpen} /></span>
      <span style={{ color: "var(--muted)", fontSize: 12 }}>Revision</span><span>{h.rev} · withdrawn</span>
    </div>
    <section style={{ display: "grid", gap: 8 }}><h2 style={eyebrow}>Recorded reason</h2><code style={{ ...mono, color: "var(--muted-strong)", padding: "10px 12px", borderRadius: "var(--radius-md)", border: hair, whiteSpace: "pre-wrap" }}>{h.recorded}</code></section>
  </div>;
}
function RailSection({ title, children }) { return <section style={{ display: "grid", gap: 8 }}><h2 style={eyebrow}>{title}</h2>{children}</section>; }
function Entity({ id, mixed, onOpen, onOpenClaim, onHandoff, onBack }) {
  const e = E[id];
  const [raw, setRaw] = useState(false);
  const about = claimsAbout(id, mixed), owned = ownedBy(id, mixed).filter((c) => !c.about.includes(id));
  const groups = Object.keys(KIND).map((k) => [k, about.filter((c) => c.kind === k)]).filter(([, l]) => l.length);
  const att = e.type === "meeting" ? attOf(id) : [];
  const attended = e.type === "person" ? ATT.filter((a) => a.who === id) : [];
  const leads = LEADS.filter((l) => l.from === id || l.to === id);
  const ev = e.event && CL[e.event];
  const idn = e.identity || {};
  const cits = e.files ? C.filter((c) => c.src === id).flatMap((c) => c.cits) : [];
  const meetingsKnown = [...new Set(attended.map((a) => a.mtg))];
  return <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
    <Crumb label={T[e.type][2]} onBack={onBack} />
    <header style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
      <Tile type={e.type} size={48} />
      <div style={{ flex: 1, minWidth: 0, display: "grid", gap: 7 }}>
        <h1 style={{ margin: 0, color: "var(--text-strong)", fontSize: 26, fontWeight: 650, letterSpacing: "-0.025em", lineHeight: 1.15 }}>{e.title}</h1>
        {e.occurred ? <span style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 12px", color: "var(--text-strong)", fontSize: 14, fontWeight: 500 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><Icon name="calendarClock" size={15} />{e.occurred}</span>
          {e.dateOnly ? <Tag>Date only · no time recorded</Tag> : null}
          {e.utc ? <span style={{ color: "var(--muted)", fontSize: 12, fontWeight: 400 }}>{e.utc}</span> : null}
        </span> : null}
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 12px", color: "var(--muted)", fontSize: 13 }}>
          <span>{T[e.type][1]}</span>
          <IdentityTag e={e} />
          {idn.context ? <span>Context <span style={{ color: "var(--text)" }}>{idn.context}</span></span> : null}
          {e.type === "person" && meetingsKnown.length ? <span>Known from {meetingsKnown.length} meeting{meetingsKnown.length > 1 ? "s" : ""}</span> : null}
        </div>
        {idn.context && e.type === "person" ? <span style={{ color: "var(--muted)", fontSize: 12 }}>“{idn.context}” is how the source describes them. It isn’t recorded as a role or employer.</span> : null}
      </div>
      <Button icon="messageSquare" onClick={() => onHandoff("ask", e, id)}>Ask Molty</Button>
    </header>
    {(idn.candidates || []).map((cd) => <div key={cd.id} style={{ ...surface, padding: 14, display: "grid", gap: 10 }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
        <span style={{ color: "var(--muted-strong)", paddingTop: 2 }}><Icon name="shieldQuestion" size={16} /></span>
        <span style={{ flex: 1, display: "grid", gap: 3 }}>
          <span style={{ color: "var(--text-strong)", fontSize: 14, fontWeight: 600 }}>Possible match: <Link id={cd.id} onOpen={onOpen} /></span>
          <span style={{ color: "var(--text)", fontSize: 13, lineHeight: 1.5 }}>{cd.basis}</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>Both records stay separate unless Molty finds evidence they’re the same person.</span>
        </span>
        <Button size="sm" onClick={() => onHandoff("identity", e, id, cd.id)}>Ask Molty to check</Button>
      </div>
      <div style={{ marginLeft: 28 }}><Excerpt cit={cd.cit} /></div>
    </div>)}
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 300px", gap: 28, alignItems: "start" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 24, minWidth: 0 }}>
        <section style={{ display: "grid", gap: 8 }}>
          <p style={{ margin: 0, color: "var(--text)", fontSize: 15, lineHeight: 1.65, textWrap: "pretty", maxWidth: "62ch" }}>{e.body}</p>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>Written by Molty · updated {e.updated} · revision {e.rev}</span>
        </section>
        {att.length ? <section style={{ display: "grid", gap: 10 }}>
          <h2 style={eyebrow}>Attended <span style={{ color: "var(--muted)", fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>{att.length} people · from attendance connections</span></h2>
          <div style={surface}>{att.map((a, i) => <div key={a.who} role="button" onClick={() => onOpen(a.who)} style={{ display: "grid", gridTemplateColumns: "24px minmax(0,1fr) auto", gap: 10, alignItems: "center", padding: "9px 14px", borderTop: i ? hair : 0, cursor: "pointer" }} {...hov}>
            <Tile type="person" size={24} /><span style={{ display: "grid", minWidth: 0 }}><span style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ color: "var(--text-strong)", fontSize: 13.5, fontWeight: 500 }}>{E[a.who].title}</span><IdentityTag e={E[a.who]} /></span><span style={{ color: "var(--muted)", fontSize: 12 }}>{a.basis || "No attribution basis recorded"}</span></span><Conf level={a.conf} basis={a.basis} compact />
          </div>)}</div>
          {ev ? <span style={{ color: "var(--muted)", fontSize: 12 }}>Also linked by the meeting event (not attendance): {ev.about.map((x, i) => <span key={x}>{i ? ", " : ""}<Link id={x} onOpen={onOpen} /></span>)}</span> : null}
        </section> : null}
        <section style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <h2 style={eyebrow}>What Molty knows <span style={{ color: "var(--muted)", fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>{about.length + (e.type === "meeting" ? C.filter((c) => c.src === id && !c.lifecycle && !c.sourceEvent && !c.about.includes(id)).length : 0)} claims</span></h2>
          {(() => { const list = e.type === "meeting" ? C.filter((c) => c.src === id && !c.lifecycle && !c.sourceEvent) : about; const gs = Object.keys(KIND).map((k) => [k, list.filter((c) => c.kind === k)]).filter(([, l]) => l.length);
            return gs.length ? <div style={surface}>{gs.map(([k, l], gi) => <div key={k}>
              <div style={{ padding: "8px 14px", borderTop: gi ? hair : 0, color: "var(--muted-strong)", fontSize: 12, fontWeight: 600, background: "color-mix(in srgb, var(--bg-hover) 35%, transparent)" }}>{KIND[k][2]} · {l.length}</div>
              {l.map((c) => <ClaimRow key={c.id} c={c} first={false} showAbout={e.type === "meeting" || c.about.length > 1} onOpen={onOpen} onOpenClaim={onOpenClaim} onHandoff={onHandoff} />)}
            </div>)}</div> : <p style={{ margin: 0, color: "var(--muted)", fontSize: 13 }}>No claims about {e.title}.{e.type === "person" && meetingsKnown.length ? " Only attendance is recorded." : ""}</p>; })()}
        </section>
        {owned.length ? <section style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <h2 style={eyebrow}>Commitments owned <span style={{ color: "var(--muted)", fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>{owned.length} · owner only, not about {e.title}</span></h2>
          <div style={surface}>{owned.map((c, i) => <ClaimRow key={c.id} c={c} first={i === 0} onOpen={onOpen} onOpenClaim={onOpenClaim} onHandoff={onHandoff} />)}</div>
        </section> : null}
      </div>
      <aside style={{ display: "flex", flexDirection: "column", gap: 20, position: "sticky", top: 0 }}>
        {attended.length || leads.length ? <RailSection title="Connections">
          <div style={surface}>{[...attended.map((a) => ({ rel: "Attended", to: a.mtg, conf: a.conf, basis: a.basis })), ...leads.map((l) => l.from === id ? { rel: "Leads", to: l.to, conf: l.conf, basis: l.basis } : { rel: "← leads", to: l.from, conf: l.conf, basis: l.basis })].map((l, i) => <div key={i} role="button" onClick={() => onOpen(l.to)} style={{ display: "grid", gridTemplateColumns: "24px minmax(0,1fr)", gap: 10, alignItems: "center", padding: "9px 12px", borderTop: i ? hair : 0, cursor: "pointer" }} {...hov}>
            <Tile type={E[l.to].type} size={24} /><span style={{ display: "grid", gap: 1, minWidth: 0 }}><span style={{ display: "flex", justifyContent: "space-between", gap: 8, color: "var(--muted)", fontSize: 11 }}>{l.rel}<Conf level={l.conf} basis={l.basis} compact /></span><span style={{ color: "var(--text-strong)", fontSize: 13, fontWeight: 500 }}>{E[l.to].title}</span></span>
          </div>)}</div>
        </RailSection> : null}
        {e.files ? <RailSection title="Sources">
          <div style={surface}>
            <div style={{ padding: "8px 12px", color: "var(--muted)", fontSize: 12, borderBottom: hair }}>{e.files.length} file{e.files.length > 1 ? "s" : ""} · {cits.length} citation{cits.length === 1 ? "" : "s"} from this meeting’s claims</div>
            {e.files.map((f, i) => { const n = cits.filter((c) => c.f === f).length; return <div key={f} style={{ display: "grid", gap: 3, padding: "9px 12px", borderTop: i ? hair : 0 }}>
              <span style={{ ...mono, color: "var(--text-strong)", overflowWrap: "anywhere" }}>{F[f].name}</span>
              <span style={{ display: "flex", flexWrap: "wrap", gap: "2px 10px", color: "var(--muted)", fontSize: 12 }}><span>{F[f].role} · {F[f].size}</span><span>{n ? `${n} cited passages` : "Not cited directly"}</span></span>
              <span style={{ display: "flex", gap: 8, alignItems: "center" }}><Meta icon="badgeCheck" color="var(--ok)">{F[f].role === "Original export" ? "Original retained" : "File verified"}</Meta><span style={{ marginLeft: "auto" }}><IconButton icon="download" label="Download" size={26} iconSize={13} /></span></span>
            </div>; })}
          </div>
        </RailSection> : null}
        <RailSection title="Learned in"><div style={{ ...surface, padding: "10px 12px", color: "var(--muted)", fontSize: 12.5, lineHeight: 1.5 }}>Conversation not recorded. Saved from meeting imports; the conversation that ran them isn’t tracked yet.</div></RailSection>
        <section style={{ display: "grid", gap: 8 }}>
          <button type="button" onClick={() => setRaw(!raw)} style={{ ...eyebrow, border: 0, padding: 0, background: "none", cursor: "pointer", font: "inherit", fontSize: 11 }}>File details <Icon name={raw ? "chevronUp" : "chevronDown"} size={12} /></button>
          {raw ? <div style={{ ...surface, padding: 12, display: "grid", gap: 6, fontSize: 12 }}>
            {[["ID", "pg_" + id], ["Revision", String(e.rev)], ["Hash", hashOf(id)], ["Updated", e.updated], ["Lifecycle", "active"]].map(([k, v]) => <div key={k} style={{ display: "flex", gap: 8 }}><span style={{ color: "var(--muted)", width: 64, flex: "none" }}>{k}</span><span style={{ ...mono, color: "var(--text)", overflowWrap: "anywhere" }}>{v}</span></div>)}
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}><Button size="xs" icon="fileText">View Markdown</Button><Button size="xs" variant="ghost" icon="clock">History</Button></div>
          </div> : null}
        </section>
      </aside>
    </div>
  </div>;
}

/* Read-only copyable request. The host can't prefill chat yet: Copy → Open chat → paste, review, send. */
function Handoff({ h, onClose, onOpenChat }) {
  const [copied, setCopied] = useState(false);
  const isClaim = !!h.rec.text;
  const title = isClaim ? h.rec.text : h.rec.title;
  const rid = (isClaim ? "clm_" : "pg_") + (h.rec.id || h.id);
  const ask = h.kind === "correct" ? `Please check this saved claim against its evidence and correct or withdraw it if the evidence supports that.\n\nWhat I think is wrong: `
    : h.kind === "identity" ? `Is “${title}” the same person as “${E[h.cand].title}”? Check the evidence on both pages. Link them only if it supports that; don’t merge on the handle alone.`
    : `What do you know about “${title}”, and where did it come from?`;
  const refs = [["Record", title], ["ID", rid], ["Revision", String(h.rec.rev)], ["Hash", hashOf(rid)]].concat(h.cand ? [["Candidate", "pg_" + h.cand]] : []);
  const text = `${ask}\n\n${refs.map(([k, v]) => `${k}: ${v}`).join("\n")}`;
  return <div role="dialog" aria-label="Request for Molty" style={{ position: "fixed", inset: 0, zIndex: 50, display: "flex", alignItems: "center", justifyContent: "center", background: "color-mix(in srgb, var(--bg) 60%, transparent)" }} onClick={onClose}>
    <div onClick={(ev) => ev.stopPropagation()} style={{ ...surface, width: "min(560px, calc(100vw - 32px))", boxShadow: "var(--shadow-lg)", display: "grid" }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "16px 18px 12px" }}>
        <span style={{ display: "grid", gap: 4, flex: 1 }}>
          <strong style={{ color: "var(--text-strong)", fontSize: 15 }}>{h.kind === "correct" ? "Ask Molty to correct this" : h.kind === "identity" ? "Ask Molty to check this match" : "Ask Molty"}</strong>
          <span style={{ color: "var(--muted)", fontSize: 13, lineHeight: 1.5 }}>Copy the request, open chat, paste it, then review and send. Nothing is sent or changed from here.</span>
        </span>
        <IconButton icon="x" label="Close" onClick={onClose} size={28} iconSize={14} />
      </div>
      <div style={{ padding: "0 18px 14px" }}>
        <pre style={{ margin: 0, padding: "12px 14px", borderRadius: "var(--radius-md)", border: hair, background: "var(--bg)", color: "var(--text)", fontFamily: "var(--mono)", fontSize: 12, lineHeight: 1.6, whiteSpace: "pre-wrap", maxHeight: 260, overflow: "auto", userSelect: "all" }}>{text}</pre>
        <span style={{ display: "block", marginTop: 8, color: "var(--muted)", fontSize: 12 }}>The ID, revision and hash let Molty confirm it’s looking at the same version you are.</span>
      </div>
      <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, padding: "12px 18px", borderTop: hair }}>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button icon={copied ? "check" : "copy"} onClick={() => { try { navigator.clipboard.writeText(text); } catch (x) {} setCopied(true); }}>{copied ? "Copied" : "Copy request"}</Button>
        <Button variant="primary" icon="messageSquare" onClick={onOpenChat}>Open chat</Button>
      </div>
    </div>
  </div>;
}

/* Design-review panel: jumps to each acceptance example. Not product UI. */
const EXAMPLES = [
  ["1", "Handle-only person", [["kestrel", "entity"]]],
  ["2", "Owner without deadline · neither", [["ci", "claim"], ["down", "claim"]]],
  ["3", "Source-only dataset facets", [["claims", "browse"]]],
  ["4", "Meeting with many attendance records", [["recent", "tab"]]],
  ["5", "One transcript, several ranges + original", [["standup23", "entity"], ["prs", "claim"]]],
  ["6", "Date-only event · evening across UTC", [["freeze", "entity"], ["partner22", "entity"]]],
  ["7", "Reaffirming pair · conflicting pair", [["prs", "claim"], ["conn23", "claim"]]],
  ["8", "Corrected claim · withdrawn connection", [["freezeD", "claim"], ["rLin", "hist"]]],
  ["9", "Missing evidence · unknown confidence", [["rot", "claim"], ["down", "claim"]]],
];
function Review({ nav, mixed, setMixed, onIdle, onUpdate, live, setLive }) {
  const [open, setOpen] = useState(true);
  const btn = { border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", background: "var(--bg)", color: "var(--text)", font: "inherit", fontSize: 11.5, padding: "2px 8px", cursor: "pointer" };
  return <div style={{ position: "fixed", right: 16, bottom: 16, zIndex: 40, width: open ? 300 : "auto", ...surface, boxShadow: "var(--shadow-lg)", fontSize: 12 }}>
    <button type="button" onClick={() => setOpen(!open)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "9px 12px", border: 0, background: "transparent", color: "var(--text-strong)", font: "inherit", fontSize: 12, fontWeight: 600, cursor: "pointer" }}><Icon name="flaskConical" size={13} />Review fixtures<span style={{ marginLeft: "auto", color: "var(--muted)", fontWeight: 400 }}>{open ? "Hide" : "Show"}</span></button>
    {open ? <div style={{ display: "grid", gap: 8, padding: "0 12px 12px", maxHeight: "60vh", overflow: "auto" }}>
      <span style={{ color: "var(--muted)" }}>Isolated synthetic data · not product UI</span>
      {EXAMPLES.map(([n, label, targets]) => <div key={n} style={{ display: "grid", gridTemplateColumns: "16px minmax(0,1fr)", gap: 6 }}>
        <span style={{ ...mono, color: "var(--muted)" }}>{n}</span>
        <span style={{ display: "grid", gap: 4 }}><span style={{ color: "var(--text)" }}>{label}</span><span style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>{targets.map(([id, k]) => <button key={id + k} type="button" style={btn} onClick={() => nav(k, id)}>{k === "tab" ? "Recent" : k === "browse" ? "Browse › Claims" : k === "hist" ? "History" : (E[id] ? E[id].title : CL[id].text).replace(/ — 2026.*$/, "").slice(0, 26)}</button>)}</span></span>
      </div>)}
      <div style={{ display: "grid", gridTemplateColumns: "16px minmax(0,1fr)", gap: 6 }}><span style={{ ...mono, color: "var(--muted)" }}>10</span><span style={{ display: "grid", gap: 4 }}><span style={{ color: "var(--text)" }}>Live refresh keeps reading state</span><span style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
        <button type="button" style={btn} onClick={onIdle}>Idle poll</button><button type="button" style={btn} onClick={onUpdate}>Real update</button>
        <button type="button" style={btn} onClick={() => setLive(live === "ok" ? "off" : "ok")}>{live === "ok" ? "Disconnect" : "Reconnect"}</button></span></span></div>
      <label style={{ display: "flex", alignItems: "center", gap: 8, paddingTop: 6, borderTop: hair, color: "var(--text)" }}><input type="checkbox" checked={mixed} onChange={(ev) => setMixed(ev.target.checked)} />Add a user statement + an inference</label>
    </div> : null}
  </div>;
}

export function KnowledgeV4Screen({ onAsk = () => {} }) {
  const [tab, setTab] = useState("recent");
  const [view, setView] = useState(null);
  const [bq, setBq] = useState({ q: "", mode: "pages", n: 0 });
  const [mixed, setMixed] = useState(false);
  const [handoff, setHandoff] = useState(null);
  const [live, setLive] = useState("ok");
  const [checked, setChecked] = useState("just now");
  const [fresh, setFresh] = useState(false);
  const [showFresh, setShowFresh] = useState(false);
  const [toast, setToast] = useState(null);
  const say = (t) => { setToast(t); setTimeout(() => setToast(null), 2600); };
  const open = (id) => setView({ kind: "entity", id });
  const openClaim = (id) => setView({ kind: "claim", id });
  const openHist = (id) => setView({ kind: "hist", id });
  const browse = (q, mode = "pages") => { setBq((b) => ({ q, mode, n: b.n + 1 })); setView(null); setTab("browse"); };
  const onHandoff = (kind, rec, id, cand) => setHandoff({ kind, rec, id, cand });
  const nav = (k, id) => k === "entity" ? open(id) : k === "claim" ? openClaim(id) : k === "hist" ? openHist(id) : k === "browse" ? browse("", "claims") : (setView(null), setTab("recent"));
  const props = { onOpen: open, onOpenClaim: openClaim, onOpenHist: openHist, onHandoff, mixed };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <PageHeader title="Knowledge" subtitle="What Molty has saved, and where it came from."
        tabs={<HubTabs value={view ? "" : tab} onChange={(v) => { setView(null); setTab(v); }} tabs={[{ value: "recent", label: "Recent" }, { value: "browse", label: "Browse", count: Object.keys(E).length }]} />}
        actions={<span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
          <span title={`Checked ${checked}`}><StatusDot tone={live === "ok" ? "ok" : "warn"} label={live === "ok" ? "Live" : "Reconnecting…"} /></span>
          <IconButton variant="bordered" icon="book" label="Vocabulary & vault" size={34} iconSize={16} />
        </span>} />
      <div style={{ width: "100%", maxWidth: 1120, margin: "0 auto", padding: "4px 16px 96px", boxSizing: "border-box", display: "grid", gap: 16 }}>
        {live !== "ok" ? <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: "var(--radius-md)", background: "var(--warn-subtle)", color: "var(--text)", fontSize: 13 }}><Icon name="alertTriangle" size={15} /><span><strong style={{ color: "var(--text-strong)" }}>Can’t reach the vault.</strong> Showing the last readable view, checked at 5:58 PM PDT. Retrying.</span></div> : null}
        {view && view.kind === "entity" ? <Entity key={view.id} id={view.id} {...props} onBack={() => setView(null)} />
          : view && view.kind === "claim" ? <ClaimPage key={view.id} id={view.id} {...props} onBack={() => setView(null)} />
          : view && view.kind === "hist" ? <HistPage id={view.id} {...props} onBack={() => setView(null)} />
          : tab === "recent" ? <Recent {...props} onBrowse={browse} fresh={fresh && !showFresh} showFresh={showFresh} onShowFresh={() => { setShowFresh(true); setFresh(false); }} />
          : <Browse key={bq.n} initialQuery={bq.q} initialMode={bq.mode} {...props} />}
      </div>
      {handoff ? <Handoff h={handoff} onClose={() => setHandoff(null)} onOpenChat={() => { setHandoff(null); onAsk(""); }} /> : null}
      {toast ? <div style={{ position: "fixed", left: "50%", bottom: 24, transform: "translateX(-50%)", zIndex: 60, padding: "8px 14px", borderRadius: 999, background: "var(--card)", border: "1px solid var(--border)", color: "var(--text-strong)", fontSize: 12.5, boxShadow: "var(--shadow-lg)" }}>{toast}</div> : null}
      <Review nav={nav} mixed={mixed} setMixed={setMixed} live={live} setLive={setLive}
        onIdle={() => { setChecked("just now"); say("Checked · no changes. Nothing on screen moved."); }}
        onUpdate={() => { if (!showFresh) setFresh(true); setTab("recent"); say(view ? "1 new save in Recent. This page is unchanged." : "1 new save. Expanded rows stay open."); }} />
    </div>
  );
}
