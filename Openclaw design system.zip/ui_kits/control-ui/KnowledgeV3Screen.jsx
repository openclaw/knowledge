import React, { useState } from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { Button } from "../../components/core/Button.jsx";
import { IconButton } from "../../components/core/IconButton.jsx";
import { Chip } from "../../components/core/Chip.jsx";
import { Segmented } from "../../components/core/Segmented.jsx";
import { StatusDot } from "../../components/core/StatusDot.jsx";
import { PageHeader } from "../../components/settings/PageHeader.jsx";
import { HubTabs } from "../../components/navigation/HubTabs.jsx";
import { SettingsSection } from "../../components/settings/SettingsSection.jsx";
import { SettingsRow } from "../../components/settings/SettingsRow.jsx";
import { DataTable, PaginationButton } from "../../components/navigation/DataTable.jsx";
/* Knowledge v3: v2 + the implemented lifecycle model (docs/CORRECTIONS.md, src/recent.ts, src/lifecycle.ts).
   - A correction is ONE event: the current statement is shown, with the earlier one struck through beneath it.
   - Withdrawals are quiet: consecutive withdrawals collapse into one "N withdrawn" row.
   - Repeated saves of one record on the same day merge into one row ("Updated 2×").
   - Status lives in the meta line (icon + word). No status pills. Expanded rows use a tint, not accent borders.
   - Entity pages show the version history of corrected claims and hide withdrawn claims behind "Show N withdrawn".
   - Superseded or withdrawn records open with a lifecycle banner that links to the current version.
   - Browse: "Current | Include history" maps to records({ lifecycle: "all" }).
   - Feed is grouped by date only; conversation grouping waits for backend provenance (see REPORT §3.2). */
const T = {
  person: ["circleUser", "Person", "var(--accent-2)", "var(--accent-2-subtle)"],
  company: ["box", "Company", "var(--info)", "var(--info-subtle)"],
  project: ["kanban", "Project", "var(--ok)", "var(--ok-subtle)"],
  concept: ["spark", "Concept", "var(--warn)", "var(--warn-subtle)"],
  meeting: ["users", "Meeting", "var(--accent)", "var(--accent-subtle)"],
  email: ["mail", "Email", "var(--muted-strong)", "var(--bg-hover)"],
  source: ["paperclip", "Source", "var(--muted-strong)", "var(--bg-hover)"],
  note: ["fileText", "Note", "var(--muted-strong)", "var(--bg-hover)"],
};
const KIND = { decision: ["flag", "Decision", "Decisions"], commitment: ["listChecks", "Commitment", "Commitments"], preference: ["star", "Preference", "Preferences"], fact: ["info", "Fact", "Facts"], belief: ["brain", "Opinion", "Opinions"], relationship: ["link", "Connection", "Connections"] };
const E = {
  mario: { type: "person", title: "Mario Ferrante", aliases: ["Mario"], fields: [["Role", "Infra lead, Northwind Labs"]], updated: "5h ago",
    summary: "Leads infrastructure at Northwind Labs and owns their side of the gateway auth migration. Reachable on iMessage for quick questions; prefers email for anything with a deadline.",
    links: [["Works at", "northwind"], ["Leads", "authproj"], ["Attended", "standup"]], path: "people/mario-ferrante.md", rev: 5 },
  lena: { type: "person", title: "Lena Park", aliases: [], fields: [["Role", "Product designer"]], updated: "2h ago", summary: "Designs the Control UI approval flows.", links: [], withdrawnLinks: [["Attended", "standup", "Lena was out that day; the transcript mislabeled a speaker."]], path: "people/lena-park.md", rev: 2 },
  dev: { type: "person", title: "Dev Shah", aliases: [], fields: [["Role", "Security reviewer"]], updated: "2h ago", summary: "Reviews auth-related changes before they merge.", links: [["Advises", "authproj"], ["Attended", "standup"]], path: "people/dev-shah.md", rev: 1 },
  northwind: { type: "company", title: "Northwind Labs", aliases: ["Northwind"], fields: [], updated: "3d ago", summary: "Runs a self-hosted OpenClaw gateway for their ops team.", links: [["Employs", "mario"]], path: "companies/northwind-labs.md", rev: 3 },
  authproj: { type: "project", title: "Gateway auth refactor", aliases: ["auth migration"], fields: [["Status", "Active"]], updated: "2h ago", summary: "Moving gateway credentials out of config files and into the OS keychain, without breaking existing installs.", links: [["Led by", "mario"], ["Reviewed by", "dev"], ["Relates to", "release"], ["About", "keychain"]], path: "projects/gateway-auth-refactor.md", rev: 6 },
  release: { type: "project", title: "2026.9 release", aliases: [], fields: [["Status", "Active"]], updated: "2h ago", summary: "September release train.", links: [["Relates to", "authproj"]], path: "projects/2026-9-release.md", rev: 9 },
  standup: { type: "meeting", title: "Team standup — Sep 22", aliases: [], fields: [["When", "Sep 22, 09:30"]], updated: "2h ago", summary: "Weekly standup. Agreed on keychain storage and dropping the legacy token fallback for 2026.9.", links: [["Attended by", "mario"], ["Attended by", "dev"]], withdrawnLinks: [["Attended by", "lena", "Lena was out that day; the transcript mislabeled a speaker."]], path: "meetings/2026-09-22-standup.md", rev: 2 },
  keychain: { type: "concept", title: "OS keychain token storage", aliases: [], fields: [], updated: "Yesterday", summary: "Keeping secrets in the platform keychain; config files hold only a reference.", links: [["Discussed in", "authproj"]], path: "concepts/os-keychain-token-storage.md", rev: 1 },
  qa: { type: "note", title: "Browser QA checklist", aliases: [], fields: [], updated: "Today", summary: "Steps for the browser QA sweep.", links: [], path: "notes/browser-qa-checklist.md", rev: 3, lifecycle: "withdrawn", change: { reason: "Duplicate of “QA sweep checklist”.", at: "Today, 3:58 PM", actor: "Molty" } },
};
const STANDUP = "standup-2026-09-22.txt";
const C = [
  { id: "c1", kind: "decision", text: "Gateway tokens move to the OS keychain; config files keep only a reference.", origin: "source", about: ["authproj", "keychain"], when: "2h ago", quote: "OK so we agreed — tokens go in the keychain, config only keeps a pointer.", speaker: "Mario Ferrante", file: STANDUP, lines: "41–43" },
  { id: "c2", kind: "commitment", text: "Mario will send the auth migration plan by Friday, Sep 26.", origin: "source", about: ["mario", "authproj"], when: "5h ago", quote: "I’ll get you the migration plan by Friday.", speaker: "Mario Ferrante", file: "imessage-mario-2026-09-23.txt", lines: "12",
    lifecycle: "superseded", supersededBy: "c2b", change: { reason: "Mario moved the date in a follow-up message.", at: "Today, 4:05 PM", actor: "Molty" } },
  { id: "c2b", kind: "commitment", text: "Mario will send the auth migration plan by Monday, Sep 29.", origin: "source", about: ["mario", "authproj"], when: "Today, 4:05 PM", quote: "Actually make that Monday, sorry — still finishing the rollback section.", speaker: "Mario Ferrante", file: "imessage-mario-2026-09-23.txt", lines: "18", supersedes: "c2",
    impact: [["authproj", "Gateway auth refactor", "Its summary still says “plan due Friday”."]] },
  { id: "c3", kind: "preference", text: "Mario prefers email for anything with a deadline.", origin: "user", about: ["mario"], when: "Yesterday", quote: "Btw Mario hates deadline stuff over iMessage, email him for those.", speaker: "You" },
  { id: "c4", kind: "fact", text: "Northwind Labs runs its gateway behind a Cloudflare tunnel.", origin: "inferred", about: ["northwind"], when: "Yesterday", reason: "Inferred from cf-connecting-ip headers in gateway logs Mario shared.",
    lifecycle: "withdrawn", change: { reason: "You said this was wrong: they use Tailscale, and the headers came from a test proxy.", at: "Today, 3:58 PM", actor: "Molty" } },
  { id: "c5", kind: "decision", text: "Ship 2026.9 without the legacy token fallback.", origin: "source", about: ["release", "authproj"], when: "2h ago", quote: "Let’s just drop the fallback for .9, nobody’s on the old format.", speaker: "Mario Ferrante", file: STANDUP, lines: "58–60" },
  { id: "c6", kind: "fact", text: "Dev Shah reviews all auth-related changes before merge.", origin: "source", about: ["dev", "authproj"], when: "2h ago", quote: "Anything touching auth goes through me first.", speaker: "Dev Shah", file: STANDUP, lines: "71" },
  { id: "c7", kind: "belief", text: "Lena thinks the approval dialog is too dense on mobile.", origin: "source", about: ["lena"], when: "2h ago", quote: "On a phone the approval sheet is a wall of text.", speaker: "Lena Park", file: STANDUP, lines: "88–89" },
];
const CL = Object.fromEntries(C.map((c) => [c.id, c]));
/* Feed = recent() events, newest first. Client coalescing: consecutive withdrawals → one group; same-record saves on one day → one row. */
const FEED = [
  { day: "Today", events: [
    { change: "corrected", ref: "c2b", at: "4:05 PM" },
    { change: "withdrawn", kind: "fact", ref: "c4", title: "Northwind Labs runs its gateway behind a Cloudflare tunnel.", at: "3:58 PM" },
    { change: "withdrawn", kind: "relationship", title: "Lena Park attended Team standup — Sep 22", reason: "Lena was out that day; the transcript mislabeled a speaker.", at: "3:58 PM", open: "lena" },
    { change: "withdrawn", kind: "note", ref: "qa", title: "Browser QA checklist", at: "3:58 PM" },
    { change: "created", ref: "standup", at: "2:10 PM" },
    { change: "created", claim: "c1", at: "2:10 PM" }, { change: "created", claim: "c5", at: "2:10 PM" }, { change: "created", claim: "c6", at: "2:10 PM" }, { change: "created", claim: "c7", at: "2:10 PM" },
    { change: "created", ref: "dev", at: "2:10 PM" },
    { change: "updated", ref: "mario", at: "11:20 AM", count: 2, note: "Added alias “Mario” · role" },
    { change: "external", ref: "release", at: "9:02 AM", note: "Edited outside OpenClaw" },
  ] },
  { day: "Yesterday", events: [
    { change: "created", ref: "authproj", at: "4:12 PM" }, { change: "created", ref: "keychain", at: "4:12 PM" }, { change: "created", claim: "c3", at: "4:12 PM" },
  ] },
];
const FACETS = [
  ["People & things", [["person", "People", 412], ["company", "Companies", 138]]],
  ["Ideas & projects", [["project", "Projects", 64], ["concept", "Concepts", 221], ["note", "Notes", 380]]],
  ["Sources & writing", [["source", "Sources", 190], ["media", "Media", 96], ["writing", "Writing", 22]]],
  ["Events & conversations", [["meeting", "Meetings", 311], ["email", "Email", 244], ["slack", "Slack", 104], ["conversation", "Conversations", 128], ["event", "Events", 57], ["deal", "Deals", 18], ["diary", "Diary", 20]]],
  ["Annotations", [["atom", "Atoms", 13]]],
];
const MORE = [["Q3 infra budget", "note", 3, 2, "3d ago"], ["Hetzner", "company", 5, 4, "4d ago"], ["Re: gateway pricing", "email", 2, 3, "4d ago"], ["Ana Lima", "person", 7, 5, "5d ago"]];
const eyebrow = { margin: 0, display: "flex", alignItems: "center", gap: 8, fontSize: 11, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--muted-strong)" };
const surface = { background: "var(--card)", border: "1px solid color-mix(in srgb, var(--border) 85%, transparent)", borderRadius: "var(--radius-lg)", overflow: "hidden" };
const hair = "1px solid color-mix(in srgb, var(--border) 60%, transparent)";
const tint = "color-mix(in srgb, var(--bg-hover) 45%, transparent)";
const activeAbout = (id) => C.filter((c) => c.about.includes(id) && !c.lifecycle);
const withdrawnAbout = (id) => C.filter((c) => c.about.includes(id) && c.lifecycle === "withdrawn");
const hov = { onMouseEnter: (ev) => ev.currentTarget.style.background = "color-mix(in srgb, var(--bg-hover) 60%, transparent)", onMouseLeave: (ev) => ev.currentTarget.style.background = "transparent" };

function Tile({ type, size = 28, muted }) {
  const [ic, , color, bg] = T[type] || T.note;
  return <span style={{ width: size, height: size, flex: "none", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: size > 32 ? "var(--radius-md)" : "var(--radius-sm)", color: muted ? "var(--muted)" : color, background: muted ? "var(--bg-hover)" : bg }}><Icon name={ic} size={Math.round(size / 2)} /></span>;
}
function Origin({ c }) {
  const o = { source: ["paperclip", "From source", "var(--muted)"], user: ["circleUser", "You told Molty", "var(--accent-2)"], inferred: ["spark", "Molty inferred", "var(--warn)"] }[c.origin];
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: o[2], fontSize: 12, fontWeight: 500 }}><Icon name={o[0]} size={12} />{o[1]}</span>;
}
/* Status word for meta lines; replaces pills. */
function Status({ s, count }) {
  const m = { created: ["plus", "New", "var(--accent)"], updated: ["pencil", count > 1 ? `Updated ${count}×` : "Updated", "var(--muted-strong)"], external: ["fileText", "Edited outside OpenClaw", "var(--muted-strong)"], observed: ["eye", "Imported", "var(--muted-strong)"], corrected: ["repeat", "Corrected", "var(--info)"], withdrawn: ["archive", "Withdrawn", "var(--muted)"], superseded: ["repeat", "Replaced", "var(--muted)"] }[s];
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: m[2], fontSize: 12, fontWeight: 500 }}><Icon name={m[0]} size={12} />{m[1]}</span>;
}
function EntityLink({ id, onOpen }) {
  const [h, setH] = useState(false);
  return <button type="button" onClick={(e) => { e.stopPropagation(); onOpen(id); }} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ border: 0, padding: 0, background: "none", font: "inherit", color: h ? "var(--text-strong)" : "var(--text)", textDecoration: h ? "underline" : "none", textUnderlineOffset: 2, cursor: "pointer" }}>{E[id].title}</button>;
}
function Evidence({ c }) {
  if (c.origin === "inferred") return <div style={{ padding: "10px 12px", borderRadius: "var(--radius-md)", background: "var(--warn-subtle)", color: "var(--text)", fontSize: 13, lineHeight: 1.5 }}><strong style={{ color: "var(--warn)" }}>No quoted source.</strong> {c.reason}</div>;
  return <figure style={{ margin: 0, padding: "12px 14px", borderRadius: "var(--radius-md)", background: "var(--bg-accent, var(--bg-hover))", border: hair }}>
    <blockquote style={{ margin: 0, color: "var(--text-strong)", fontSize: 14, lineHeight: 1.55 }}>“{c.quote}”</blockquote>
    <figcaption style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: "4px 10px", color: "var(--muted)", fontSize: 12 }}>
      <span>— {c.speaker}</span>
      {c.file ? <span style={{ fontFamily: "var(--mono)", fontSize: 11 }}>{c.file} · line {c.lines}</span> : <span>Chat message</span>}
      {c.file ? <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "var(--ok)" }}><Icon name="badgeCheck" size={12} />Original retained</span> : null}
    </figcaption>
  </figure>;
}
/* Version chain block, used inside expanded claim rows and on the claim page. */
function History({ c, onOpenClaim }) {
  const chain = []; let p = c;
  while (p && p.supersedes) { const prev = CL[p.supersedes]; chain.push(prev); p = prev; }
  if (!chain.length) return null;
  return <div style={{ display: "grid", gap: 8 }}>
    <span style={{ ...eyebrow, fontSize: 10 }}>Earlier version{chain.length > 1 ? "s" : ""}</span>
    {chain.map((v) => <div key={v.id} style={{ display: "grid", gridTemplateColumns: "14px minmax(0,1fr) auto", gap: 10, alignItems: "start" }}>
      <span style={{ color: "var(--muted)", paddingTop: 3 }}><Icon name="repeat" size={12} /></span>
      <span style={{ display: "grid", gap: 2 }}>
        <span style={{ color: "var(--muted)", fontSize: 13, textDecoration: "line-through", textDecorationColor: "color-mix(in srgb, var(--muted) 60%, transparent)" }}>{v.text}</span>
        <span style={{ color: "var(--muted)", fontSize: 12 }}>Replaced {v.change.at.replace("Today, ", "today at ")} · {v.change.reason}</span>
      </span>
      <Button size="xs" variant="ghost" onClick={() => onOpenClaim(v.id)}>View</Button>
    </div>)}
  </div>;
}

function ClaimRow({ c, onOpen, onOpenClaim, onAsk, first, showAbout = true, status, statusCount }) {
  const [open, setOpen] = useState(false);
  const [ic, label] = KIND[c.kind];
  const prev = c.supersedes && CL[c.supersedes];
  return <div style={{ borderTop: first ? 0 : hair, background: open ? tint : "transparent" }}>
    <div role="button" tabIndex={0} onClick={() => setOpen(!open)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "start", padding: "12px 14px", cursor: "pointer" }}>
      <span title={label} style={{ width: 28, height: 28, display: "inline-flex", alignItems: "center", justifyContent: "center", color: "var(--muted-strong)" }}><Icon name={ic} size={15} /></span>
      <span style={{ display: "grid", gap: 4, minWidth: 0 }}>
        <span style={{ color: "var(--text-strong)", fontSize: 14, lineHeight: 1.45, textWrap: "pretty" }}>{c.text}</span>
        {prev && status === "corrected" ? <span style={{ color: "var(--muted)", fontSize: 13, lineHeight: 1.45, textDecoration: "line-through", textDecorationColor: "color-mix(in srgb, var(--muted) 60%, transparent)" }}>{prev.text}</span> : null}
        <span style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 10px", color: "var(--muted)", fontSize: 12 }}>
          {status ? <Status s={status} count={statusCount} /> : null}
          {!status && prev ? <Status s="corrected" /> : null}
          <span>{label}</span><Origin c={c} />
          {showAbout ? <span style={{ display: "inline-flex", gap: 4 }}>About {c.about.map((a, i) => <span key={a}>{i ? ", " : ""}<EntityLink id={a} onOpen={onOpen} /></span>)}</span> : null}
          <span>{c.when}</span>
        </span>
      </span>
      <span style={{ color: "var(--muted)", paddingTop: 6, transform: open ? "rotate(180deg)" : "none", transition: "transform .15s" }}><Icon name="chevronDown" size={14} /></span>
    </div>
    {open ? <div style={{ margin: "0 14px 14px 54px", display: "grid", gap: 12 }}>
      {status === "corrected" && prev ? <p style={{ margin: 0, color: "var(--text)", fontSize: 13, lineHeight: 1.5 }}><strong style={{ color: "var(--text-strong)" }}>Why it changed:</strong> {prev.change.reason}</p> : null}
      <Evidence c={c} />
      {c.impact ? <div style={{ display: "grid", gap: 6, padding: "10px 12px", borderRadius: "var(--radius-md)", border: hair }}>
        <span style={{ color: "var(--text-strong)", fontSize: 13, fontWeight: 600 }}>{c.impact.length} related record{c.impact.length > 1 ? "s were" : " was"} not updated</span>
        {c.impact.map(([id, t, why]) => <span key={id} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}><Tile type={E[id].type} size={20} /><EntityLink id={id} onOpen={onOpen} /><span style={{ color: "var(--muted)", fontSize: 12 }}>{why}</span></span>)}
      </div> : null}
      {status !== "corrected" ? <History c={c} onOpenClaim={onOpenClaim} /> : null}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        <Button size="sm" icon="fileText" onClick={() => onOpenClaim(c.id)}>Open claim</Button>
        {prev ? <Button size="sm" variant="ghost" icon="repeat" onClick={() => onOpenClaim(prev.id)}>View original</Button> : null}
        {c.file ? <Button size="sm" variant="ghost" icon="download">Original file</Button> : null}
        <Button size="sm" variant="ghost" icon="pencil" onClick={() => onAsk(`This isn’t right: “${c.text}” — `)}>Correct in chat</Button>
      </div>
    </div> : null}
  </div>;
}

/* Muted single line for a withdrawn item. */
function WithdrawnLine({ e, onOpen, onOpenClaim, first }) {
  const c = e.ref && CL[e.ref], rec = e.ref && E[e.ref];
  const reason = e.reason || (c && c.change.reason) || (rec && rec.change && rec.change.reason);
  const kindIcon = KIND[e.kind] ? KIND[e.kind][0] : (T[e.kind] || T.note)[0];
  const kindLabel = KIND[e.kind] ? KIND[e.kind][1] : (T[e.kind] || T.note)[1];
  return <div role="button" onClick={() => c ? onOpenClaim(c.id) : rec ? onOpen(e.ref) : e.open && onOpen(e.open)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "start", padding: "9px 14px", borderTop: first ? 0 : hair, cursor: "pointer" }} {...hov}>
    <span style={{ display: "inline-flex", justifyContent: "center", paddingTop: 2, color: "var(--muted)" }}><Icon name={kindIcon} size={14} /></span>
    <span style={{ display: "grid", gap: 2, minWidth: 0 }}>
      <span style={{ color: "var(--muted-strong)", fontSize: 13, textDecoration: "line-through", textDecorationColor: "color-mix(in srgb, var(--muted) 50%, transparent)" }}>{e.title}</span>
      <span style={{ color: "var(--muted)", fontSize: 12 }}>{kindLabel} · {reason}</span>
    </span>
    <span style={{ color: "var(--muted)", fontSize: 12, paddingTop: 2 }}>{e.at}</span>
  </div>;
}
function WithdrawnGroup({ items, onOpen, onOpenClaim, first }) {
  const [open, setOpen] = useState(false);
  if (items.length === 1) return <WithdrawnLine e={items[0]} first={first} onOpen={onOpen} onOpenClaim={onOpenClaim} />;
  return <div style={{ borderTop: first ? 0 : hair, background: open ? tint : "transparent" }}>
    <div role="button" onClick={() => setOpen(!open)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "10px 14px", cursor: "pointer" }}>
      <span style={{ display: "inline-flex", justifyContent: "center", color: "var(--muted)" }}><Icon name="archive" size={15} /></span>
      <span style={{ display: "flex", flexWrap: "wrap", alignItems: "baseline", gap: "2px 10px", minWidth: 0 }}>
        <span style={{ color: "var(--text)", fontSize: 13.5, fontWeight: 500 }}>{items.length} items withdrawn</span>
        <span style={{ color: "var(--muted)", fontSize: 12 }}>No longer used in search or answers · {items[0].at}</span>
      </span>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 12 }}>{open ? "Hide" : "Show"}<Icon name={open ? "chevronUp" : "chevronDown"} size={14} /></span>
    </div>
    {open ? <div style={{ borderTop: hair }}>{items.map((e, i) => <WithdrawnLine key={i} e={e} first={i === 0} onOpen={onOpen} onOpenClaim={onOpenClaim} />)}</div> : null}
  </div>;
}
function SaveRow({ e, onOpen, first }) {
  const rec = E[e.ref];
  return <div role="button" onClick={() => onOpen(e.ref)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "10px 14px", borderTop: first ? 0 : hair, cursor: "pointer" }} {...hov}>
    <Tile type={rec.type} />
    <span style={{ display: "grid", gap: 2, minWidth: 0 }}>
      <span style={{ color: "var(--text-strong)", fontSize: 14, fontWeight: 500 }}>{rec.title}</span>
      <span style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "2px 10px", color: "var(--muted)", fontSize: 12 }}><Status s={e.change} count={e.count} /><span>{T[rec.type][1]}</span>{e.note && e.change !== "external" ? <span>{e.note}</span> : null}</span>
    </span>
    <span style={{ color: "var(--muted)", fontSize: 12 }}>{e.at}</span>
  </div>;
}

function Search({ onOpen, onBrowse }) {
  const [q, setQ] = useState("");
  const [focus, setFocus] = useState(false);
  const s = q.trim().toLowerCase();
  const hits = s ? Object.entries(E).filter(([, e]) => !e.lifecycle && [e.title, ...e.aliases].some((n) => n.toLowerCase().includes(s))).slice(0, 5) : [];
  return <div style={{ position: "relative" }}>
    <label style={{ position: "relative", display: "block" }}>
      <span style={{ position: "absolute", top: "50%", left: 13, transform: "translateY(-50%)", color: "var(--muted)", display: "inline-flex", pointerEvents: "none" }}><Icon name="search" size={16} strokeWidth={1.7} /></span>
      <input value={q} onChange={(e) => setQ(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setTimeout(() => setFocus(false), 150)} placeholder="Find a person, project, or anything Molty saved…" aria-label="Search knowledge"
        style={{ width: "100%", boxSizing: "border-box", minHeight: 44, padding: "8px 12px 8px 38px", border: "1px solid var(--input)", borderRadius: "var(--radius-md)", background: "var(--card)", color: "var(--text)", fontSize: 14, fontFamily: "var(--font-body)", outline: "none", boxShadow: "inset 0 1px 0 var(--card-highlight)" }} />
      <span style={{ position: "absolute", top: "50%", right: 12, transform: "translateY(-50%)", color: "var(--muted)", fontSize: 11, fontFamily: "var(--mono)", border: "1px solid var(--border)", borderRadius: 4, padding: "1px 5px" }}>/</span>
    </label>
    {focus && s ? <div style={{ ...surface, position: "absolute", zIndex: 5, top: "calc(100% + 6px)", left: 0, right: 0, boxShadow: "var(--shadow-lg)", padding: 6 }}>
      {hits.length ? <p style={{ ...eyebrow, padding: "6px 8px" }}>Exact matches</p> : null}
      {hits.map(([id, e]) => <button key={id} type="button" onMouseDown={() => onOpen(id)} style={{ display: "flex", width: "100%", alignItems: "center", gap: 10, padding: "8px", border: 0, borderRadius: "var(--radius-sm)", background: "transparent", color: "var(--text)", font: "inherit", textAlign: "left", cursor: "pointer" }} {...hov}>
        <Tile type={e.type} size={24} /><span style={{ color: "var(--text-strong)", fontWeight: 500 }}>{e.title}</span><span style={{ color: "var(--muted)", fontSize: 12 }}>{T[e.type][1]}</span>
        <span style={{ marginLeft: "auto", color: "var(--muted)", fontSize: 12 }}>{activeAbout(id).length} claims</span>
      </button>)}
      <button type="button" onMouseDown={() => onBrowse(q)} style={{ display: "flex", width: "100%", alignItems: "center", gap: 10, padding: "8px", border: 0, borderTop: hits.length ? hair : 0, marginTop: hits.length ? 4 : 0, background: "transparent", color: "var(--muted-strong)", font: "inherit", fontSize: 13, textAlign: "left", cursor: "pointer" }}>
        <Icon name="search" size={14} />Search all text for “{q}”<span style={{ marginLeft: "auto" }}><Icon name="cornerDownLeft" size={13} /></span>
      </button>
    </div> : null}
  </div>;
}

function Recent({ onOpen, onOpenClaim, onAsk, onBrowse }) {
  const [filter, setFilter] = useState("all");
  const pass = (e) => filter === "all" || (filter === "saved" ? ["created", "updated", "external", "observed"].includes(e.change) : ["corrected", "withdrawn"].includes(e.change));
  const render = (events) => {
    const out = []; let i = 0;
    while (i < events.length) {
      const e = events[i];
      if (e.change === "withdrawn") { const g = []; while (i < events.length && events[i].change === "withdrawn") g.push(events[i++]); out.push(["w", g]); continue; }
      out.push(["e", e]); i++;
    }
    return out.map(([k, v], idx) => k === "w" ? <WithdrawnGroup key={idx} items={v} first={idx === 0} onOpen={onOpen} onOpenClaim={onOpenClaim} />
      : v.claim || v.change === "corrected" ? <ClaimRow key={idx} c={CL[v.claim || v.ref]} status={v.change} first={idx === 0} onOpen={onOpen} onOpenClaim={onOpenClaim} onAsk={onAsk} />
      : <SaveRow key={idx} e={v} first={idx === 0} onOpen={onOpen} />);
  };
  return <div style={{ display: "flex", flexDirection: "column", gap: 28 }}>
    <Search onOpen={onOpen} onBrowse={onBrowse} />
    <SettingsSection title="Needs a look" description="Follow-ups Molty’s changes left behind.">
      <SettingsRow first title="A correction left 1 related record unchanged" description="“Gateway auth refactor” still says the plan is due Friday." control={<Button size="sm" onClick={() => onAsk("Update “Gateway auth refactor” to match the corrected commitment (plan due Monday, Sep 29).")}>Fix in chat</Button>} />
    </SettingsSection>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
      <h2 style={eyebrow}>Activity</h2>
      <Segmented ariaLabel="Activity filter" value={filter} onChange={setFilter} options={[{ value: "all", label: "All" }, { value: "saved", label: "Saved" }, { value: "changes", label: "Corrections & withdrawals" }]} />
    </div>
    {FEED.map((d) => { const ev = d.events.filter(pass); return ev.length ? <section key={d.day} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <h3 style={{ ...eyebrow, color: "var(--muted)" }}>{d.day}</h3>
      <div style={surface}>{render(ev)}</div>
    </section> : null; })}
  </div>;
}

function Browse({ onOpen, onOpenClaim, onAsk, initialQuery }) {
  const [mode, setMode] = useState("pages");
  const [hist, setHist] = useState("current");
  const [facet, setFacet] = useState("all");
  const [q, setQ] = useState(initialQuery || "");
  const rows = [...Object.entries(E).filter(([, e]) => hist === "all" || !e.lifecycle).map(([id, e]) => ({ key: id, name: e.title, type: e.type, claims: activeAbout(id).length, links: e.links.length, updated: e.updated, lifecycle: e.lifecycle })),
    ...MORE.map(([name, type, claims, links, updated]) => ({ key: name, name, type, claims, links, updated }))]
    .filter((r) => (facet === "all" || r.type === facet) && (!q || r.name.toLowerCase().includes(q.toLowerCase())));
  const claims = C.filter((c) => (hist === "all" || !c.lifecycle) && (!q || c.text.toLowerCase().includes(q.toLowerCase())));
  const total = facet === "all" ? 2418 : (FACETS.flatMap((f) => f[1]).find((f) => f[0] === facet) || [0, 0, rows.length])[2];
  const fBtn = (id, label, n) => { const on = facet === id; return <button key={id} type="button" onClick={() => setFacet(id)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "6px 8px", border: 0, borderRadius: "var(--radius-sm)", background: on ? "var(--accent-subtle)" : "transparent", color: on ? "var(--text-strong)" : "var(--text)", font: "inherit", fontSize: 13, textAlign: "left", cursor: "pointer" }}>{T[id] ? <Tile type={id} size={20} /> : <span style={{ width: 20 }} />}<span>{label}</span><span style={{ marginLeft: "auto", color: "var(--muted)", fontSize: 12, fontFamily: "var(--mono)" }}>{n.toLocaleString()}</span></button>; };
  const lifeLabel = (l) => l ? <span style={{ marginLeft: 8 }}><Status s={l === "superseded" ? "superseded" : "withdrawn"} /></span> : null;
  return <div style={{ display: "grid", gridTemplateColumns: "210px minmax(0,1fr)", gap: 24, alignItems: "start" }}>
    <nav aria-label="Types" style={{ position: "sticky", top: 0, display: "grid", gap: 14 }}>
      <div>{fBtn("all", "Everything", 2418)}</div>
      {FACETS.map(([g, items]) => <div key={g} style={{ display: "grid", gap: 2 }}><p style={{ ...eyebrow, padding: "0 8px 4px", fontSize: 10 }}>{g}</p>{items.map(([id, l, n]) => fBtn(id, l, n))}</div>)}
      <p style={{ margin: "0 8px", color: "var(--muted)", fontSize: 12 }}>12 empty types hidden</p>
    </nav>
    <div style={surface}>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, padding: "8px 12px", borderBottom: hair }}>
        <label style={{ position: "relative", flex: "1 1 220px" }}>
          <span style={{ position: "absolute", top: "50%", left: 10, transform: "translateY(-50%)", color: "var(--muted)", display: "inline-flex" }}><Icon name="search" size={14} /></span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={mode === "pages" ? "Filter by name or alias" : "Search claim text"} style={{ width: "100%", boxSizing: "border-box", height: 34, padding: "0 10px 0 30px", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", background: "var(--bg)", color: "var(--text)", fontSize: 13, fontFamily: "var(--font-body)", outline: "none" }} />
        </label>
        <Segmented ariaLabel="Record kind" value={mode} onChange={setMode} options={[{ value: "pages", label: "Pages" }, { value: "claims", label: "Claims" }]} />
        <Segmented ariaLabel="Lifecycle" value={hist} onChange={setHist} options={[{ value: "current", label: "Current" }, { value: "all", label: "Include history" }]} />
      </div>
      {mode === "pages" ? <DataTable sort={{ column: "updated", dir: "desc" }}
        columns={[{ key: "name", label: "Name", sortable: true }, { key: "type", label: "Type", sortable: true }, { key: "claims", label: "Claims", sortable: true }, { key: "links", label: "Connections" }, { key: "updated", label: "Last saved", sortable: true }]}
        rows={rows.map((r) => ({ ...r, onClick: () => E[r.key] && onOpen(r.key) }))} emptyMessage="Nothing matches these filters"
        renderRow={(r, td) => <>
          <td style={td}><span style={{ display: "flex", alignItems: "center", gap: 10 }}><Tile type={r.type} size={24} muted={!!r.lifecycle} /><span style={{ color: r.lifecycle ? "var(--muted)" : "var(--text-strong)", fontWeight: 500 }}>{r.name}</span>{lifeLabel(r.lifecycle)}</span></td>
          <td style={{ ...td, color: "var(--muted)" }}>{(T[r.type] || [0, r.type])[1]}</td>
          <td style={{ ...td, fontFamily: "var(--mono)", fontSize: 12 }}>{r.claims}</td>
          <td style={{ ...td, fontFamily: "var(--mono)", fontSize: 12 }}>{r.links}</td>
          <td style={{ ...td, color: "var(--muted)", whiteSpace: "nowrap" }}>{r.updated}</td>
        </>}
        pagination={<><span>1–{rows.length} of {total.toLocaleString()}{hist === "all" ? " · including withdrawn" : ""} · complete list</span><div style={{ display: "flex", gap: 8 }}><PaginationButton disabled>Previous</PaginationButton><PaginationButton>Next</PaginationButton></div></>} />
        : <div>{claims.map((c, i) => c.lifecycle
            ? <div key={c.id} role="button" onClick={() => onOpenClaim(c.id)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, padding: "11px 14px", borderTop: i ? hair : 0, cursor: "pointer" }} {...hov}>
                <span style={{ display: "inline-flex", justifyContent: "center", color: "var(--muted)", paddingTop: 2 }}><Icon name={KIND[c.kind][0]} size={14} /></span>
                <span style={{ display: "grid", gap: 3 }}><span style={{ color: "var(--muted-strong)", fontSize: 14, textDecoration: "line-through", textDecorationColor: "color-mix(in srgb, var(--muted) 50%, transparent)" }}>{c.text}</span><span style={{ display: "flex", gap: 10, fontSize: 12, color: "var(--muted)" }}><Status s={c.lifecycle} /><span>{c.change.reason}</span></span></span>
                <span style={{ color: "var(--muted)", fontSize: 12 }}>{c.change.at}</span>
              </div>
            : <ClaimRow key={c.id} c={c} first={i === 0} onOpen={onOpen} onOpenClaim={onOpenClaim} onAsk={onAsk} />)}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderTop: hair, color: "var(--muted)", fontSize: 12 }}><span>1–{claims.length} of {hist === "all" ? "7,012" : "6,905"} claims · complete list</span><div style={{ display: "flex", gap: 8 }}><PaginationButton disabled>Previous</PaginationButton><PaginationButton>Next</PaginationButton></div></div></div>}
    </div>
  </div>;
}

/* Banner shown on a superseded or withdrawn record. */
function LifecycleBanner({ life, change, current, onOpenClaim }) {
  const w = life === "withdrawn";
  return <div style={{ display: "flex", alignItems: "flex-start", gap: 12, padding: "12px 14px", borderRadius: "var(--radius-md)", border: hair, background: w ? "var(--bg-hover)" : "var(--info-subtle)" }}>
    <span style={{ color: w ? "var(--muted-strong)" : "var(--info)", display: "inline-flex", paddingTop: 2 }}><Icon name={w ? "archive" : "repeat"} size={16} /></span>
    <span style={{ flex: 1, display: "grid", gap: 3, fontSize: 13, lineHeight: 1.5 }}>
      <strong style={{ color: "var(--text-strong)" }}>{w ? "Withdrawn" : "Replaced by a correction"} · {change.at}</strong>
      <span style={{ color: "var(--text)" }}>{w ? "Molty no longer uses this in search or answers. The original and its evidence are kept." : "This is the earlier version. Search and answers use the current one."}</span>
      <span style={{ color: "var(--muted)" }}>Reason: {change.reason}</span>
    </span>
    {current ? <Button size="sm" icon="arrowRight" onClick={() => onOpenClaim(current)}>Current version</Button> : null}
  </div>;
}

function ClaimPage({ id, onOpen, onOpenClaim, onAsk, onBack }) {
  const c = CL[id];
  const [ic, label] = KIND[c.kind];
  const inactive = !!c.lifecycle;
  return <div style={{ display: "flex", flexDirection: "column", gap: 20, maxWidth: 760 }}>
    <nav style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 13 }}>
      <button type="button" onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 4, border: 0, padding: 0, background: "none", color: "var(--muted-strong)", font: "inherit", cursor: "pointer" }}><Icon name="arrowLeft" size={14} />Knowledge</button>
      <Icon name="chevronRight" size={12} /><span>Claims</span>
    </nav>
    {inactive ? <LifecycleBanner life={c.lifecycle} change={c.change} current={c.supersededBy} onOpenClaim={onOpenClaim} /> : null}
    <header style={{ display: "grid", gap: 8 }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--muted-strong)", fontSize: 12, fontWeight: 600 }}><Icon name={ic} size={14} />{label}</span>
      <h1 style={{ margin: 0, color: inactive ? "var(--muted-strong)" : "var(--text-strong)", fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.3, textWrap: "pretty", textDecoration: c.lifecycle === "withdrawn" ? "line-through" : "none", textDecorationColor: "color-mix(in srgb, var(--muted) 50%, transparent)" }}>{c.text}</h1>
      <span style={{ display: "flex", flexWrap: "wrap", gap: "4px 12px", color: "var(--muted)", fontSize: 12 }}><Origin c={c} /><span style={{ display: "inline-flex", gap: 4 }}>About {c.about.map((a, i) => <span key={a}>{i ? ", " : ""}<EntityLink id={a} onOpen={onOpen} /></span>)}</span><span>Saved {c.when}</span></span>
    </header>
    <Evidence c={c} />
    <History c={c} onOpenClaim={onOpenClaim} />
    {!inactive ? <div style={{ display: "flex", gap: 8 }}><Button size="sm" variant="ghost" icon="pencil" onClick={() => onAsk(`This isn’t right: “${c.text}” — `)}>Correct in chat</Button></div> : null}
  </div>;
}

function Entity({ id, onOpen, onOpenClaim, onAsk, onBack }) {
  const e = E[id];
  const [, typeLabel] = T[e.type];
  const claims = activeAbout(id);
  const gone = withdrawnAbout(id);
  const groups = Object.keys(KIND).map((k) => [k, claims.filter((c) => c.kind === k)]).filter(([, l]) => l.length);
  const [raw, setRaw] = useState(false);
  const [showGone, setShowGone] = useState(false);
  const [showGoneLinks, setShowGoneLinks] = useState(false);
  return <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
    <nav style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 13 }}>
      <button type="button" onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 4, border: 0, padding: 0, background: "none", color: "var(--muted-strong)", font: "inherit", cursor: "pointer" }}><Icon name="arrowLeft" size={14} />Knowledge</button>
      <Icon name="chevronRight" size={12} /><span>{typeLabel === "Person" ? "People" : typeLabel + "s"}</span>
    </nav>
    {e.lifecycle ? <LifecycleBanner life={e.lifecycle} change={e.change} /> : null}
    <header style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
      <Tile type={e.type} size={48} muted={!!e.lifecycle} />
      <div style={{ flex: 1, minWidth: 0, display: "grid", gap: 6 }}>
        <h1 style={{ margin: 0, color: e.lifecycle ? "var(--muted-strong)" : "var(--text-strong)", fontSize: 26, fontWeight: 650, letterSpacing: "-0.025em", lineHeight: 1.15 }}>{e.title}</h1>
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 14px", color: "var(--muted)", fontSize: 13 }}>
          <span>{typeLabel}</span>
          {e.fields.map(([k, v]) => <span key={k}><span style={{ color: "var(--muted)" }}>{k} </span><span style={{ color: "var(--text)" }}>{v}</span></span>)}
          {e.aliases.length ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>Also called {e.aliases.map((a) => <Chip key={a}>{a}</Chip>)}</span> : null}
        </div>
      </div>
      {!e.lifecycle ? <Button icon="messageSquare" onClick={() => onAsk(`What do you know about ${e.title}?`)}>Ask Molty</Button> : null}
    </header>
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 300px", gap: 28, alignItems: "start" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 24, minWidth: 0 }}>
        <section style={{ display: "grid", gap: 8 }}>
          <p style={{ margin: 0, color: "var(--text)", fontSize: 15, lineHeight: 1.65, textWrap: "pretty", maxWidth: "62ch" }}>{e.summary}</p>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>Summary written by Molty · updated {e.updated} · revision {e.rev}</span>
        </section>
        {!e.lifecycle ? <section style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <h2 style={eyebrow}>What Molty knows <span style={{ color: "var(--muted)", fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>{claims.length} claims</span></h2>
          {groups.length || gone.length ? <div style={surface}>
            {groups.map(([k, list], gi) => <div key={k}>
              <div style={{ padding: "8px 14px", borderTop: gi ? hair : 0, color: "var(--muted-strong)", fontSize: 12, fontWeight: 600, background: "color-mix(in srgb, var(--bg-hover) 35%, transparent)" }}>{KIND[k][2]} · {list.length}</div>
              {list.map((c) => <ClaimRow key={c.id} c={c} first={false} onOpen={onOpen} onOpenClaim={onOpenClaim} onAsk={onAsk} showAbout={c.about.length > 1} />)}
            </div>)}
            {gone.length ? <div style={{ borderTop: groups.length ? hair : 0 }}>
              <button type="button" onClick={() => setShowGone(!showGone)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "9px 14px", border: 0, background: "transparent", color: "var(--muted)", font: "inherit", fontSize: 12, textAlign: "left", cursor: "pointer" }}>
                <Icon name="archive" size={13} />{showGone ? "Hide" : "Show"} {gone.length} withdrawn claim{gone.length > 1 ? "s" : ""}<Icon name={showGone ? "chevronUp" : "chevronDown"} size={12} />
              </button>
              {showGone ? gone.map((c) => <WithdrawnLine key={c.id} e={{ ref: c.id, kind: c.kind, title: c.text, at: c.change.at }} onOpen={onOpen} onOpenClaim={onOpenClaim} />) : null}
            </div> : null}
          </div> : <p style={{ margin: 0, color: "var(--muted)", fontSize: 13 }}>No claims about {e.title} yet. Tell Molty in chat and it will save them here.</p>}
        </section> : null}
      </div>
      <aside style={{ display: "flex", flexDirection: "column", gap: 20, position: "sticky", top: 0 }}>
        {e.links.length || (e.withdrawnLinks || []).length ? <section style={{ display: "grid", gap: 8 }}>
          <h2 style={eyebrow}>Connections</h2>
          <div style={surface}>
            {e.links.map(([rel, to], i) => <div key={i} role="button" onClick={() => onOpen(to)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderTop: i ? hair : 0, cursor: "pointer" }} {...hov}>
              <Tile type={E[to].type} size={24} /><span style={{ display: "grid", minWidth: 0 }}><span style={{ color: "var(--muted)", fontSize: 11 }}>{rel}</span><span style={{ color: "var(--text-strong)", fontSize: 13, fontWeight: 500 }}>{E[to].title}</span></span>
            </div>)}
            {(e.withdrawnLinks || []).length ? <div style={{ borderTop: e.links.length ? hair : 0 }}>
              <button type="button" onClick={() => setShowGoneLinks(!showGoneLinks)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "8px 12px", border: 0, background: "transparent", color: "var(--muted)", font: "inherit", fontSize: 12, textAlign: "left", cursor: "pointer" }}><Icon name="archive" size={12} />{e.withdrawnLinks.length} withdrawn<Icon name={showGoneLinks ? "chevronUp" : "chevronDown"} size={12} /></button>
              {showGoneLinks ? e.withdrawnLinks.map(([rel, to, why], i) => <div key={i} style={{ display: "grid", gap: 2, padding: "6px 12px 10px 12px" }}>
                <span style={{ color: "var(--muted-strong)", fontSize: 13, textDecoration: "line-through", textDecorationColor: "color-mix(in srgb, var(--muted) 50%, transparent)" }}>{rel} {E[to].title}</span>
                <span style={{ color: "var(--muted)", fontSize: 12 }}>{why}</span>
              </div>) : null}
            </div> : null}
          </div>
        </section> : null}
        <section style={{ display: "grid", gap: 8 }}>
          <button type="button" onClick={() => setRaw(!raw)} style={{ ...eyebrow, border: 0, padding: 0, background: "none", cursor: "pointer", font: "inherit", fontSize: 11 }}>File details <Icon name={raw ? "chevronUp" : "chevronDown"} size={12} /></button>
          {raw ? <div style={{ ...surface, padding: 12, display: "grid", gap: 6, fontSize: 12 }}>
            {[["File", e.path], ["ID", "rec_" + id], ["Revision", String(e.rev)], ["Lifecycle", e.lifecycle || "active"], ["History", "Committed · 3f9a2c1"]].map(([k, v]) => <div key={k} style={{ display: "flex", gap: 8 }}><span style={{ color: "var(--muted)", width: 64, flex: "none" }}>{k}</span><span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--text)", overflowWrap: "anywhere" }}>{v}</span></div>)}
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}><Button size="xs" icon="fileText">View Markdown</Button><Button size="xs" variant="ghost" icon="clock">History</Button></div>
          </div> : null}
        </section>
      </aside>
    </div>
  </div>;
}

export function KnowledgeV3Screen({ onAsk = () => {} }) {
  const [tab, setTab] = useState("recent");
  const [view, setView] = useState(null); // { kind: "entity" | "claim", id }
  const [bq, setBq] = useState("");
  const open = (id) => setView({ kind: "entity", id });
  const openClaim = (id) => setView({ kind: "claim", id });
  const browse = (q) => { setBq(q); setView(null); setTab("browse"); };
  const props = { onOpen: open, onOpenClaim: openClaim, onAsk };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <PageHeader title="Knowledge" subtitle="What Molty has saved, and where it came from."
        tabs={<HubTabs value={view ? "" : tab} onChange={(v) => { setView(null); setTab(v); }} tabs={[{ value: "recent", label: "Recent" }, { value: "browse", label: "Browse", count: 2418 }]} />}
        actions={<span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}><StatusDot tone="ok" label="Live" /><IconButton variant="bordered" icon="book" label="Vocabulary & vault" size={34} iconSize={16} /></span>} />
      <div style={{ width: "100%", maxWidth: 1120, margin: "0 auto", padding: "4px 16px 48px", boxSizing: "border-box" }}>
        {view && view.kind === "entity" ? <Entity key={view.id} id={view.id} {...props} onBack={() => setView(null)} />
          : view && view.kind === "claim" ? <ClaimPage key={view.id} id={view.id} {...props} onBack={() => setView(null)} />
          : tab === "recent" ? <Recent {...props} onBrowse={browse} />
          : <Browse key={bq} initialQuery={bq} {...props} />}
      </div>
    </div>
  );
}
