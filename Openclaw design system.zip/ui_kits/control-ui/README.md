# Control UI kit

Interactive recreation of the OpenClaw Control UI (web dashboard served by the Gateway at `openclaw dashboard`), built from `ui/src` in the attached codebase.

- `index.html` — Chat route (default). Sidebar → click a page or session; the composer sends a fake message.
- `sessions.html` — Sessions hub (search, state segmented filter, select rows, bulk bar).
- `plugins.html` — Plugins hub (installed group with toggles, ClawHub catalog chips + 4-col grid).

Files: `Shell.jsx` (sidebar + content grid, from layout.css / app-sidebar-render.ts), `ChatScreen.jsx` (chat/startup-layout.css, composer-surface.css, tool-cards.css), `SessionsScreen.jsx` (pages/sessions/view.ts, sessions.css, components.css data-table), `PluginsScreen.jsx` (pages/plugins/*, plugins.css, settings-design.md), `App.jsx` (router).

Not recreated: mobile drawer layout, settings takeover sidebar, command palette, light mode, knot/dash theme families.
