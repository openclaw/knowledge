import React, { useState } from "react";
import { Shell, SESSIONS } from "./Shell.jsx";
import { ChatScreen } from "./ChatScreen.jsx";
import { SessionsScreen } from "./SessionsScreen.jsx";
import { PluginsScreen } from "./PluginsScreen.jsx";
import { KnowledgeScreen } from "./KnowledgeScreen.jsx";
import { KnowledgeV2Screen } from "./KnowledgeV2Screen.jsx";
import { KnowledgeV3Screen } from "./KnowledgeV3Screen.jsx";
import { KnowledgeV4Screen } from "./KnowledgeV4Screen.jsx";
import { Callout } from "../../components/core/Callout.jsx";
export function App({ initialRoute = "chat", knowledgeVersion = 3 }) {
  const [route, setRoute] = useState(initialRoute);
  const [session, setSession] = useState("s1");
  const [draft, setDraft] = useState(null);
  const [chatTitle, setChatTitle] = useState(null);
  const openSession = (k) => { setSession(k); setChatTitle(null); setDraft(null); setRoute("chat"); };
  // Knowledge v2 hands corrections/questions to chat: onAsk(draft, sessionTitle?)
  const ask = (text, sessionTitle) => { const s = sessionTitle && SESSIONS.find((x) => x.title === sessionTitle); setSession(s ? s.key : session); setChatTitle(s ? null : sessionTitle || null); setDraft(text || ""); setRoute("chat"); };
  const title = chatTitle || (SESSIONS.find((s) => s.key === session) || SESSIONS[0]).title;
  const chat = route === "chat" || route === "home";
  return (
    <Shell route={route} onNavigate={setRoute} activeSession={session} onOpenSession={openSession} chat={chat}>
      {chat ? <ChatScreen key={session + (chatTitle || "") + (draft || "")} sessionTitle={route === "home" ? "Home" : title} draft={draft || ""} /> : null}
      {route === "sessions" ? <SessionsScreen onOpen={() => openSession("s1")} /> : null}
      {route === "plugins" ? <PluginsScreen /> : null}
      {route === "knowledge" ? (knowledgeVersion === 1 ? <KnowledgeScreen /> : knowledgeVersion === 2 ? <KnowledgeV2Screen onAsk={ask} /> : knowledgeVersion === 4 ? <KnowledgeV4Screen onAsk={ask} /> : <KnowledgeV3Screen onAsk={ask} />) : null}
      {!chat && route !== "sessions" && route !== "plugins" && route !== "knowledge" ? <div style={{ maxWidth: 760, margin: "40px auto" }}><Callout tone="info" icon="info">The <b style={{ textTransform: "capitalize" }}>{route}</b> page is not part of this kit yet — Chat, Sessions, Plugins and Knowledge are recreated from source.</Callout></div> : null}
    </Shell>
  );
}
