---
name: openclaw-design
description: Use this skill to generate well-branded interfaces and assets for OpenClaw (Control UI, dark claw theme), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key rules for OpenClaw Control UI work:
- Dark first. Base #0e1015, card #161920, elevated #191c24. Tokens in tokens/colors.css mirror ui/src/styles/base.css — use them, never hardcode.
- Accent #ff5c5c is for text/indicators; filled buttons use --primary #d13c3c with white text. One primary button per view.
- Settings language: uppercase eyebrow heading + ONE card group of rows; status is dot + text, never a pill.
- Instrument Sans for UI, JetBrains Mono for keys/values. Lucide-style stroke icons from assets/icons — never draw your own.
- Motion: 100/180/300ms with --ease-out; everything respects prefers-reduced-motion.
