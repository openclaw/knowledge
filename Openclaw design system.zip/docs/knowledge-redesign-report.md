# Knowledge Control UI redesign: required changes

**For:** the agent implementing the `knowledge` plugin
**Date:** 2026-09-23
**Design reference:** `ui_kits/control-ui/knowledge-v2.html` (the redesign) and `ui_kits/control-ui/knowledge.html` (the current page, reproduced as shipped). The screen source is `ui_kits/control-ui/KnowledgeV2Screen.jsx`.

This report is based on the plugin source (`src/control-ui.ts`, `ontology-view.ts`, `retrieval-view.ts`, `evidence-view.ts`), the docs (`README.md`, `KNOWLEDGE_SCOPE.md`, `KNOWLEDGE_SPEC.md`), the ontology file (`knowledge-default.yaml`) and the OpenClaw host (`ui/src/plugins/*`, `src/plugin-sdk/control-ui.ts`) as of 2026-09-23. Please check the claims about the current state against HEAD before acting on them.

---

## 1. Context and design intent

### Who uses it and for what

The product owner confirmed these inputs:

- **Scale:** real vaults hold thousands of records, not tens.
- **Main job:** *checking what the agent has saved*. Curating by hand matters less.
- **How knowledge gets in:** chat only, for now. The UI adds nothing directly. Corrections and new information go through the agent.

### Problems with the current page

The current page is a good inspector for developers but a poor product for end users:

- It leads with storage concepts: page, claim or relationship; raw Markdown; SHA-256 hashes; revision numbers.
- One question ("what do I know about X?") is split across Records, Search and Ontology.
- Every control is the same bordered button, so nothing stands out.
- It uses its own styling instead of Control UI's.

### What the redesign does

1. **Recent is the default view.** It's a feed of what the agent saved, grouped by the conversation it came from. It has a "Needs a look" section for unidentified people and for claims the agent inferred with no source.
2. **People and things come first.** People, projects and companies get a page that combines:
   - a summary;
   - claims grouped by type (decisions, commitments, preferences, facts, opinions);
   - typed connections in both directions;
   - the conversations the record was learned in;
   - a collapsed "File details" section (path, ID, revision, Git).
3. **Evidence is the trust signal.** Every claim shows where it came from: *From source*, *You told Molty*, or *Molty inferred*. Expanding a claim shows the quote, who said it, the file and line range, and whether the original is retained. Inferred claims say explicitly that they have no quoted source.
4. **One search box.** Names and aliases match as you type, with "Search all text" below.
5. **Browse is built for thousands of records.**
   - The type filter comes from the ontology, with counts, and empty types are hidden.
   - A switch toggles between pages and claims.
   - The table sorts by last saved and shows claim and connection counts plus the conversation each record was learned in.
   - Pagination labels the list as complete. It's still an exhaustive list, kept distinct from ranked search.
6. **Chat is the only way to change things.** "Correct in chat", "Tell Molty who", "Ask Molty" and "Open conversation" all hand off to Chat, with a message pre-filled where relevant.
7. **Host styling.** The page uses Control UI's page header, tabs, settings sections, data table, chips and status dots.
8. **The ontology moves.** It's no longer a main tab. Its categories become the Browse filter, and the full vocabulary view becomes a secondary page (not designed yet).

---

## 2. Already supported (no change needed)

- Claim type (`claim_kind`), attribution and where a claim came from (`assertion_origin`: source, user or inferred) in the record format.
- Evidence references: path, sha256, start and end line, quote, the `verified` flag, and chunked download of originals.
- Aliases, typed fields and field labels from the ontology.
- Per-type `recordCount` from `ontology`, which the Browse type filter uses.
- Lifecycle, revision, hash, path and raw file views, which "File details" uses.
- Git state per saved change (committed, pending or unavailable).
- Live refresh: the `changed` event plus a 30-second resync.
- `records` with `query`, `kind`, `type`, `offset`, `limit` and `total`.

---

## 3. Record format changes

### 3.1 Unidentified mentions

**Why:** the "Needs a look" section and the entity-page banner ("'Sam' spoke in this meeting but isn't linked to anyone") need to query unidentified people. `KNOWLEDGE_SCOPE.md` §3 says unresolved identities "remain explicit through attribution and evidence", but nothing stores them as data today.

**Proposal:** an optional frontmatter field on pages (especially meetings) and on claims:

```yaml
unresolved_mentions:
  - label: Sam
    kind_hint: person          # optional, from the ontology
    evidence:
      - path: artifacts/standup-2026-09-22.txt
        sha256: …
        start_line: 14
        end_line: 14
```

- Keep it portable, so it can be rebuilt without an LLM.
- Resolving a mention (the agent links "Sam" to a person) removes the entry and adds an `entities` reference or relationship. This is an ordinary edit with a receipt, not an approval step.
- Diagnostics should count unresolved mentions separately from validation issues. They aren't errors.

### 3.2 Which conversation a save came from

**Why:** the Recent feed groups saves by conversation, and each record shows "Learned in…". `KNOWLEDGE_SPEC.md` §6.3 already specifies host-attached origin ("actor, agent, conversation, session/run identity when available, and storage time"). The receipts and history entries the UI receives today have no conversation identity.

**Proposal:**
- Record `origin: { actor, agentId, sessionKey?, runId?, requestId }` on every save's receipt and history entry, taken from **trusted host context only**, never from arguments the model supplies.
- Store this in SQLite operational state, not in the portable frontmatter: it's provenance of the operation, not of the knowledge. Optionally, write `learned_in: [sessionKey…]` into frontmatter if portability of this link matters.
- Edits made outside OpenClaw and detected by the scan get `actor: external`, and the feed groups them as "Edited outside OpenClaw".
- Access: a conversation-scoped save must only surface to callers authorized for that conversation. That applies to lists, counts and "Learned in" alike.

---

## 4. New or extended backend operations

All of these are typed operations shared by the UI and agent tools, with the same access checks. Filtering must happen before counting, ranking and paging (spec §5).

### 4.1 `recent`: history grouped for the feed

Input: `{ since?, until?, limit, cursor? }`. Output: groups ordered by time:

```ts
{
  groups: Array<{
    origin: { sessionKey?: string; actor: "agent" | "operator" | "external"; runId?: string };
    batchId?: string;            // e.g. one ingestion or one request
    at: string; lastAt: string;
    items: Array<{
      change: "created" | "updated" | "withdrawn" | "superseded";
      record: RecordSummary;     // see 4.3
      note?: string;             // e.g. "Added alias 'Mario'"
    }>;
    unresolved: UnresolvedMention[];
  }>;
  nextCursor: string | null;
}
```

- `created` means revision 1, and `updated` means revision above 1. A short machine-generated change note (fields or aliases touched) is useful but optional.
- The UI turns `sessionKey` into a conversation title with `host.sessions.rows` / `observe`. The plugin doesn't store titles.
- Relationship saves in one batch can be collapsed in the UI ("Mario, Lena and Dev attended"). The operation should return them individually.

### 4.2 `entity`: combined view of one page

This is the spec's proposed `knowledge_entity` (§6.2), scoped to what the page needs. Input: `{ id, claimLimit?, claimCursor?, linkLimit?, linkCursor? }`.

```ts
{
  record: RecordSummary & { aliases: string[]; fields: Array<{ name; label; value }>; body: string };
  claims: {                    // claims whose `entities` include this id
    byKind: Record<ClaimKind, number>;
    items: ClaimSummary[];     // includes claim_kind, assertion_origin, attribution, evidence count, first evidence excerpt
    nextCursor: string | null;
  };
  links: {                     // one hop only (spec §4.5)
    items: Array<{ direction: "out" | "in"; label: string; relationshipId?: string; derived: boolean; target: RecordSummary }>;
    nextCursor: string | null;
  };
  learnedIn: Array<{ sessionKey: string; lastAt: string; count: number }>;
  unresolved: UnresolvedMention[];
}
```

- Needs a **reverse index** from `claim.entities` (and `dependencies`) to claims. This is a projection that can be rebuilt in SQLite.
- `links` must keep typed, evidenced relationships (`derived: false`) separate from links that only come from wikilinks (`derived: true`). Removing a wikilink must not remove a typed relationship (scope §3.2).
- Relationship labels in both directions: the ontology currently defines one label per relationship ("Leads"). The UI needs the reverse wording too ("Led by"). See 5.1.
- Missing or ambiguous IDs return the same response as today's `record`, so nothing reveals that a hidden record exists.

### 4.3 Richer record summaries and `records` extensions

Extend `RecordSummary`, returned by `records`, `recent` and `entity`:

```ts
{ id, kind, type, title, lifecycle, valid,
  updatedAt, recordedAt,
  claimCount?, linkCount?,      // pages only; counts respect access
  lastLearnedIn?: string,       // sessionKey
  origin?: AssertionOrigin, claimKind?: ClaimKind }  // claims only
```

Extend `records` input:

- `sort: "updated" | "title" | "claims"` plus `dir`. The default for the UI is `updated desc`.
- `claimKind?`, `assertionOrigin?`, `learnedIn?` (sessionKey), `updatedSince?`.
- **Stable paging:** return and accept a `snapshot` token, as `grep` already does, so paging through thousands of records doesn't skip or repeat rows while the agent writes. If the snapshot has expired, return an explicit message saying so.
- Keep the "complete list" guarantee separate from ranked search, and keep the label that says which is which.

### 4.4 Type-ahead search

`lookup` only does exact matches. Add a `mode: "prefix"` (or a separate `suggest`) over titles and aliases:

- Input: `{ query, limit ≤ 10 }`. Output: `RecordSummary[]` with `claimCount`, plus whether the match was on the title or an alias.
- Must be cheap enough to run on every keystroke with a short debounce. An FTS5 prefix query on the title and alias columns is enough.
- Same access filtering. Never suggest hidden records.

### 4.5 "Needs a look" totals

Add to `status` (or a new `attention` operation) counts the UI can show without loading everything:

```ts
attention: {
  unresolvedMentions: number;
  inferredClaimsRecent: number;   // assertion_origin = inferred, recently saved
  unverifiedEvidence: number;     // evidence refs whose original can't be verified
  indexPending: number;           // saved but not yet searchable
  conflicts: number;
}
```

Each count should map to a filter on `records` or `recent`, so the UI can link through.

### 4.6 Corrections (already the next milestone)

The "Correct in chat" flow depends on the supersede and withdraw work in `KNOWLEDGE_SCOPE.md` §6. Nothing new is asked here beyond:

- The UI shows superseded and withdrawn claims with their replacement or reason in the entity view's history.
- Withdrawn claims must drop out of `entity.claims`, `recent` (as active items) and every count.

---

## 5. Ontology changes

### 5.1 Reverse relationship labels

Add an optional `inverse_label` to relationship definitions:

```yaml
- name: leads
  label: Leads
  inverse_label: Led by
```

Where it's missing, the UI falls back to "← Leads". This is a display hint only, which the spec allows ("optional display hints limited to labels").

### 5.2 Nothing else required

Browse uses the existing `primitive` categories and `recordCount`. The ontology atlas page stays, reachable from the page header, not as a main tab.

---

## 6. OpenClaw host / plugin API changes (outside the plugin)

These live in the OpenClaw repo (`src/plugin-sdk/control-ui.ts`, `ui/src/plugins/*`) and need an owner there.

### 6.1 Opening chat with a message pre-filled (**blocking for the chat hand-off**)

Today a plugin page can open a conversation (`host.sessions.open({ sessionKey, agentId })`) or create one (`host.sessions.create`). It **cannot** put text into the main chat box. Only a plugin that fully replaces the chat box gets `setDraft`.

Proposal:

```ts
host.sessions.open({ sessionKey, agentId, draft?: string, context?: ControlUiChatContext })
host.chat.compose({ agentId?, sessionKey?, text, context?: ControlUiChatContext })  // new session if no key

type ControlUiChatContext = {
  pluginId: string;
  references: Array<{ kind: "knowledge-record" | "knowledge-claim"; id: string; revision?: number; label: string }>;
};
```

- The draft is **only a pre-fill**: the user still reviews and sends it. Nothing is sent automatically.
- Structured `references` let the agent act on the exact claim or record ID and revision, instead of re-identifying it from quoted text. Show them as removable chips in the chat box.
- Uses: "Correct in chat" (claim reference), "Tell Molty who" (unresolved mention plus meeting reference), "Ask Molty about X" (record reference), "Open conversation" (session only).

### 6.2 Stable styling contract for plugin pages

Plugin pages mount in the regular DOM (`OpenClawLightDomContentsElement`), so host classes (`.btn`, `.chip`, `.settings-section`, `.data-table`, …) and CSS variables currently reach plugin markup. That's incidental, not a contract. Choose one:

- (a) Document a small, versioned set of host classes and tokens plugins may rely on; or
- (b) Add components to `host.components`: button, chip, status dot, section and row, data table with pagination, search input, empty state.

`host.components` currently offers: agent avatar, appearance picker and glyph, dialog, agent picker, select picker, session summary, dashboard.

### 6.3 Sidebar icon

The plugin registers navigation with `icon: "bookOpen"`, which isn't in `ui/src/components/icons.ts` (`book` is). Either add `bookOpen` to the host set or change the plugin to `book`. This is a bug today.

### 6.4 Plugin access to host icons (nice to have)

The redesign uses host glyphs for type tiles, claim types and origin marks. Expose `host.icons.render(name, opts)` or equivalent, so plugins don't have to bundle their own copy of Lucide.

---

## 7. Agent skill changes

- **`knowledge-correct`** (planned, not shipped): accept a structured claim reference (from 6.1) as the primary input. Confirm the target revision before superseding or withdrawing. Reply with the receipt.
- **`knowledge-entities`**: handle "X is Y" resolutions of unresolved mentions. Remove the mention (3.1), add the entity reference or relationship, and report what changed.
- **Ingestion skills** (`knowledge-ingest`, `knowledge-meeting-ingest`): write `unresolved_mentions` instead of dropping unmatched names or burying them in prose.

---

## 8. Suggested order

| # | Change | Unlocks |
|---|---|---|
| 1 | 3.2 conversation origin on saves | Recent feed grouping, "Learned in", "Open conversation" |
| 2 | 6.1 pre-filled chat (host) | Every chat hand-off action |
| 3 | 4.3 richer summaries + `records` sort/filter/snapshot | Browse at scale |
| 4 | 4.1 `recent` | Default Recent view |
| 5 | 4.2 `entity` + reverse claim index + 5.1 reverse labels | Entity pages |
| 6 | 3.1 unresolved mentions + 4.5 attention counts + skill updates | "Needs a look" |
| 7 | 4.4 type-ahead search | Search box suggestions |
| 8 | 6.2 styling contract, 6.3 icon fix, 6.4 icons | Visual consistency |
| — | 4.6 corrections | Already the next backend milestone. "Correct in chat" depends on it. |

Items 1–3 are prerequisites. Everything else can be done in parallel once they land.

---

## 9. Invariants to keep

- **Access:** hidden records must not leak through feed groups, "Learned in", counts, suggestions, backlinks or attention totals.
- **Ranked vs complete:** Browse is exhaustive and labelled as such. Search and type-ahead are ranked and labelled as such.
- **Saved vs searchable:** a save that isn't searchable yet stays visible in `recent` and `entity`. `indexPending` reports the gap.
- **No approval step:** unresolved mentions and inferred claims are shown, not held back.
- **The browser never writes:** every change the UI starts goes through chat and the agent's tools (for now), then through the shared service.

---

## 10. Open questions

1. Should `learned_in` be written to portable frontmatter, or live only in operational state?
2. How far back does `recent` go by default, and how is history before the conversation-origin field existed (3.2) shown?
3. Should the summary paragraph on an entity page be the page's Markdown body (rendered safely), or a separate field the agent maintains?
4. Where does the ontology atlas live: a second registered page, a dialog, or a Browse sub-view?
