# Knowledge v4: UI changes for implementation

Date: 2026-09-23
Design reference: `ui_kits/control-ui/knowledge-v4.html` → `KnowledgeV4Screen.jsx`
Responds to: `docs/DESIGN_HANDOFF.md`, `docs/FEEDBACK_IMPLEMENTATION.md`, `docs/UI_REDESIGN_IMPLEMENTATION.md`

This document lists what the shipped Control UI (`src/control-ui.ts` + `control-ui.css`) must change to match v4. Each item names the data it reads, the exact copy, and the fallback when the field is absent. Everything is read-only; no item adds a browser write.

Rule for every item: **feature-detect the field. If it's absent, render the fallback. Never infer it from titles, prose, timestamps or feed proximity.**

The prototype's fixture data (Priya Raman, Hexline, etc.) and its "Review fixtures" panel are design aids. Don't ship either.

---

## 0. Shared primitives

Build these once and use them everywhere below.

### 0.1 Origin label (`assertionOrigin`)

| Value | Icon | Copy | Color |
|---|---|---|---|
| `source` | `paperclip` | From source | `--muted` |
| `user_belief` | `messageSquare` | Statement by {speaker} | `--accent-2` |
| `agent_inference` | `spark` | Molty inferred | `--warn` |
| absent/unknown | `circleQuestionMark` | Origin not recorded | `--muted` |

- `{speaker}` comes from evidence attribution. Use "You" **only** if the host confirms the speaker is the current viewer. Otherwise, if the speaker is unknown, use "Statement by an unidentified user".
- Remove the v3 strings "You told Molty" and "No quoted source".

### 0.2 Attribution confidence (`attribution_confidence`)

- Render a 3-bar meter plus a level word. Use "{Level} attribution confidence" in evidence captions and "{Level}" alone in compact rows (attendee lists, connections rail).
- Put `basis` in a tooltip in compact rows and as visible text in attendee lists.
- Absent: show the `circleQuestionMark` icon with "Attribution confidence not recorded" (compact: "Confidence not recorded").
- **Never** style a missing value as low, and never place confidence next to origin as if it were a truth score.

### 0.3 Identity tag (`identity`)

- `status: partial` shows a neutral tag with the `shieldQuestion` icon and the text "Identity unresolved".
- If the record *explicitly* notes an unresolved surname, the tag reads "Surname unresolved" instead. Don't derive this from the name's shape; a handle can be a complete identity.
- `status: resolved` or absent: no tag.
- The tag appears next to the title in: feed rows, Browse table, attendee lists, search results and the entity header.

### 0.4 Claim kinds

Add `event` (`calendarClock`, "Event" / "Events") to the kind map. Rename the `belief` label from "Opinion" to "Belief". Kind groups, facets and counts list only kinds that have at least one current claim.

### 0.5 Time

- **Occurred** comes from `occurred_at` or the meeting's recorded span. Show it with the timezone: "Wed, Sep 23, 2026 · 9:00–9:32 AM PDT".
- If the stored UTC date differs from the local date, add a muted second line: "Stored as 2026-09-23 01:30–02:08 UTC".
- A date-only value keeps its date with no time, followed by the tag "Date only · no time recorded". Never render midnight.
- **Saved** is the operation time from `recent`. Always label it "Saved {time} {TZ}". Recent's day headers say "· saved times in PDT" (the viewer's zone).
- **Updated** (`updatedAt`) is secondary. It appears only in Browse's "Last updated" column and in File details.
- Keep titles verbatim. Do not strip "— 2026-09-23" or any other text from titles.

---

## 1. Recent

### 1.1 Structure per day

```
{Day} · {date} · saved times in PDT
[Corrections & withdrawals · N]     ← only if the day has lifecycle events
[Source group] …                    ← one card per explicit source
[Edited outside OpenClaw]           ← external observations
[Saved in conversation]             ← records with no source page
Load older activity
```

Call `recent({ groupBySource: true })`. Grouping and totals come from the server, before pagination. The client must not group rows by timestamp.

### 1.2 Source group card (`source_page`)

- **Header row (clickable, toggles expand):**
  - 32px type tile.
  - Source page title.
  - "Occurred {date · time TZ}". This line is omitted when the source has no occurrence time.
  - "Saved {first/last time} · {N} records".
  - A summary line of kind counts in this order: attended → decisions → commitments → events → beliefs → facts → preferences → pages. For example: "5 attended · 3 commitments · 1 decision · 2 beliefs · 4 pages · meeting event".
- **Default state:** the newest group of the first day is expanded; all others are collapsed.
- **Rows when expanded:**
  1. Page saves: tile, title, identity tag, change label, type, and occurred date for meetings/events.
  2. One attendance row (§1.3).
  3. Claim rows (§3).
- **Meeting event claim:** a claim with `source_event: true` whose `source_page` is this group's page is **not** its own row. It adds "meeting event" to the summary line. Keep the claim in the data; it still powers entity timelines.
- **Group names:** the product copy says "source group". Never use "import", "ingest", "batch" or "job".
- Continuation: when a group spans pages, show "Load N more from this source" at the end of the group.

Change labels:

| Change | Icon | Copy |
|---|---|---|
| `created` | `plus` (accent) | New |
| `updated` | `pencil` | Updated |
| `observed` | `eye` | Observed in vault |
| external | group header | Edited outside OpenClaw · "Change found in the vault files" |

Don't show "New" for `observed`. The live screenshot currently shows New on every row; switch to the change type the server returns.

### 1.3 Attendance row

- **Collapsed:** "{A}, {B}, {C} and {n} more attended", with the sub-line "{N} attendance connections · each with its own attribution".
- **Expanded:** a nested list with one line per person: tile, name, identity tag, attribution basis, and a compact confidence meter. Clicking a line opens that person.
- Build it only from `attended` relationships to this source page. An entity linked to a meeting event is **not** attendance.

### 1.4 Corrections & withdrawals block

This is its own card, kept separate from source groups.

- **Row:**
  - `repeat` (info) or `archive` (muted) icon.
  - The record's **current** saved title. For a withdrawn record, use its saved title.
  - The meta line: Corrected or Withdrawn, then the kind, then "{time} {TZ}".
- **No strikethrough and no old assertion body in the feed.** Delete v3's inline struck-through previous text and its struck-through withdrawn lines.
- **Expanded:**
  - A plain-language effect sentence, one per case:
    - Corrected: "This replaced an earlier version. {reason} Search and answers now use the current version."
    - Withdrawn: "{reason} It no longer appears in connections, search or answers. The original and its evidence are kept in history."
  - A "Recorded reason" disclosure, collapsed by default, holding the verbatim audit reason in mono.
  - Buttons: "Current version" (corrected) or "Open {entity}" (withdrawn relationship), plus a ghost "View in history" button.
- Consecutive withdrawals are **not** merged into "N withdrawn" any more (a v3 behaviour). Each lifecycle event is one row; the block header carries the count.

### 1.5 Remove from v3

- The "Needs a look" section. Bring it back only when `attention()` ships, and only with server totals.
- The All / Saved / Corrections filter. Lifecycle events are now visually separate.
- The "Updated 2×" client-side merge.

### 1.6 Live refresh (§10 of the design handoff)

- An idle poll changes nothing on screen.
- A real change on the first page shows a centered pill above the day list: "↑ 1 new save · Show" (pluralize for N). Pressing Show inserts the rows. Never shift content while the user is reading.
- Expanded source groups, claim rows, evidence and open disclosures must survive both cases.
- On disconnect:
  - Header status reads "Reconnecting…" (`StatusDot` warn).
  - A warn banner appears above the content: "**Can't reach the vault.** Showing the last readable view, checked at {time TZ}. Retrying."
  - Keep the last view readable.
- The "Live" status tooltip reads "Checked {relative time}".

---

## 2. Search

- Keep the label "Exact matches" while the backend returns exact identity matches. Switch to "Suggestions" only when `suggest()` ships prefix ranking.
- No match: "No page is named exactly "{q}"."
- The last row reads "Search all text for "{q}" · ranked".
- Result rows show the identity tag and drop the claim count, since summaries don't carry it yet.

---

## 3. Claim row (feed, entity, Browse › Claims)

**Collapsed meta line, in order:**
1. Optional state note ("Corrected", info tone, only on a current record that has `supersedes`).
2. Kind label.
3. Origin (§0.1).
4. For commitments: "Owner {name}", or "Owner not identified" when there's no structured owner.
5. "About {up to 2 links}". Hidden on an entity page when the claim is only about that entity.
6. The continuity hint: "Conflicting account" (`arrowLeftRight`) if any `contradicts` relation exists, otherwise "Reaffirmed" (`link`) if any relation exists.
7. "Source file unavailable" (`alertTriangle`, warn) if any cited file fails verification.

There's no relative time in the collapsed row; it appears in the expanded Details as "Saved".

**Expanded, in order:**

1. **Details grid** (72px label column):
   - Owner: a link or "Owner not identified". Commitments only.
   - Deadline: the date, or "No deadline recorded". Commitments only; never show "overdue" or any task status.
   - Source: a link to `source_page`. Fallbacks: "Source page not recorded", or for `user_belief` "Conversation not recorded".
   - About: links.
   - Saved: "{saved time TZ} · revision {n}".
2. **Evidence** (§4).
3. **Related statements** (`continuity`, §3.1).
4. **Actions:**
   - "Open claim".
   - "Original file" (download; only when a verified file exists).
   - Ghost "Correct in chat", which opens the hand-off (§7).
   - Remove v3's "View original". History is reached from the claim page.

### 3.1 Related statements (`continuity`)

- Render outgoing relations and computed incoming relations.
- Each is a bordered row: icon, relation label, the other claim's text, `basis` + "From {source title}.", and a ghost "Open" button.

| relation | outgoing label | incoming label | icon |
|---|---|---|---|
| `reaffirms` | Reaffirms | Reaffirmed by | `check` |
| `updates` | Updates | Updated by | `arrowRight` |
| `contradicts` | Conflicts with | Conflicts with | `arrowLeftRight` |

- Continuity must **not** look like supersession: no strikethrough, no "Replaced", no lifecycle colour.
- Both sides of a conflict stay visible with their own attribution. There's no "resolve" action.

---

## 4. Evidence

### 4.1 Excerpt block (one per citation)

- **Top line:**
  - An uppercase label: `EXCERPT`, `PREMISE · EXCERPT` (for agent inference), or `CHAT MESSAGE`.
  - Mono "{filename} · lines {a–b}".
  - "Truncated" when the preview is cut off.
- **Body:** the excerpt text in quotes. A stored `quote` is optional; line-derived excerpts use the same block.
- **Caption:**
  - Speaker. When the recorder label and resolved identity differ: `recorder label "{label}" → {who}`. When unresolved: `recorder label "{label}" · not identified`. When they're the same: `{who}`.
  - Attribution confidence (§0.2).
  - `badgeCheck` "File verified" (`--ok`). This means the file and locator were checked, **not** that the claim is true.
- **Failed or missing file:**
  - Replace the whole block with a bordered box: `alertTriangle` "Source file unavailable" (warn), the failure message, then mono "{filename} · lines {a–b}".
  - Keep the citation visible. Don't hide it.

### 4.2 Grouping and counts

- Group citations under their file, keeping every locator and attribution separate.
- Collapse only exact duplicate citations.
- When there's more than one citation or file, show above the list: "{N} citations · {M} files".
- For `agent_inference`, add a warn-tint box above the premises: "**No direct quote for this inference.** {reason} Premises below."
- An original export and its derived transcript are two files. Never merge them.

---

## 5. Entity page

### 5.1 Header

- **Title** row.
- **Occurred line** (meetings and events), 14px, `--text-strong`, `calendarClock` icon, using §0.5 formatting including the UTC note and the date-only tag.
- **Meta line:**
  - Type.
  - Identity tag.
  - "Context {identity.context}".
  - For people: "Known from {N} meeting(s)", counted from attendance relationships.
- **Context disclaimer:** when `identity.context` exists on a person, add a muted line: ""{context}" is how the source describes them. It isn't recorded as a role or employer."
- **Fields:** render only fields that are present. No empty Role/Employer placeholders; omit rather than write "Not recorded".
- Keep "Ask Molty"; it now opens the hand-off (§7).

### 5.2 Possible match card (`identity.candidates[]`)

Show one card per candidate, below the header:

- `shieldQuestion` icon and "Possible match: {candidate title (link)}".
- The candidate's `basis`.
- A muted line: "Both records stay separate unless Molty finds evidence they're the same person."
- A button, "Ask Molty to check", which opens the hand-off with `kind: identity` (§7).
- The candidate's evidence as an excerpt block (§4.1), indented.

No merge button, dialog or confirmation step.

### 5.3 Main column

1. **Body** as safe Markdown (paragraphs for now), with "Written by Molty · updated {updated} · revision {n}".
2. **Meetings only: "Attended".**
   - Heading: "Attended · {N} people · from attendance connections".
   - Rows: tile, name, identity tag, basis (fallback "No attribution basis recorded"), compact confidence.
   - Under the list, if a meeting event exists: "Also linked by the meeting event (not attendance): {links}".
3. **"What Molty knows · {N} claims"**, grouped by kind (§0.4).
   - A meeting page lists claims whose `source_page` is that meeting, excluding its `source_event` claim.
   - Every other type lists claims whose `entities` include the page.
   - Empty state: "No claims about {title}." For a person who has attendance but no claims, add " Only attendance is recorded."
4. **People only: "Commitments owned · {N} · owner only, not about {title}".** These are claims whose owner is this person but whose `entities` don't include them. Keep them out of the claims count.

Delete v3's inline "Show N withdrawn claims" on entity pages. Withdrawn content is reached only through History (§6).

### 5.4 Rail (300px, sticky)

- **Connections.** Each row: tile, a small label row with the relation and a compact confidence meter on the right, then the target title.
  - The relation label is the forward label, or "← {label}" for incoming until `inverse_label` ships.
  - Don't show withdrawn connections here.
- **Sources** (pages with evidence files):
  - Header: "{N} files · {M} citations from this meeting's claims".
  - Per file: mono name, "{role} · {size}", "{n} cited passages" or "Not cited directly", then "Original retained" (original exports) or "File verified" (derived files), plus a download icon button.
- **Learned in.** While trusted origin is unavailable, the whole section reads: "Conversation not recorded. Saved from meeting imports; the conversation that ran them isn't tracked yet." Never link to the currently open chat.
- **File details** (collapsed): ID, Revision, Hash, Updated, Lifecycle, plus "View Markdown" and "History" buttons.

---

## 6. Claim page and history

### 6.1 Claim page (current record)

In order:

- Breadcrumb "Knowledge › Claims".
- The kind eyebrow.
- The claim text as the title.
- The origin label.
- The Details grid (§3) in a surface.
- "Evidence" (§4).
- Related statements (§3.1).
- **Versions** (when `supersedes` or `replacedBy` exists): the heading "Versions {n}", then one row per revision showing mono "rev {n}", the text, and either "Current · saved {time}" or "Replaced {time}". The row being viewed is tinted and tagged "Viewing".
- Ghost "Correct in chat".

### 6.2 Historical record (superseded or withdrawn)

- Reached only by explicit navigation: "View in history", or a Versions row, or Browse with "Include history".
- **Banner:** `clock` icon and "Viewing history · Replaced {time}" or "Viewing history · Withdrawn {time}".
  - Body for a replaced record: "An earlier version. Search and answers use the current one." + reason.
  - Body for a withdrawn record: "Not used in search, connections or answers." + reason.
  - The banner carries a "Current version" button when one exists.
- The title is `--muted-strong`, **not** struck through. No "Correct in chat" button.

### 6.3 Withdrawn connection history

Breadcrumb "Knowledge › Connection history". Then:

- The banner.
- The eyebrow "Connection · {label}".
- The title.
- A From / To / Revision grid.
- "Recorded reason" in mono.

---

## 7. Chat hand-off (replaces pre-fill)

Every "Correct in chat", "Ask Molty" and "Ask Molty to check" button opens a modal. Nothing is sent or changed from it.

- **Title:**
  - correct: "Ask Molty to correct this"
  - ask: "Ask Molty"
  - identity: "Ask Molty to check this match"
- **Sub-line:** "Copy the request, open chat, paste it, then review and send. Nothing is sent or changed from here."
- **Body:** a read-only, select-all mono block holding the request text followed by the reference lines:
  ```
  Record: {title}
  ID: {id}
  Revision: {revision}
  Hash: {hash}
  Candidate: {candidate id}      ← identity only
  ```
- **Request text by kind:**
  - correct: "Please check this saved claim against its evidence and correct or withdraw it if the evidence supports that.\n\nWhat I think is wrong: "
  - ask: "What do you know about "{title}", and where did it come from?"
  - identity: "Is "{title}" the same person as "{candidate}"? Check the evidence on both pages. Link them only if it supports that; don't merge on the handle alone."
- **Helper line:** "The ID, revision and hash let Molty confirm it's looking at the same version you are."
- **Footer:**
  - "Cancel" (ghost).
  - "Copy request", which becomes "Copied" with a check icon.
  - "Open chat" (primary), which uses `sessions.open` / new chat and does **not** paste anything.
- A passive refresh must not close the modal or reset "Copied".
- When `host.chat.compose` ships, replace Copy + Open with a single "Open in chat" that composes a draft with reference chips. Keep the modal as the fallback.

---

## 8. Browse

### 8.1 Left rail

- **Pages mode:** "Everything" plus the ontology categories. Show only types with a count > 0, then "{N} empty types hidden".
- **Claims mode:** the rail becomes "Claim kinds": "All claims", then each kind with a current count > 0.
- **Origin note** under the list:
  - One origin: "All {N} claims are from sources."
  - Several: "{k} origins: {a} from sources, {b} user statement, {c} inferred."
  - Always end with: "Kinds with no claims are hidden."
- Show an origin filter control only when more than one origin exists.

### 8.2 Toolbar

- A filter input:
  - Pages and Connections: "Filter by name or alias".
  - Claims: "Filter claim text".
- `Segmented` **Pages | Claims | Connections**. Connections is new versus v3; the live UI already has it.
- `Segmented` **Current | Include history**, mapping to `records({ lifecycle: "all" })`.

### 8.3 Pages table

| Column | Content | Notes |
|---|---|---|
| Name | tile · title · identity tag | |
| Type | type label | |
| Occurred | meetings/events: "Wed, Sep 23 · 9:00 AM PDT"; date-only: "Thu, Oct 1 · date only"; others: "—" | new |
| Last updated | `updatedAt` with TZ | default sort desc |

- **Remove** the Status, Claims, Connections and Learned in columns. Add Claims and Connections back only when summaries return `claimCount`/`linkCount`.
- **Footer:**
  - Normally: "1–{n} of {total} · complete list".
  - With history included: "· including history".
  - Past the offset cap: "Showing the first 550 · partial browse", with Next disabled.

### 8.4 Claims list

- Current claims use the claim row (§3).
- With history included, inactive claims render as a muted row: kind icon, text (not struck through), "Replaced" or "Withdrawn", and the time. Clicking opens the historical record.

### 8.5 Connections list

- One row per relationship: from-tile, from-name, the muted label, to-tile, to-name, and a compact confidence meter on the right. Clicking opens the "from" endpoint.
- With history included, withdrawn connections show muted tiles, an `archive` "Withdrawn" label, and the time in place of confidence.
- Footer: "1–{n} of {total} connections · complete list".

---

## 9. Header

- The Browse tab badge shows the current eligible page count, excluding `record_class: fixture`.
- Status is "Live" (ok), or "Reconnecting…" (warn), or "Offline".
- A sample vault shows `Chip` "Sample vault" next to the status. It's never shown for a real vault.
- The vocabulary action keeps the `book` icon.

---

## 10. Acceptance checklist

The QA reference for each case is the prototype's Review panel target.

| # | Case | Must see |
|---|---|---|
| 1 | Handle-only person (`kestrel`) | Identity unresolved tag, context line + disclaimer, no Role field, "Known from 1 meeting", possible-match card with excerpt, no merge control |
| 2 | Commitment with owner, no deadline (`ci`); neither (`down`) | "Owner {name}" / "Owner not identified"; "No deadline recorded"; no task status |
| 3 | Source-only dataset | Claim kinds rail shows only present kinds; "All N claims are from sources."; no origin filter |
| 4 | Meeting with many attendance records | One source group with summary counts; one collapsible attendance row; the per-person list keeps confidence |
| 5 | One transcript, several ranges + original | Sources rail "2 files · N citations"; original shown as retained and not cited directly; claim shows "2 citations · 1 file" |
| 6 | Date-only event; evening meeting across UTC | "Thu, Oct 1, 2026" + Date only tag; PDT time + "Stored as … UTC" |
| 7 | Reaffirming pair; conflicting pair | "Reaffirms / Reaffirmed by" and "Conflicts with" rows, no strikethrough, both attributions kept |
| 8 | Corrected claim; withdrawn connection | One row each in Corrections & withdrawals; old text only in the history view; Versions list; connection history page |
| 9 | Missing file; unknown confidence | "Source file unavailable" block with locator; "Attribution confidence not recorded"; speaker "not identified" |
| 10 | Live refresh | Idle poll: nothing moves. Update: "1 new save · Show" pill; expanded rows and open hand-off persist. Disconnect: banner + last view kept |

## 11. Not in this pass

- A narrow/mobile layout. The existing 760/390px behaviour must still not overflow.
- The "Needs a look" section (waits for `attention()`).
- Conversation-grouped Recent and a working "Learned in" (wait for trusted origin).
- Claim and connection counts in Browse (wait for summary additions).
- Stable snapshot paging (the 550 cap stays and is labelled).
- Composing a draft with reference chips (waits for `host.chat.compose`).
