import React, { useState } from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { Button } from "../../components/core/Button.jsx";
import { IconButton } from "../../components/core/IconButton.jsx";
import { Chip } from "../../components/core/Chip.jsx";
import { Segmented } from "../../components/core/Segmented.jsx";
import { StatusDot } from "../../components/core/StatusDot.jsx";
import { PageHeader } from "../../components/settings/PageHeader.jsx";
import { HubTabs } from "../../components/navigation/HubTabs.jsx";
import { SettingsSection } from "../../components/settings/SettingsSection.jsx";
import { SettingsRow } from "../../components/settings/SettingsRow.jsx";
import { DataTable, PaginationButton } from "../../components/navigation/DataTable.jsx";
/* Knowledge — redesign proposal (v2). Job: "check what my agent saved". Entity-first; one search; evidence as the trust signal;
   corrections + new knowledge go through chat (onAsk). Host constraints (openclaw/ui/src/plugins): page mounts in light DOM, so host
   classes (.btn, .chip, .settings-section, .data-table) + CSS vars apply; host.components offers AgentAvatar, Dialog, SelectPicker,
   AgentPicker, SessionSummary; host.sessions.open() deep-links to the conversation a record was learned in. */
const T = {
  person: ["circleUser", "Person", "var(--accent-2)", "var(--accent-2-subtle)"],
  company: ["box", "Company", "var(--info)", "var(--info-subtle)"],
  project: ["kanban", "Project", "var(--ok)", "var(--ok-subtle)"],
  concept: ["spark", "Concept", "var(--warn)", "var(--warn-subtle)"],
  meeting: ["users", "Meeting", "var(--accent)", "var(--accent-subtle)"],
  email: ["mail", "Email", "var(--muted-strong)", "var(--bg-hover)"],
  source: ["paperclip", "Source", "var(--muted-strong)", "var(--bg-hover)"],
  note: ["fileText", "Note", "var(--muted-strong)", "var(--bg-hover)"],
};
const KIND = { decision: ["flag", "Decision", "Decisions"], commitment: ["listChecks", "Commitment", "Commitments"], preference: ["star", "Preference", "Preferences"], fact: ["info", "Fact", "Facts"], belief: ["brain", "Opinion", "Opinions"] };
const E = {
  mario: { type: "person", title: "Mario Ferrante", aliases: ["Mario"], fields: [["Role", "Infra lead, Northwind Labs"]], updated: "5h ago",
    summary: "Leads infrastructure at Northwind Labs and owns their side of the gateway auth migration. Reachable on iMessage for quick questions; prefers email for anything with a deadline.",
    links: [["Works at", "northwind"], ["Leads", "authproj"], ["Attended", "standup"]], learned: [["iMessage: Mario", "5h ago"], ["Team standup notes", "2h ago"], ["Refactor gateway auth", "Yesterday"]], path: "people/mario-ferrante.md", rev: 4 },
  lena: { type: "person", title: "Lena Park", aliases: [], fields: [["Role", "Product designer"]], updated: "2h ago", summary: "Designs the Control UI approval flows.", links: [["Attended", "standup"]], learned: [["Team standup notes", "2h ago"]], path: "people/lena-park.md", rev: 2 },
  dev: { type: "person", title: "Dev Shah", aliases: [], fields: [["Role", "Security reviewer"]], updated: "2h ago", summary: "Reviews auth-related changes before they merge.", links: [["Advises", "authproj"], ["Attended", "standup"]], learned: [["Team standup notes", "2h ago"]], path: "people/dev-shah.md", rev: 1 },
  northwind: { type: "company", title: "Northwind Labs", aliases: ["Northwind"], fields: [], updated: "3d ago", summary: "Runs a self-hosted OpenClaw gateway for their ops team.", links: [["Employs", "mario"]], learned: [["Refactor gateway auth", "3d ago"]], path: "companies/northwind-labs.md", rev: 3 },
  authproj: { type: "project", title: "Gateway auth refactor", aliases: ["auth migration"], fields: [["Status", "Active"]], updated: "2h ago", summary: "Moving gateway credentials out of config files and into the OS keychain, without breaking existing installs.", links: [["Led by", "mario"], ["Reviewed by", "dev"], ["Relates to", "release"], ["About", "keychain"]], learned: [["Refactor gateway auth", "Yesterday"], ["Team standup notes", "2h ago"]], path: "projects/gateway-auth-refactor.md", rev: 6 },
  release: { type: "project", title: "2026.9 release", aliases: [], fields: [["Status", "Active"]], updated: "2h ago", summary: "September release train.", links: [["Relates to", "authproj"]], learned: [["Team standup notes", "2h ago"]], path: "projects/2026-9-release.md", rev: 9 },
  standup: { type: "meeting", title: "Team standup — Sep 22", aliases: [], fields: [["When", "Sep 22, 09:30"]], updated: "2h ago", summary: "Weekly standup. Agreed on keychain storage and dropping the legacy token fallback for 2026.9.", links: [["Attended by", "mario"], ["Attended by", "lena"], ["Attended by", "dev"]], learned: [["Team standup notes", "2h ago"]], path: "meetings/2026-09-22-standup.md", rev: 1, unresolved: "Sam" },
  keychain: { type: "concept", title: "OS keychain token storage", aliases: [], fields: [], updated: "Yesterday", summary: "Keeping secrets in the platform keychain; config files hold only a reference.", links: [["Discussed in", "authproj"]], learned: [["Refactor gateway auth", "Yesterday"]], path: "concepts/os-keychain-token-storage.md", rev: 1 },
};
const STANDUP = "standup-2026-09-22.txt";
const C = [
  { id: "c1", kind: "decision", text: "Gateway tokens move to the OS keychain; config files keep only a reference.", origin: "source", about: ["authproj", "keychain"], from: "Team standup notes", when: "2h ago", quote: "OK so we agreed — tokens go in the keychain, config only keeps a pointer.", speaker: "Mario Ferrante", file: STANDUP, lines: "41–43" },
  { id: "c2", kind: "commitment", text: "Mario will send the auth migration plan by Friday, Sep 26.", origin: "source", about: ["mario", "authproj"], from: "iMessage: Mario", when: "5h ago", quote: "I’ll get you the migration plan by Friday.", speaker: "Mario Ferrante", file: "imessage-mario-2026-09-23.txt", lines: "12" },
  { id: "c3", kind: "preference", text: "Mario prefers email for anything with a deadline.", origin: "user", about: ["mario"], from: "Refactor gateway auth", when: "Yesterday", quote: "Btw Mario hates deadline stuff over iMessage, email him for those.", speaker: "You" },
  { id: "c4", kind: "fact", text: "Northwind Labs runs its gateway behind a Cloudflare tunnel.", origin: "inferred", about: ["northwind"], from: "Refactor gateway auth", when: "Yesterday", reason: "Inferred from cf-connecting-ip headers in gateway logs Mario shared." },
  { id: "c5", kind: "decision", text: "Ship 2026.9 without the legacy token fallback.", origin: "source", about: ["release", "authproj"], from: "Team standup notes", when: "2h ago", quote: "Let’s just drop the fallback for .9, nobody’s on the old format.", speaker: "Mario Ferrante", file: STANDUP, lines: "58–60" },
  { id: "c6", kind: "fact", text: "Dev Shah reviews all auth-related changes before merge.", origin: "source", about: ["dev", "authproj"], from: "Team standup notes", when: "2h ago", quote: "Anything touching auth goes through me first.", speaker: "Dev Shah", file: STANDUP, lines: "71" },
  { id: "c7", kind: "belief", text: "Lena thinks the approval dialog is too dense on mobile.", origin: "source", about: ["lena"], from: "Team standup notes", when: "2h ago", quote: "On a phone the approval sheet is a wall of text.", speaker: "Lena Park", file: STANDUP, lines: "88–89" },
];
const FEED = [
  { day: "Today", groups: [
    { session: "Team standup notes", when: "2h ago", note: "Meeting transcript", items: [["new", "standup"], ["claim", "c1"], ["claim", "c5"], ["claim", "c6"], ["claim", "c7"], ["new", "dev"], ["link", "Mario Ferrante, Lena Park and Dev Shah attended"], ["unresolved", "“Sam” couldn’t be matched to a person"]] },
    { session: "iMessage: Mario", when: "5h ago", items: [["claim", "c2"], ["updated", "mario", "Added alias “Mario”"]] },
  ] },
  { day: "Yesterday", groups: [
    { session: "Refactor gateway auth", when: "Yesterday, 16:12", items: [["new", "authproj"], ["new", "keychain"], ["claim", "c3"], ["claim", "c4"]] },
  ] },
];
const FACETS = [
  ["People & things", [["person", "People", 412], ["company", "Companies", 138]]],
  ["Ideas & projects", [["project", "Projects", 64], ["concept", "Concepts", 221], ["note", "Notes", 380]]],
  ["Sources & writing", [["source", "Sources", 190], ["media", "Media", 96], ["writing", "Writing", 22]]],
  ["Events & conversations", [["meeting", "Meetings", 311], ["email", "Email", 244], ["slack", "Slack", 104], ["conversation", "Conversations", 128], ["event", "Events", 57], ["deal", "Deals", 18], ["diary", "Diary", 20]]],
  ["Annotations", [["atom", "Atoms", 13]]],
];
const MORE = [["Q3 infra budget", "note", 3, 2, "3d ago", "Weekly digest"], ["Hetzner", "company", 5, 4, "4d ago", "Refactor gateway auth"], ["Re: gateway pricing", "email", 2, 3, "4d ago", "Weekly digest"], ["Ana Lima", "person", 7, 5, "5d ago", "iMessage: Mario"], ["Browser QA checklist", "source", 0, 1, "6d ago", "Browser QA sweep"]];
const eyebrow = { margin: 0, display: "flex", alignItems: "center", gap: 8, fontSize: 11, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--muted-strong)" };
const surface = { background: "var(--card)", border: "1px solid color-mix(in srgb, var(--border) 85%, transparent)", borderRadius: "var(--radius-lg)", overflow: "hidden" };
const hair = "1px solid color-mix(in srgb, var(--border) 60%, transparent)";
const claimsAbout = (id) => C.filter((c) => c.about.includes(id));

function Tile({ type, size = 28 }) {
  const [ic, , color, bg] = T[type] || T.note;
  return <span style={{ width: size, height: size, flex: "none", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: size > 32 ? "var(--radius-md)" : "var(--radius-sm)", color, background: bg }}><Icon name={ic} size={Math.round(size / 2)} /></span>;
}
function Origin({ c }) {
  const o = { source: ["paperclip", "From source", "var(--muted)"], user: ["circleUser", "You told Molty", "var(--accent-2)"], inferred: ["spark", "Molty inferred", "var(--warn)"] }[c.origin];
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: o[2], fontSize: 12, fontWeight: 500 }}><Icon name={o[0]} size={12} />{o[1]}</span>;
}
function EntityLink({ id, onOpen }) {
  const [h, setH] = useState(false);
  return <button type="button" onClick={() => onOpen(id)} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ border: 0, padding: 0, background: "none", font: "inherit", color: h ? "var(--text-strong)" : "var(--text)", textDecoration: h ? "underline" : "none", textUnderlineOffset: 2, cursor: "pointer" }}>{E[id].title}</button>;
}

function ClaimRow({ c, onOpen, onAsk, first, showAbout = true }) {
  const [open, setOpen] = useState(false);
  const [h, setH] = useState(false);
  const [ic, label] = KIND[c.kind];
  return <div style={{ borderTop: first ? 0 : hair }}>
    <div role="button" tabIndex={0} onClick={() => setOpen(!open)} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "start", padding: "12px 14px", cursor: "pointer", background: h ? "color-mix(in srgb, var(--bg-hover) 60%, transparent)" : "transparent" }}>
      <span title={label} style={{ width: 28, height: 28, display: "inline-flex", alignItems: "center", justifyContent: "center", color: "var(--muted-strong)" }}><Icon name={ic} size={15} /></span>
      <span style={{ display: "grid", gap: 4, minWidth: 0 }}>
        <span style={{ color: "var(--text-strong)", fontSize: 14, lineHeight: 1.45, textWrap: "pretty" }}>{c.text}</span>
        <span style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 10px", color: "var(--muted)", fontSize: 12 }}>
          <span>{label}</span><Origin c={c} />
          {showAbout ? <span style={{ display: "inline-flex", gap: 4 }}>About {c.about.map((a, i) => <span key={a} onClick={(e) => e.stopPropagation()}>{i ? ", " : ""}<EntityLink id={a} onOpen={onOpen} /></span>)}</span> : null}
          <span>{c.when}</span>
        </span>
      </span>
      <span style={{ color: "var(--muted)", paddingTop: 6, transform: open ? "rotate(180deg)" : "none", transition: "transform .15s" }}><Icon name="chevronDown" size={14} /></span>
    </div>
    {open ? <div style={{ margin: "0 14px 14px 54px", display: "grid", gap: 10 }}>
      {c.origin === "inferred"
        ? <div style={{ padding: "10px 12px", borderRadius: "var(--radius-md)", background: "var(--warn-subtle)", color: "var(--text)", fontSize: 13, lineHeight: 1.5 }}><strong style={{ color: "var(--warn)" }}>No quoted source.</strong> {c.reason}</div>
        : <figure style={{ margin: 0, padding: "12px 14px", borderRadius: "var(--radius-md)", background: "var(--bg-accent, var(--bg-hover))", border: hair }}>
            <blockquote style={{ margin: 0, color: "var(--text-strong)", fontSize: 14, lineHeight: 1.55 }}>“{c.quote}”</blockquote>
            <figcaption style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: "4px 10px", color: "var(--muted)", fontSize: 12 }}>
              <span>— {c.speaker}</span>
              {c.file ? <span style={{ fontFamily: "var(--mono)", fontSize: 11 }}>{c.file} · line {c.lines}</span> : <span>Chat message in “{c.from}”</span>}
              {c.file ? <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "var(--ok)" }}><Icon name="badgeCheck" size={12} />Original retained</span> : null}
            </figcaption>
          </figure>}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        <Button size="sm" icon="messageSquare" onClick={() => onAsk(null, c.from)}>Open “{c.from}”</Button>
        {c.file ? <Button size="sm" icon="download">Original file</Button> : null}
        <Button size="sm" variant="ghost" icon="pencil" onClick={() => onAsk(`This isn’t right: “${c.text}” — `)}>Correct in chat</Button>
      </div>
    </div> : null}
  </div>;
}

function Search({ onOpen, onBrowse }) {
  const [q, setQ] = useState("");
  const [focus, setFocus] = useState(false);
  const s = q.trim().toLowerCase();
  const hits = s ? Object.entries(E).filter(([, e]) => [e.title, ...e.aliases].some((n) => n.toLowerCase().includes(s))).slice(0, 5) : [];
  return <div style={{ position: "relative" }}>
    <label style={{ position: "relative", display: "block" }}>
      <span style={{ position: "absolute", top: "50%", left: 13, transform: "translateY(-50%)", color: "var(--muted)", display: "inline-flex", pointerEvents: "none" }}><Icon name="search" size={16} strokeWidth={1.7} /></span>
      <input value={q} onChange={(e) => setQ(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setTimeout(() => setFocus(false), 150)} placeholder="Find a person, project, or anything Molty saved…" aria-label="Search knowledge"
        style={{ width: "100%", boxSizing: "border-box", minHeight: 44, padding: "8px 12px 8px 38px", border: "1px solid var(--input)", borderRadius: "var(--radius-md)", background: "var(--card)", color: "var(--text)", fontSize: 14, fontFamily: "var(--font-body)", outline: "none", boxShadow: "inset 0 1px 0 var(--card-highlight)" }} />
      <span style={{ position: "absolute", top: "50%", right: 12, transform: "translateY(-50%)", color: "var(--muted)", fontSize: 11, fontFamily: "var(--mono)", border: "1px solid var(--border)", borderRadius: 4, padding: "1px 5px" }}>/</span>
    </label>
    {focus && s ? <div style={{ ...surface, position: "absolute", zIndex: 5, top: "calc(100% + 6px)", left: 0, right: 0, boxShadow: "var(--shadow-lg)", padding: 6 }}>
      {hits.length ? <p style={{ ...eyebrow, padding: "6px 8px" }}>Exact matches</p> : null}
      {hits.map(([id, e]) => <button key={id} type="button" onMouseDown={() => onOpen(id)} style={{ display: "flex", width: "100%", alignItems: "center", gap: 10, padding: "8px", border: 0, borderRadius: "var(--radius-sm)", background: "transparent", color: "var(--text)", font: "inherit", textAlign: "left", cursor: "pointer" }}
        onMouseEnter={(ev) => ev.currentTarget.style.background = "var(--bg-hover)"} onMouseLeave={(ev) => ev.currentTarget.style.background = "transparent"}>
        <Tile type={e.type} size={24} /><span style={{ color: "var(--text-strong)", fontWeight: 500 }}>{e.title}</span><span style={{ color: "var(--muted)", fontSize: 12 }}>{T[e.type][1]}</span>
        <span style={{ marginLeft: "auto", color: "var(--muted)", fontSize: 12 }}>{claimsAbout(id).length} claims</span>
      </button>)}
      <button type="button" onMouseDown={() => onBrowse(q)} style={{ display: "flex", width: "100%", alignItems: "center", gap: 10, padding: "8px", border: 0, borderTop: hits.length ? hair : 0, marginTop: hits.length ? 4 : 0, background: "transparent", color: "var(--muted-strong)", font: "inherit", fontSize: 13, textAlign: "left", cursor: "pointer" }}>
        <Icon name="search" size={14} />Search all text for “{q}”<span style={{ marginLeft: "auto" }}><Icon name="cornerDownLeft" size={13} /></span>
      </button>
    </div> : null}
  </div>;
}

function FeedItem({ it, onOpen, onAsk, first }) {
  const [k, ref, note] = it;
  if (k === "claim") return <ClaimRow c={C.find((c) => c.id === ref)} onOpen={onOpen} onAsk={onAsk} first={first} />;
  const row = { display: "grid", gridTemplateColumns: "28px minmax(0,1fr) auto", gap: 12, alignItems: "center", padding: "10px 14px", borderTop: first ? 0 : hair };
  if (k === "link") return <div style={row}><span style={{ display: "inline-flex", justifyContent: "center", color: "var(--muted-strong)" }}><Icon name="link" size={15} /></span><span style={{ color: "var(--text)", fontSize: 13 }}>{ref}</span><span style={{ color: "var(--muted)", fontSize: 12 }}>3 connections</span></div>;
  if (k === "unresolved") return <div style={{ ...row, background: "color-mix(in srgb, var(--warn-subtle) 55%, transparent)" }}><span style={{ display: "inline-flex", justifyContent: "center", color: "var(--warn)" }}><Icon name="shieldQuestion" size={15} /></span><span style={{ color: "var(--text)", fontSize: 13 }}>{ref}</span><Button size="xs" onClick={() => onAsk("In the Sep 22 standup, “Sam” is ")}>Tell Molty who</Button></div>;
  const e = E[ref];
  return <div role="button" onClick={() => onOpen(ref)} style={{ ...row, cursor: "pointer" }} onMouseEnter={(ev) => ev.currentTarget.style.background = "color-mix(in srgb, var(--bg-hover) 60%, transparent)"} onMouseLeave={(ev) => ev.currentTarget.style.background = "transparent"}>
    <Tile type={e.type} />
    <span style={{ display: "grid", gap: 2, minWidth: 0 }}><span style={{ color: "var(--text-strong)", fontSize: 14, fontWeight: 500 }}>{e.title}</span><span style={{ color: "var(--muted)", fontSize: 12 }}>{T[e.type][1]}{note ? " · " + note : ""}</span></span>
    <Chip tone={k === "new" ? "accent" : "neutral"}>{k === "new" ? "New" : "Updated"}</Chip>
  </div>;
}

function Recent({ onOpen, onAsk, onBrowse }) {
  return <div style={{ display: "flex", flexDirection: "column", gap: 28 }}>
    <Search onOpen={onOpen} onBrowse={onBrowse} />
    <SettingsSection title="Needs a look" description="Things Molty saved but couldn’t fully pin down.">
      <SettingsRow first title="“Sam” in Team standup — Sep 22" description="Mentioned 4 times, but doesn’t match anyone Molty knows." control={<Button size="sm" onClick={() => onAsk("In the Sep 22 standup, “Sam” is ")}>Tell Molty who</Button>} />
      <SettingsRow title="1 claim is Molty’s inference" description="Saved without a quoted source. Worth a glance." control={<Button size="sm" onClick={() => onOpen("northwind")}>Review</Button>} />
    </SettingsSection>
    {FEED.map((d) => <section key={d.day} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <h2 style={eyebrow}>{d.day}</h2>
      {d.groups.map((g) => <div key={g.session} style={surface}>
        <header style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderBottom: hair, background: "color-mix(in srgb, var(--bg-hover) 35%, transparent)" }}>
          <span style={{ color: "var(--muted-strong)", display: "inline-flex" }}><Icon name="messageSquare" size={15} /></span>
          <span style={{ color: "var(--text-strong)", fontWeight: 600, fontSize: 13.5 }}>{g.session}</span>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>{g.items.length} saved · {g.when}{g.note ? " · " + g.note : ""}</span>
          <span style={{ marginLeft: "auto" }}><Button size="xs" variant="ghost" icon="arrowUpRight" onClick={() => onAsk(null, g.session)}>Open conversation</Button></span>
        </header>
        {g.items.map((it, i) => <FeedItem key={i} it={it} first={i === 0} onOpen={onOpen} onAsk={onAsk} />)}
      </div>)}
    </section>)}
  </div>;
}

function Browse({ onOpen, onAsk, initialQuery }) {
  const [mode, setMode] = useState("pages");
  const [facet, setFacet] = useState("all");
  const [q, setQ] = useState(initialQuery || "");
  const rows = [...Object.entries(E).map(([id, e]) => ({ key: id, name: e.title, type: e.type, claims: claimsAbout(id).length, links: e.links.length, updated: e.updated, from: e.learned[0][0] })),
    ...MORE.map(([name, type, claims, links, updated, from]) => ({ key: name, name, type, claims, links, updated, from }))]
    .filter((r) => (facet === "all" || r.type === facet) && (!q || r.name.toLowerCase().includes(q.toLowerCase())));
  const total = facet === "all" ? 2418 : (FACETS.flatMap((f) => f[1]).find((f) => f[0] === facet) || [0, 0, rows.length])[2];
  const fBtn = (id, label, n) => { const on = facet === id; return <button key={id} type="button" onClick={() => setFacet(id)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "6px 8px", border: 0, borderRadius: "var(--radius-sm)", background: on ? "var(--accent-subtle)" : "transparent", color: on ? "var(--text-strong)" : "var(--text)", font: "inherit", fontSize: 13, textAlign: "left", cursor: "pointer" }}>{T[id] ? <Tile type={id} size={20} /> : <span style={{ width: 20 }} />}<span>{label}</span><span style={{ marginLeft: "auto", color: "var(--muted)", fontSize: 12, fontFamily: "var(--mono)" }}>{n.toLocaleString()}</span></button>; };
  return <div style={{ display: "grid", gridTemplateColumns: "210px minmax(0,1fr)", gap: 24, alignItems: "start" }}>
    <nav aria-label="Types" style={{ position: "sticky", top: 0, display: "grid", gap: 14 }}>
      <div>{fBtn("all", "Everything", 2418)}</div>
      {FACETS.map(([g, items]) => <div key={g} style={{ display: "grid", gap: 2 }}><p style={{ ...eyebrow, padding: "0 8px 4px", fontSize: 10 }}>{g}</p>{items.map(([id, l, n]) => fBtn(id, l, n))}</div>)}
      <p style={{ margin: "0 8px", color: "var(--muted)", fontSize: 12 }}>12 empty types hidden</p>
    </nav>
    <div style={surface}>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, padding: "8px 12px", borderBottom: hair }}>
        <label style={{ position: "relative", flex: "1 1 220px" }}>
          <span style={{ position: "absolute", top: "50%", left: 10, transform: "translateY(-50%)", color: "var(--muted)", display: "inline-flex" }}><Icon name="search" size={14} /></span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={mode === "pages" ? "Filter by name or alias" : "Search claim text"} style={{ width: "100%", boxSizing: "border-box", height: 34, padding: "0 10px 0 30px", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", background: "var(--bg)", color: "var(--text)", fontSize: 13, fontFamily: "var(--font-body)", outline: "none" }} />
        </label>
        <Segmented ariaLabel="Record kind" value={mode} onChange={setMode} options={[{ value: "pages", label: "Pages" }, { value: "claims", label: "Claims" }]} />
        <IconButton variant="bordered" icon="listFilter" label="More filters" size={32} iconSize={14} />
      </div>
      {mode === "pages" ? <DataTable sort={{ column: "updated", dir: "desc" }}
        columns={[{ key: "name", label: "Name", sortable: true }, { key: "type", label: "Type", sortable: true }, { key: "claims", label: "Claims", sortable: true }, { key: "links", label: "Connections" }, { key: "updated", label: "Last saved", sortable: true }, { key: "from", label: "Learned in" }]}
        rows={rows.map((r) => ({ ...r, onClick: () => E[r.key] && onOpen(r.key) }))} emptyMessage="Nothing matches these filters"
        renderRow={(r, td) => <>
          <td style={td}><span style={{ display: "flex", alignItems: "center", gap: 10 }}><Tile type={r.type} size={24} /><span style={{ color: "var(--text-strong)", fontWeight: 500 }}>{r.name}</span></span></td>
          <td style={{ ...td, color: "var(--muted)" }}>{(T[r.type] || [0, r.type])[1]}</td>
          <td style={{ ...td, fontFamily: "var(--mono)", fontSize: 12 }}>{r.claims}</td>
          <td style={{ ...td, fontFamily: "var(--mono)", fontSize: 12 }}>{r.links}</td>
          <td style={{ ...td, color: "var(--muted)", whiteSpace: "nowrap" }}>{r.updated}</td>
          <td style={{ ...td, color: "var(--muted)", whiteSpace: "nowrap" }}>{r.from}</td>
        </>}
        pagination={<><span>1–{rows.length} of {total.toLocaleString()} · complete list</span><div style={{ display: "flex", gap: 8 }}><PaginationButton disabled>Previous</PaginationButton><PaginationButton>Next</PaginationButton></div></>} />
        : <div>{C.filter((c) => !q || c.text.toLowerCase().includes(q.toLowerCase())).map((c, i) => <ClaimRow key={c.id} c={c} first={i === 0} onOpen={onOpen} onAsk={onAsk} />)}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderTop: hair, color: "var(--muted)", fontSize: 12 }}><span>1–7 of 6,905 claims · complete list</span><div style={{ display: "flex", gap: 8 }}><PaginationButton disabled>Previous</PaginationButton><PaginationButton>Next</PaginationButton></div></div></div>}
    </div>
  </div>;
}

function Entity({ id, onOpen, onAsk, onBack }) {
  const e = E[id];
  const [ic, typeLabel] = T[e.type];
  const claims = claimsAbout(id);
  const groups = Object.keys(KIND).map((k) => [k, claims.filter((c) => c.kind === k)]).filter(([, l]) => l.length);
  const [raw, setRaw] = useState(false);
  return <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
    <nav style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 13 }}>
      <button type="button" onClick={onBack} style={{ display: "inline-flex", alignItems: "center", gap: 4, border: 0, padding: 0, background: "none", color: "var(--muted-strong)", font: "inherit", cursor: "pointer" }}><Icon name="arrowLeft" size={14} />Knowledge</button>
      <Icon name="chevronRight" size={12} /><span>{typeLabel === "Person" ? "People" : typeLabel + "s"}</span>
    </nav>
    <header style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
      <Tile type={e.type} size={48} />
      <div style={{ flex: 1, minWidth: 0, display: "grid", gap: 6 }}>
        <h1 style={{ margin: 0, color: "var(--text-strong)", fontSize: 26, fontWeight: 650, letterSpacing: "-0.025em", lineHeight: 1.15 }}>{e.title}</h1>
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "4px 14px", color: "var(--muted)", fontSize: 13 }}>
          <span>{typeLabel}</span>
          {e.fields.map(([k, v]) => <span key={k}><span style={{ color: "var(--muted)" }}>{k} </span><span style={{ color: "var(--text)" }}>{v}</span></span>)}
          {e.aliases.length ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>Also called {e.aliases.map((a) => <Chip key={a}>{a}</Chip>)}</span> : null}
        </div>
      </div>
      <Button icon="messageSquare" onClick={() => onAsk(`What do you know about ${e.title}?`)}>Ask Molty</Button>
    </header>
    {e.unresolved ? <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: "var(--radius-md)", background: "var(--warn-subtle)", fontSize: 13 }}><span style={{ color: "var(--warn)", display: "inline-flex" }}><Icon name="shieldQuestion" size={15} /></span><span style={{ flex: 1 }}>“{e.unresolved}” spoke in this meeting but isn’t linked to anyone.</span><Button size="xs" onClick={() => onAsk(`In the Sep 22 standup, “${e.unresolved}” is `)}>Tell Molty who</Button></div> : null}
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) 300px", gap: 28, alignItems: "start" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 24, minWidth: 0 }}>
        <section style={{ display: "grid", gap: 8 }}>
          <p style={{ margin: 0, color: "var(--text)", fontSize: 15, lineHeight: 1.65, textWrap: "pretty", maxWidth: "62ch" }}>{e.summary}</p>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>Summary written by Molty · updated {e.updated} · revision {e.rev}</span>
        </section>
        <section style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <h2 style={eyebrow}>What Molty knows <span style={{ color: "var(--muted)", fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>{claims.length} claims</span></h2>
          {groups.length ? <div style={surface}>{groups.map(([k, list], gi) => <div key={k}>
            <div style={{ padding: "8px 14px", borderTop: gi ? hair : 0, color: "var(--muted-strong)", fontSize: 12, fontWeight: 600, background: "color-mix(in srgb, var(--bg-hover) 35%, transparent)" }}>{KIND[k][2]} · {list.length}</div>
            {list.map((c) => <ClaimRow key={c.id} c={c} first={false} onOpen={onOpen} onAsk={onAsk} showAbout={c.about.length > 1} />)}
          </div>)}</div> : <p style={{ margin: 0, color: "var(--muted)", fontSize: 13 }}>No claims about {e.title} yet. Tell Molty in chat and it will save them here.</p>}
        </section>
      </div>
      <aside style={{ display: "flex", flexDirection: "column", gap: 20, position: "sticky", top: 0 }}>
        <section style={{ display: "grid", gap: 8 }}>
          <h2 style={eyebrow}>Connections</h2>
          <div style={surface}>{e.links.map(([rel, to], i) => <div key={i} role="button" onClick={() => onOpen(to)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderTop: i ? hair : 0, cursor: "pointer" }} onMouseEnter={(ev) => ev.currentTarget.style.background = "color-mix(in srgb, var(--bg-hover) 60%, transparent)"} onMouseLeave={(ev) => ev.currentTarget.style.background = "transparent"}>
            <Tile type={E[to].type} size={24} /><span style={{ display: "grid", minWidth: 0 }}><span style={{ color: "var(--muted)", fontSize: 11 }}>{rel}</span><span style={{ color: "var(--text-strong)", fontSize: 13, fontWeight: 500 }}>{E[to].title}</span></span>
          </div>)}</div>
        </section>
        <section style={{ display: "grid", gap: 8 }}>
          <h2 style={eyebrow}>Learned in</h2>
          <div style={surface}>{e.learned.map(([s, w], i) => <div key={s} role="button" onClick={() => onAsk(null, s)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderTop: i ? hair : 0, cursor: "pointer" }} onMouseEnter={(ev) => ev.currentTarget.style.background = "color-mix(in srgb, var(--bg-hover) 60%, transparent)"} onMouseLeave={(ev) => ev.currentTarget.style.background = "transparent"}>
            <span style={{ color: "var(--muted-strong)", display: "inline-flex" }}><Icon name="messageSquare" size={14} /></span><span style={{ flex: 1, color: "var(--text)", fontSize: 13 }}>{s}</span><span style={{ color: "var(--muted)", fontSize: 12 }}>{w}</span>
          </div>)}</div>
        </section>
        <section style={{ display: "grid", gap: 8 }}>
          <button type="button" onClick={() => setRaw(!raw)} style={{ ...eyebrow, border: 0, padding: 0, background: "none", cursor: "pointer", font: "inherit", fontSize: 11 }}>File details <Icon name={raw ? "chevronUp" : "chevronDown"} size={12} /></button>
          {raw ? <div style={{ ...surface, padding: 12, display: "grid", gap: 6, fontSize: 12 }}>
            {[["File", e.path], ["ID", "rec_" + id], ["Revision", String(e.rev)], ["History", "Committed · 3f9a2c1"]].map(([k, v]) => <div key={k} style={{ display: "flex", gap: 8 }}><span style={{ color: "var(--muted)", width: 64, flex: "none" }}>{k}</span><span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--text)", overflowWrap: "anywhere" }}>{v}</span></div>)}
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}><Button size="xs" icon="fileText">View Markdown</Button><Button size="xs" variant="ghost" icon="clock">History</Button></div>
          </div> : null}
        </section>
      </aside>
    </div>
  </div>;
}

export function KnowledgeV2Screen({ onAsk = () => {} }) {
  const [tab, setTab] = useState("recent");
  const [entity, setEntity] = useState(null);
  const [bq, setBq] = useState("");
  const open = (id) => { setEntity(id); };
  const browse = (q) => { setBq(q); setEntity(null); setTab("browse"); };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <PageHeader title="Knowledge" subtitle="What Molty has saved, and where it came from."
        tabs={<HubTabs value={entity ? "" : tab} onChange={(v) => { setEntity(null); setTab(v); }} tabs={[{ value: "recent", label: "Recent" }, { value: "browse", label: "Browse", count: 2418 }]} />}
        actions={<span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}><StatusDot tone="ok" label="Live" /><IconButton variant="bordered" icon="book" label="Ontology & vault settings" size={34} iconSize={16} /></span>} />
      <div style={{ width: "100%", maxWidth: 1120, margin: "0 auto", padding: "4px 16px 48px", boxSizing: "border-box" }}>
        {entity ? <Entity key={entity} id={entity} onOpen={open} onAsk={onAsk} onBack={() => setEntity(null)} />
          : tab === "recent" ? <Recent onOpen={open} onAsk={onAsk} onBrowse={browse} />
          : <Browse key={bq} initialQuery={bq} onOpen={open} onAsk={onAsk} />}
      </div>
    </div>
  );
}
