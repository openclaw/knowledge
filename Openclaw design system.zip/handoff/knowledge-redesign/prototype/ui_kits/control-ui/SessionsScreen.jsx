import React, { useState } from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { Input } from "../../components/core/Input.jsx";
import { Button } from "../../components/core/Button.jsx";
import { IconButton } from "../../components/core/IconButton.jsx";
import { Segmented } from "../../components/core/Segmented.jsx";
import { StatusDot } from "../../components/core/StatusDot.jsx";
import { PageHeader } from "../../components/settings/PageHeader.jsx";
import { HubTabs } from "../../components/navigation/HubTabs.jsx";
import { DataTable, PaginationButton } from "../../components/navigation/DataTable.jsx";
/* Source: pages/sessions/view.ts + sessions.css: settings-page--wide (1120), heading facts, .sessions-toolbar (search + segmented + filter popover trigger 32px), .sessions-table (key cell: 28px kind avatar tile + mono key + label chip; kind tinted uppercase; status dot+text; tokens meter), data-table pagination. */
const KIND = { direct: ["messageSquare", "var(--accent-2)", "var(--accent-2-subtle)"], group: ["users", "var(--info)", "var(--info-subtle)"], cron: ["clock", "var(--ok)", "var(--ok-subtle)"], global: ["globe", "var(--warn)", "var(--warn-subtle)"] };
const ROWS = [
  { key: "agent:main:direct:whatsapp:+4366…", label: "Peter", kind: "direct", status: ["ok", "Live"], updated: "2m ago", tokens: [38200, 200000], live: true },
  { key: "agent:main:cron:weekly-digest", kind: "cron", status: ["warn", "Queued"], updated: "14m ago", tokens: [12100, 200000] },
  { key: "agent:main:group:discord:#ops", label: "ops", kind: "group", status: ["muted", "Idle"], updated: "1h ago", tokens: [96400, 200000] },
  { key: "agent:main:direct:imessage:mario", kind: "direct", status: ["ok", "Done"], updated: "3h ago", tokens: [4300, 200000] },
  { key: "agent:research:global", kind: "global", status: ["muted", "Idle"], updated: "Yesterday", tokens: [171000, 200000] },
  { key: "agent:main:cron:backup-check", kind: "cron", status: ["danger", "Failed"], updated: "2d ago", tokens: [900, 200000], archived: true },
];
function fmt(n) { return n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + "k" : String(n); }
export function SessionsScreen({ onOpen }) {
  const [tab, setTab] = useState("sessions");
  const [state, setState] = useState("active");
  const [sel, setSel] = useState(new Set());
  const [q, setQ] = useState("");
  const rows = ROWS.filter((r) => (state === "all" || (state === "archived") === !!r.archived) && r.key.includes(q));
  const toggle = (k) => setSel((s) => { const n = new Set(s); n.has(k) ? n.delete(k) : n.add(k); return n; });
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <PageHeader title="Sessions" subtitle="Every conversation the Gateway is tracking." learnMoreHref="https://docs.openclaw.ai/concepts/sessions" tabs={<HubTabs value={tab} onChange={setTab} tabs={[{ value: "sessions", label: "Sessions", count: ROWS.length }, { value: "worktrees", label: "Worktrees" }]} />} actions={<Button size="sm" icon="repeat">Refresh</Button>} />
      <div style={{ width: "100%", maxWidth: 1120, margin: "0 auto", display: "flex", flexDirection: "column", gap: 16, padding: "12px 16px 40px" }}>
        <section style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <h2 style={{ margin: 0, display: "flex", alignItems: "center", gap: 8, fontSize: 11, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--muted-strong)" }}>
            Sessions
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "var(--muted)", fontWeight: 500, letterSpacing: 0, textTransform: "none" }}>
              <span><strong style={{ color: "var(--text-strong)", fontFamily: "var(--mono)", fontWeight: 700 }}>{ROWS.length}</strong> total</span><span style={{ color: "var(--border-strong)" }}>·</span>
              <span style={{ color: "var(--ok)" }}><strong style={{ fontFamily: "var(--mono)", fontWeight: 700 }}>1</strong> active</span><span style={{ color: "var(--border-strong)" }}>·</span>
              <span><strong style={{ color: "var(--text-strong)", fontFamily: "var(--mono)", fontWeight: 700 }}>323k</strong> tokens</span>
            </span>
          </h2>
          <div style={{ background: "var(--card)", border: "1px solid color-mix(in srgb, var(--border) 85%, transparent)", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
            <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 4, padding: "8px 12px", borderBottom: "1px solid color-mix(in srgb, var(--border) 60%, transparent)" }}>
              <div style={{ flex: "1 1 220px", minWidth: 180 }}><Input variant="search" icon="search" placeholder="Search sessions…" value={q} onChange={setQ} /></div>
              <Segmented ariaLabel="Session state" value={state} onChange={setState} options={[{ value: "active", label: "Active" }, { value: "archived", label: "Archived" }, { value: "all", label: "All" }]} />
              <IconButton variant="bordered" icon="listFilter" label="Filters" size={32} iconSize={14} />
            </div>
            <DataTable selectable selected={sel} onToggle={toggle} onToggleAll={() => setSel(sel.size ? new Set() : new Set(rows.map((r) => r.key)))} sort={{ column: "updated", dir: "desc" }}
              bulkBar={sel.size ? <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 12px", borderBottom: "1px solid var(--border)", background: "var(--accent-subtle)", fontSize: 13, fontWeight: 500 }}><span>{sel.size} selected</span><Button size="sm" onClick={() => setSel(new Set())}>Unselect</Button><Button size="sm" variant="danger" icon="trash">Delete selected</Button></div> : null}
              columns={[{ key: "key", label: "Key", sortable: true }, { key: "kind", label: "Kind", sortable: true }, { key: "status", label: "Status", width: 118 }, { key: "updated", label: "Updated", sortable: true }, { key: "tokens", label: "Tokens", sortable: true }, { key: "actions", label: "" }]}
              rows={rows.map((r) => ({ ...r, onClick: () => onOpen && onOpen(r.key) }))}
              emptyMessage="No sessions match these filters"
              renderRow={(r, td) => {
                const [icon, color, bg] = KIND[r.kind];
                const pct = Math.round((r.tokens[0] / r.tokens[1]) * 100);
                const tone = pct >= 85 ? "var(--danger)" : pct >= 65 ? "var(--warn)" : "var(--ok)";
                return <>
                  <td style={{ ...td, minWidth: 180 }}><div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0, maxWidth: 340 }}>
                    <span style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", width: 28, height: 28, flex: "0 0 auto", color, background: bg, borderRadius: "var(--radius-sm)" }}><Icon name={icon} size={14} />{r.live ? <span style={{ position: "absolute", right: -3, bottom: -3, width: 9, height: 9, background: "var(--ok)", border: "2px solid var(--card)", borderRadius: "50%" }} /> : null}</span>
                    <span style={{ display: "grid", gap: 3, minWidth: 0 }}><span style={{ display: "inline-flex", alignItems: "center", gap: 6, minWidth: 0 }}><span style={{ fontFamily: "var(--mono)", fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.key}</span>{r.label ? <span style={{ color: "var(--accent-2)", fontSize: 11, fontWeight: 600 }}>{r.label}</span> : null}</span></span>
                  </div></td>
                  <td style={{ ...td, whiteSpace: "nowrap" }}><span style={{ fontSize: 12, fontWeight: 600, letterSpacing: "0.02em", color, textTransform: "uppercase" }}>{r.kind}</span></td>
                  <td style={{ ...td, whiteSpace: "nowrap" }}><StatusDot tone={r.status[0]} label={r.status[1]} /></td>
                  <td style={{ ...td, whiteSpace: "nowrap", color: "var(--muted)" }}>{r.updated}</td>
                  <td style={{ ...td, whiteSpace: "nowrap" }}><span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><span style={{ fontFamily: "var(--mono)", fontSize: 12 }}>{fmt(r.tokens[0])}</span><span style={{ width: 56, height: 4, borderRadius: 2, background: "var(--bg-hover)", overflow: "hidden" }}><span style={{ display: "block", width: pct + "%", height: "100%", background: tone }} /></span><span style={{ fontSize: 11, color: "var(--muted)" }}>{pct}%</span></span></td>
                  <td style={{ ...td, width: 40, textAlign: "right" }}><IconButton icon="moreHorizontal" label="Session actions" size={28} iconSize={16} /></td>
                </>;
              }}
              pagination={<><span>1–{rows.length} of {rows.length}</span><div style={{ display: "flex", alignItems: "center", gap: 8 }}><select aria-label="Page size" style={{ height: 28, padding: "0 8px", border: "1px solid var(--border)", borderRadius: "var(--radius-sm)", background: "var(--card)", color: "var(--text)", fontSize: 13, fontFamily: "var(--font-body)" }}><option>25 per page</option></select><PaginationButton disabled>Previous</PaginationButton><PaginationButton disabled>Next</PaginationButton></div></>} />
          </div>
        </section>
      </div>
    </div>
  );
}
