import React, { useState } from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { IconButton } from "../../components/core/IconButton.jsx";
import { RailHeader } from "../../components/navigation/RailHeader.jsx";
import { Composer } from "../../components/chat/Composer.jsx";
import { Message } from "../../components/chat/Message.jsx";
import { ToolRow } from "../../components/chat/ToolRow.jsx";
import { ChatDivider } from "../../components/chat/ChatDivider.jsx";
/* Source: chat/startup-layout.css .chat (thread max 48rem, gutter 18, composer side inset 36, bottom gap 14), .chat-thread (pad-top clamp 20–28), .chat-pane__header (48px, pad 0 6 0 12, crumbs 12px: project muted · session text), .chat-main__conversation (composer top margin 8, underlap 30, fade 24). */
const SEED = [
  { id: 1, role: "user", time: "09:41", text: "Can you summarise the gateway logs from the last hour and check whether the websocket reconnects are a problem?" },
  { id: 2, role: "assistant", tools: [
    { icon: "terminal", verb: "Ran", target: "openclaw logs --since 1h", detail: "1.2s", body: "09:12 ws reconnect (4s gap)\n09:31 ws reconnect\n09:58 ws reconnect\n[no errors]" },
    { icon: "fileText", verb: "Read", target: "src/gateway/ws.ts" },
  ], text: "Three reconnects in the last hour, all recovered within 4 seconds and no errors logged. They line up with the laptop's Wi-Fi power-save cycle rather than anything in the gateway. If you want, I can raise the ping interval so the socket rides through those gaps." },
  { id: 3, role: "user", time: "09:44", text: "Yes, do that and open a PR." },
  { id: 4, role: "assistant", tools: [
    { icon: "fileDiff", verb: "Edited", target: "src/gateway/ws.ts", diffstat: [14, 3] },
    { icon: "terminal", verb: "Ran", target: "pnpm test --filter gateway", detail: "12s", body: "✓ 184 passed" },
    { icon: "gitPullRequest", verb: "Opening", target: "PR #4821", status: "running" },
  ], text: null },
];
export function ChatScreen({ sessionTitle = "Refactor gateway auth", draft = "" }) {
  const [messages, setMessages] = useState(SEED);
  const [d, setD] = useState(draft);
  const send = (text) => { setMessages((m) => [...m, { id: Date.now(), role: "user", time: "now", text }]); setD(""); };
  return (
    <div style={{ display: "flex", flexDirection: "column", flex: "1 1 0", minHeight: 0, minWidth: 0, height: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, minHeight: 48, padding: "0 6px 0 12px", userSelect: "none", flex: "0 0 auto" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, minWidth: 0, transform: "translateY(-1px)" }}>
          <button type="button" style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "3px 5px", marginInline: -5, border: 0, borderRadius: "var(--radius-sm)", background: "transparent", color: "var(--muted)", fontSize: 12, fontFamily: "var(--font-body)", cursor: "var(--cursor-action)" }}><Icon name="folder" size={14} strokeWidth={1.7} />openclaw</button>
          <span style={{ color: "var(--muted)", fontSize: 12 }}>/</span>
          <span style={{ color: "var(--text)", fontSize: 12, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{sessionTitle}</span>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
          <IconButton variant="rail" icon="search" label="Search transcript" />
          <IconButton variant="rail" icon="panelsTopLeft" label="Split view" />
          <IconButton variant="rail" icon="moreHorizontal" label="Session actions" />
        </div>
      </div>
      <div style={{ position: "relative", display: "flex", minWidth: 0, minHeight: 0, flex: "1 1 auto", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ flex: "1 1 0", overflowY: "auto", overflowX: "hidden", padding: "clamp(20px, 3vh, 28px) 0 40px", scrollbarGutter: "stable both-edges" }}>
          <div style={{ maxWidth: "48rem", margin: "0 auto", padding: "0 clamp(6px, 1vw, 12px)" }}>
            <ChatDivider label="Today" />
            {messages.map((m) => (
              <Message key={m.id} role={m.role} time={m.time} actions={m.role === "assistant" ? <><IconButton icon="copy" label="Copy" size={22} iconSize={13} /><IconButton icon="cornerDownLeft" label="Reply" size={22} iconSize={13} /></> : null}>
                {m.tools ? <div style={{ display: "flex", flexDirection: "column", gap: 2, marginBottom: m.text ? 10 : 0 }}>{m.tools.map((t, i) => <ToolRow key={i} icon={t.icon} verb={t.verb} target={t.target} detail={t.detail} diffstat={t.diffstat} status={t.status}>{t.body}</ToolRow>)}</div> : null}
                {m.text}
              </Message>
            ))}
          </div>
        </div>
        <div style={{ position: "relative", padding: "0 36px 14px", marginTop: -30, background: "linear-gradient(to bottom, transparent 0, var(--bg) 30px)" }}>
          <div style={{ maxWidth: "48rem", margin: "0 auto" }}>
            <Composer model="Claude Opus 4" effort="Medium" value={d} onChange={setD} onSend={send} />
          </div>
        </div>
      </div>
    </div>
  );
}
