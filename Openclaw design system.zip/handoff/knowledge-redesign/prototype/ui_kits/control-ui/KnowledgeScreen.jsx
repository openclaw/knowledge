import React, { useState } from "react";
/* Source: knowledge plugin (extensions/knowledge) src/control-ui.ts, control-ui.css, ontology-view.ts, retrieval-view.ts, evidence-view.ts.
   Rendered as a plugin page (host.ui.registerPage "overview"), styled by the plugin's own stylesheet — NOT the host settings components.
   Data: fixtures/sample-vault + ontologies/knowledge-default.yaml. */
const RECORDS = [
  { id: "sample_person_alex", kind: "page", type: "person", title: "Alex Rivera", path: "people/alex-rivera.md", fields: { role: "Volunteer coordinator" }, aliases: ["Alex"],
    body: "# Alex Rivera\n\nFictional coordinator for the [Community Garden](../projects/community-garden.md).\n\nThis is sample data, not a profile of a real person.", refs: ["sample_project_garden", "sample_rel_alex_leads", "sample_claim_pilot", "sample_meeting_planning"] },
  { id: "sample_project_garden", kind: "page", type: "project", title: "Community Garden", path: "projects/community-garden.md", fields: { status: "active" }, aliases: ["Garden pilot"],
    body: "# Community Garden\n\nA fictional project encompassing a small garden pilot workstream.\n\nProject status is separate from record lifecycle. See [planning meeting](../meetings/planning.md).", refs: ["sample_claim_pilot", "sample_meeting_planning", "sample_person_alex", "sample_company_harbor"] },
  { id: "sample_meeting_planning", kind: "page", type: "meeting", title: "Garden planning meeting", path: "meetings/planning.md", evidence: true,
    body: "# Planning meeting\n\nSample summary: the group chose a small pilot. The retained sample transcript is the evidence, not this summary.", refs: ["sample_person_alex", "sample_project_garden"] },
  { id: "sample_company_harbor", kind: "page", type: "company", title: "Harbor Collective", path: "companies/harbor-collective.md",
    body: "# Harbor Collective\n\nA fictional neighborhood organization supporting the [Community Garden](../projects/community-garden.md).", refs: ["sample_rel_harbor_supports", "sample_project_garden"] },
  { id: "sample_claim_pilot", kind: "claim", type: "decision", title: "Start with a small garden pilot", path: "claims/pilot-decision.md", evidence: true,
    body: "The group decided to begin with a small pilot garden.", refs: ["sample_person_alex", "sample_project_garden", "sample_meeting_planning"] },
  { id: "sample_rel_alex_leads", kind: "relationship", type: "leads", title: "Alex Rivera leads Community Garden", path: "relationships/alex-leads-garden.md",
    body: "Alex coordinates volunteers for the garden pilot.", refs: ["sample_person_alex", "sample_project_garden"] },
  { id: "sample_rel_harbor_supports", kind: "relationship", type: "supports", title: "Harbor Collective supports Community Garden", path: "relationships/harbor-supports-garden.md",
    body: "Harbor Collective lends tools and space to the pilot.", refs: ["sample_company_harbor", "sample_project_garden"] },
];
const byId = Object.fromEntries(RECORDS.map((r) => [r.id, r]));
const EVIDENCE = { filename: "planning-meeting.txt", path: "artifacts/planning-meeting.txt", sha256: "0bd49d2343f5353db59f06782830d200a65ffba912c03a247fff60521b179abf", attribution: "Alex Rivera, fictional planning meeting", meta: "text/plain · 214 bytes · Lines 4–4", quote: "We decided to begin with a small pilot garden." };
const P = (name, label, primitive, description, fields = [], aliases = []) => ({ kind: "page", name, label, primitive, description, fields, aliases, records: RECORDS.filter((r) => r.kind === "page" && r.type === name) });
const R = (name, label, description, from = [], to = []) => ({ kind: "relationship", name, label, description, fromTypes: from, toTypes: to, fields: [], aliases: [], records: RECORDS.filter((r) => r.kind === "relationship" && r.type === name) });
const DEFS = [
  P("person", "Person", "entity", "Someone you know, work with, or want to learn about.", [{ label: "Role" }], ["people", "contact", "individual", "founder", "partner", "partner-profile"]),
  P("company", "Company", "entity", "A business or organization. This broad type also includes products in the current vocabulary.", [], ["yc-company", "product", "org", "people-org", "organization", "startup", "business"]),
  P("concept", "Concept", "concept", "An idea, topic, or definition you want to understand."),
  P("project", "Project", "concept", "An ongoing initiative with a purpose, context, and work to follow.", [{ label: "Status", values: ["active", "paused", "done"] }]),
  P("note", "Note", "concept", "A thought, observation, or useful piece of knowledge to keep."),
  P("media", "Media", "media", "Articles, books, videos, podcasts, and other content you consume.", [], ["article", "video", "essay", "book", "podcast"]),
  P("tweet", "Tweet", "media", "A social post or thread worth keeping and referring back to."),
  P("analysis", "Analysis", "media", "Research and interpretation that help you make sense of a subject."),
  P("source", "Source", "media", "Reference material or a transcript that other knowledge draws on."),
  P("writing", "Writing", "media", "Something you are authoring, from an early draft to a finished piece."),
  P("social-digest", "Social Digest", "temporal", "A collected view of social activity over a period of time."),
  P("deal", "Deal", "temporal", "An investment opportunity, agreement, or transaction in progress."),
  P("email", "Email", "temporal", "An email message or thread, preserved with its context."),
  P("slack", "Slack", "temporal", "A Slack message or conversation worth keeping."),
  P("meeting", "Meeting", "temporal", "A meeting and the discussion, context, and notes around it."),
  P("conversation", "Conversation", "temporal", "An exchange between people, from an interview to an informal chat."),
  P("event", "Event", "temporal", "Something that happened at a particular point in your life or work."),
  P("diary", "Diary", "temporal", "A personal journal entry capturing a day or a moment."),
  P("atom", "Atom", "annotation", "A small, standalone annotation. Separate from an evidence-backed claim."),
  R("partner_of", "Partner Of", "Connects partners or collaborators."),
  R("founded", "Founded", "Connects a founder to what they established.", ["Person"], ["Company"]),
  R("works_at", "Works At", "Connects a person to the organization where they work.", ["Person"], ["Company"]),
  R("invested_in", "Invested In", "Connects an investor to what they invested in."),
  R("advises", "Advises", "Connects an advisor to whom or what they advise.", ["Person"]),
  R("leads", "Leads", "A person leads a project.", ["Person"], ["Project"]),
  R("supports", "Supports", "A company or organization supports a project.", ["Company"], ["Project"]),
  R("relates_to", "Relates To", "A general connection between two pages."),
  R("mentions", "Mentions", "One page refers to another without necessarily discussing it in depth."),
  R("discusses", "Discusses", "One page explores or talks about the subject of another."),
  R("sourced_from", "Sourced From", "Points to the source behind a page.", [], ["Source"]),
  R("derived_from", "Derived From", "Shows which earlier material a page builds on."),
  R("authored", "Authored", "Connects a creator to their work.", ["Person"]),
  R("attributed_to", "Attributed To", "Connects material to the person or source it is credited to."),
  R("attended", "Attended", "Connects a participant to a meeting or event.", ["Person"], ["Meeting", "Event"]),
  R("owes_to", "Owes To", "Connects an obligation with the person or organization it is owed to."),
  R("awaiting_reply_from", "Awaiting Reply From", "Records whose response is still awaited."),
  R("supersedes", "Supersedes", "Indicates that one page takes the place of another."),
  R("redirects_to", "Redirects To", "Points from one page toward its intended destination."),
];
const PAGE_CATS = [
  { id: "entity", label: "People & things", subtitle: "The people and organizations that make up your world.", icon: "◎" },
  { id: "concept", label: "Ideas & projects", subtitle: "What you’re thinking about, learning, and working toward.", icon: "◇" },
  { id: "media", label: "Sources & writing", subtitle: "What you read, watch, create, and draw knowledge from.", icon: "▤" },
  { id: "temporal", label: "Events & conversations", subtitle: "What happened, what was said, and how things unfold.", icon: "◷" },
  { id: "annotation", label: "Annotations", subtitle: "Small observations that add context to the bigger picture.", icon: "✧" },
];
const REL_CATS = [
  { id: "people", label: "People & responsibility", subtitle: "How people and organizations work together.", icon: "◎", names: ["partner_of", "founded", "works_at", "invested_in", "advises", "leads", "supports"] },
  { id: "references", label: "Connections & references", subtitle: "What a page connects to, mentions, or discusses.", icon: "↗", names: ["relates_to", "mentions", "discusses"] },
  { id: "origins", label: "Sources & authorship", subtitle: "Where knowledge comes from and who contributed it.", icon: "▤", names: ["sourced_from", "derived_from", "authored", "attributed_to"] },
  { id: "participation", label: "Participation & follow-up", subtitle: "Who was there, what is owed, and who you’re waiting on.", icon: "◷", names: ["attended", "owes_to", "awaiting_reply_from"] },
  { id: "history", label: "Changes over time", subtitle: "How pages replace or point toward one another.", icon: "↪", names: ["supersedes", "redirects_to"] },
];
const catOf = (d) => d.kind === "page" ? d.primitive : (REL_CATS.find((g) => g.names.includes(d.name)) || {}).id;

/* .knowledge-page button / input / select */
const ctl = { padding: "10px 14px", border: "1px solid var(--border)", borderRadius: 8, font: "inherit", fontSize: 13, color: "var(--text)", background: "var(--bg)", boxSizing: "border-box" };
function KBtn({ pressed, onClick, children, style, disabled }) {
  const [h, setH] = useState(false);
  const hover = h && !disabled;
  return <button type="button" disabled={disabled} aria-pressed={pressed === undefined ? undefined : String(pressed)} onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
    style={{ ...ctl, cursor: disabled ? "default" : "pointer", textAlign: "left", opacity: disabled ? 0.5 : 1, ...(pressed ? { borderColor: "var(--accent)", background: "var(--accent-subtle)" } : null), ...(hover ? { background: "var(--bg-hover)", borderColor: "var(--accent)" } : null), ...style }}>{children}</button>;
}
const pS = { color: "var(--muted)", lineHeight: 1.6, margin: "8px 0" };
const muted = { color: "var(--muted)", fontSize: 12 };
const eyebrow = { fontSize: 11, letterSpacing: ".14em", color: "var(--accent)", margin: "8px 0", textTransform: "uppercase" };
const h2S = { fontSize: 23, margin: "8px 0 16px", color: "var(--text-strong)" };
const h3S = { margin: "24px 0 10px", fontSize: 16, color: "var(--text-strong)" };
const preS = { fontSize: 12, lineHeight: 1.6, whiteSpace: "pre-wrap", overflowWrap: "anywhere", maxHeight: 420, overflow: "auto", padding: 16, background: "var(--bg-accent, var(--bg))", borderRadius: 6, margin: 0, fontFamily: "var(--font-mono)" };
const codeS = { fontSize: 12, overflowWrap: "anywhere", fontFamily: "var(--font-mono)" };
function Raw({ label, text, open }) {
  return <details open={open} style={{ marginTop: 16, fontSize: 13 }}><summary style={{ cursor: "pointer" }}>{label}</summary><pre style={{ ...preS, marginTop: 8 }}>{text}</pre></details>;
}
function rawFile(r) {
  const fm = ["---", "format: knowledge-record-v1", `id: ${r.id}`, "revision: 1", `kind: ${r.kind}`, `title: ${r.title}`, "scope:", "  visibility: sample", "lifecycle: active", r.kind === "page" ? `type: ${r.type}` : null, "---"].filter(Boolean).join("\n");
  return fm + "\n" + r.body;
}

function Detail({ id, onOpen, empty = ["Inspect a record", "Select a record to see its authored text, structured fields, evidence, and connections."] }) {
  const [rawOpen, setRawOpen] = useState(false);
  const box = { minWidth: 0, border: "1px solid var(--border)", borderRadius: 12, padding: 24, position: "sticky", top: 16 };
  const r = byId[id];
  if (!r) return <article style={box}><h2 style={h2S}>{empty[0]}</h2><p style={pS}>{empty[1]}</p></article>;
  return (
    <article style={box} key={id}>
      <p style={eyebrow}>{r.kind} / {r.type}</p>
      <h2 style={h2S}>{r.title}</h2>
      <p style={{ ...pS, ...muted }}>active · Revision 1</p>
      <code style={codeS}>{r.path}</code>
      <h3 style={h3S}>Authored Markdown</h3>
      <pre style={{ ...preS, fontFamily: "inherit", fontSize: 14 }}>{r.body}</pre>
      {r.evidence ? <section>
        <h3 style={h3S}>Source files (1)</h3>
        <article style={{ borderLeft: "2px solid var(--accent)", padding: "12px 16px", margin: "12px 0" }}>
          <strong style={{ color: "var(--text-strong)" }}>{EVIDENCE.filename}</strong>
          <p style={pS}>Verified original</p><p style={pS}>{EVIDENCE.attribution}</p><p style={pS}>{EVIDENCE.meta}</p>
          <blockquote style={{ margin: "12px 0", fontSize: 14, lineHeight: 1.6 }}>{EVIDENCE.quote}</blockquote>
          <KBtn>Download original</KBtn>
          <details style={{ marginTop: 16, fontSize: 13 }}><summary style={{ cursor: "pointer" }}>File reference</summary><code style={{ ...codeS, whiteSpace: "pre-wrap" }}>{EVIDENCE.path + "\nSHA-256: " + EVIDENCE.sha256}</code></details>
        </article>
      </section> : null}
      {r.refs && r.refs.length ? <>
        <h3 style={h3S}>Connected records</h3>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>{r.refs.map((x) => <KBtn key={x} onClick={() => onOpen(x)}>{byId[x].title} · {byId[x].kind}</KBtn>)}</div>
      </> : null}
      <div style={{ marginTop: 16 }}>{rawOpen ? <Raw label="Original file (read only)" text={rawFile(r)} open /> : <KBtn onClick={() => setRawOpen(true)}>Read original file</KBtn>}</div>
      <Raw label="Structured fields & metadata" text={JSON.stringify({ fields: r.fields || {}, aliases: r.aliases || [], scope: { visibility: "sample" }, recorded_at: "2026-09-22T12:00:00Z" }, null, 2)} />
      <Raw label="Identity & observed content hash" text={`${r.id}\nSHA-256: 7f3a…e21c`} />
    </article>
  );
}

function RecordsTab({ selected, setSelected, query, kind, type }) {
  const q = query.trim().toLowerCase(), t = type.trim().toLowerCase();
  const list = RECORDS.filter((r) => (!kind || r.kind === kind) && (!t || r.type.includes(t)) && (!q || [r.title, r.id, ...(r.aliases || [])].some((s) => s.toLowerCase().includes(q))));
  return <>
    <p style={{ ...pS, ...muted }}>{list.length ? `${list.length} records` : "No matching records."}</p>
    <div style={{ display: "grid", gridTemplateColumns: "minmax(240px,.8fr) minmax(0,1.6fr)", gap: 24, alignItems: "start" }}>
      <div style={{ display: "grid", gap: 8 }}>
        {list.map((r) => <KBtn key={r.id} pressed={r.id === selected} onClick={() => setSelected(r.id)} style={{ display: "grid", gap: 7, padding: 16, width: "100%" }}>
          <strong style={{ color: "var(--text-strong)" }}>{r.title}</strong><span style={muted}>{r.kind} · {r.type}</span><small style={muted}>active</small>
        </KBtn>)}
      </div>
      <Detail id={selected} onOpen={setSelected} />
    </div>
  </>;
}

function SearchTab({ ran, selected, setSelected }) {
  if (!ran || !ran.query.trim()) return <p style={pS}>Search accepted, active knowledge by keywords, or resolve an exact identity. Use Records for exhaustive browsing, including records needing attention.</p>;
  const words = ran.query.toLowerCase().split(/\s+/).filter(Boolean);
  const hits = RECORDS.filter((r) => (!ran.kind || r.kind === ran.kind)).filter((r) => { const hay = (r.title + " " + r.body + " " + (r.aliases || []).join(" ")).toLowerCase(); return ran.mode === "any" ? words.some((w) => hay.includes(w)) : words.every((w) => hay.includes(w)); });
  return <div>
    <h2 style={h2S}>Keyword results</h2>
    <p style={{ ...pS, ...muted }}>{hits.length} matches · Ranked results, not an exhaustive inventory</p>
    {!hits.length ? <p style={pS}>No matches. Check your query and filters.</p> : null}
    <div style={{ display: "grid", gridTemplateColumns: "minmax(240px,.8fr) minmax(0,1.6fr)", gap: 24, alignItems: "start" }}>
      <div style={{ display: "grid", gap: 8 }}>
        {hits.map((h) => <article key={h.id} style={{ padding: "1rem", borderBottom: "1px solid var(--border)", overflowWrap: "anywhere" }}>
          <KBtn pressed={h.id === selected} onClick={() => setSelected(h.id)} style={{ fontWeight: 600 }}>{h.title}</KBtn>
          <p style={{ ...pS, ...muted }}>{h.kind} · {h.type} · active</p>
          <pre style={{ ...preS, fontFamily: "inherit", fontSize: 14 }}>{h.body.split("\n").filter(Boolean).slice(-1)[0]}</pre>
          <p style={pS}>Matched {h.title.toLowerCase().includes(words[0]) ? "title, body" : "body"}</p>
          <code style={codeS}>{h.path} · revision 1</code>
          <details style={{ marginTop: 16, fontSize: 13 }}><summary style={{ cursor: "pointer" }}>Citation and source locators</summary><pre style={{ ...preS, marginTop: 8 }}>{h.id + "\nSHA-256: 7f3a…e21c"}</pre></details>
        </article>)}
      </div>
      <Detail id={selected} onOpen={setSelected} empty={["Inspect a result", "Open a result to read the current record and its evidence. Citations below identify the searched revision."]} />
    </div>
  </div>;
}

function TypeCard({ d, openRecord }) {
  const n = d.records.length;
  return <article style={{ minWidth: 0, border: "1px solid var(--border)", borderTop: "2px solid color-mix(in srgb, var(--accent) 60%, var(--border))", borderRadius: 12, padding: 20, background: "var(--card)" }}>
    <h4 style={{ margin: "0 0 8px", fontSize: 15, fontWeight: 600, color: "var(--text-strong)" }}>{d.label}</h4>
    <p style={{ ...pS, margin: 0, fontSize: 13, minHeight: 62 }}>{d.description}</p>
    <div style={{ marginTop: 18, fontSize: 11, color: "var(--muted)" }}><span style={n ? { color: "var(--text)" } : null}>{n} {n === 1 ? "record" : "records"}</span></div>
    <details style={{ marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--border)" }}>
      <summary style={{ cursor: "pointer", fontSize: 12, color: "var(--muted)" }}>Explore type</summary>
      {d.kind === "relationship" ? <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, fontSize: 12, paddingTop: 16 }}>
        <span style={{ borderRadius: 5, padding: "5px 8px", background: "var(--bg-accent, var(--bg))" }}>{d.fromTypes.join(" or ") || "Any page"}</span><span>→</span><span style={{ borderRadius: 5, padding: "5px 8px", background: "var(--bg-accent, var(--bg))" }}>{d.toTypes.join(" or ") || "Any page"}</span>
      </div> : null}
      {d.fields.length ? <><h5 style={h5S}>Details you can add</h5><ul style={{ listStyle: "none", margin: 0, padding: 0 }}>{d.fields.map((f) => <li key={f.label} style={{ fontSize: 12, padding: "6px 0" }}><strong>{f.label}</strong><span style={{ marginLeft: 8, color: "var(--muted)", fontSize: 10 }}>Optional</span>{f.values ? <p style={{ ...pS, fontSize: 12 }}>{f.values.join(" · ")}</p> : null}</li>)}</ul></> : null}
      {d.aliases.length ? <><h5 style={h5S}>Search terms</h5><p style={{ ...pS, fontSize: 11, marginBottom: 12 }}>These terms also find this type. They aren’t separate types or roles.</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>{d.aliases.map((a) => <span key={a} style={{ fontSize: 10, padding: "4px 7px", border: "1px solid var(--border)", borderRadius: 5 }}>{a.replaceAll("-", " ")}</span>)}</div></> : null}
      <h5 style={h5S}>In your vault</h5>
      {n ? <div style={{ display: "grid", gap: 6 }}>{d.records.map((r) => <KBtn key={r.id} onClick={() => openRecord(r.id)} style={{ fontSize: 12, padding: "8px 10px" }}>{r.title}</KBtn>)}</div> : <p style={{ ...pS, fontSize: 12 }}>No records of this type yet.</p>}
    </details>
  </article>;
}
const h5S = { fontSize: 11, textTransform: "uppercase", letterSpacing: ".06em", margin: "22px 0 10px", color: "var(--text-strong)" };

function OntologyTab({ openRecord }) {
  const [mode, setMode] = useState("page");
  const [sel, setSel] = useState("all");
  const defs = DEFS.filter((d) => d.kind === mode);
  const groups = (mode === "page" ? PAGE_CATS : REL_CATS).filter((g) => defs.some((d) => catOf(d) === g.id));
  const seg = (m, label) => <button type="button" aria-pressed={String(mode === m)} onClick={() => { setMode(m); setSel("all"); }} style={{ ...ctl, cursor: "pointer", textAlign: "center", borderColor: mode === m ? "var(--border)" : "transparent", background: mode === m ? "var(--bg)" : "transparent", boxShadow: mode === m ? "var(--shadow-sm)" : "none" }}>{label}</button>;
  return <div style={{ display: "grid", gap: 28 }}>
    <div style={{ display: "flex", justifyContent: "space-between", gap: 20, alignItems: "center" }}>
      <div role="group" aria-label="Ontology vocabulary" style={{ display: "flex", padding: 4, borderRadius: 11, background: "var(--bg-accent, var(--bg))", border: "1px solid var(--border)" }}>{seg("page", "Page types")}{seg("relationship", "Relationships")}</div>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "205px minmax(0,1fr)", gap: 30, alignItems: "start" }}>
      <nav aria-label="Ontology categories" style={{ display: "grid", gap: 6, position: "sticky", top: 20 }}>
        {[{ id: "all", label: "All categories", icon: "⊞" }, ...groups].map((g) => {
          const on = sel === g.id;
          return <KBtn key={g.id} pressed={on} onClick={() => setSel(g.id)} style={{ display: "flex", gap: 9, alignItems: "center", borderColor: "transparent", padding: "12px 10px", background: on ? "var(--accent-subtle)" : "transparent", fontSize: 12 }}>
            <span aria-hidden="true" style={{ color: "var(--accent)", fontSize: 17, width: 19, textAlign: "center", flexShrink: 0 }}>{g.icon}</span><span>{g.label}</span>
            <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--muted)" }}>{defs.filter((d) => g.id === "all" || catOf(d) === g.id).length}</span>
          </KBtn>;
        })}
      </nav>
      <div style={{ display: "grid", gap: 34, minWidth: 0 }}>
        {groups.filter((g) => sel === "all" || sel === g.id).map((g) => {
          const items = defs.filter((d) => catOf(d) === g.id);
          return <section key={g.id} style={{ minWidth: 0 }}>
            <header style={{ display: "flex", alignItems: "center", gap: 13, marginBottom: 16 }}>
              <span aria-hidden="true" style={{ display: "grid", placeItems: "center", width: 42, height: 42, flexShrink: 0, fontSize: 25, borderRadius: 12, color: "var(--accent)", background: "var(--accent-subtle)" }}>{g.icon}</span>
              <div><h3 style={{ fontSize: 17, margin: 0, letterSpacing: "-.015em", color: "var(--text-strong)" }}>{g.label}</h3><p style={{ ...pS, fontSize: 12, margin: "4px 0 0" }}>{g.subtitle}</p></div>
              <span style={{ marginLeft: "auto", fontSize: 12, color: "var(--muted)" }}>{items.length}</span>
            </header>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0,1fr))", gap: 12, alignItems: "start" }}>{items.map((d) => <TypeCard key={d.name} d={d} openRecord={openRecord} />)}</div>
          </section>;
        })}
      </div>
    </div>
  </div>;
}

function ActivityTab() {
  return <div>
    <h2 style={h2S}>Activity & issues</h2>
    <p style={pS}>Local Git history: disabled. Sample vaults are not checkpointed.</p>
    <p style={pS}>No recorded mutations in this scope.</p>
    <p style={pS}>No validation issues found.</p>
  </div>;
}

export function KnowledgeScreen() {
  const [tab, setTab] = useState("records");
  const [selected, setSelected] = useState("sample_claim_pilot");
  const [query, setQuery] = useState(""), [kind, setKind] = useState(""), [type, setType] = useState("");
  const [sq, setSq] = useState({ query: "", mode: "all", kind: "", lifecycle: "active" });
  const [ran, setRan] = useState(null);
  const go = (t) => { setTab(t); setSelected(""); };
  const openRecord = (id) => { setTab("records"); setQuery(""); setKind(""); setType(""); setSelected(id); };
  const lbl = { display: "grid", gap: ".25rem", fontSize: ".85rem", color: "var(--muted)" };
  return (
    <section style={{ width: "100%", maxWidth: 1280, margin: "0 auto", padding: 32, display: "grid", gap: 20, color: "var(--text)", fontFamily: "var(--font-body)", boxSizing: "border-box" }}>
      <header>
        <p style={eyebrow}>KNOWLEDGE / EXPLORER</p>
        <h1 style={{ margin: "4px 0 12px", fontSize: "clamp(24px, 3vw, 36px)", lineHeight: 1.2, letterSpacing: "-.03em", color: "var(--text-strong)" }}>A clearer view of what you know.</h1>
        <p style={pS}>Browse records, follow their evidence, and inspect the definitions behind them.</p>
      </header>
      <div style={{ padding: "16px 20px", border: "1px solid var(--border)", borderLeft: "3px solid var(--accent)", borderRadius: 8, background: "var(--bg-accent, var(--bg))" }}>
        <strong style={{ color: "var(--text-strong)" }}>Sample vault · Read only</strong>
        <p style={{ ...pS, marginBottom: 0 }}>Fictional people and projects for exploring the data model. No private agent vault is connected.</p>
      </div>
      <div role="status" style={{ fontSize: 13, color: "var(--muted)" }}>7 sample records</div>
      <nav aria-label="Knowledge views" style={{ display: "flex", gap: 10, flexWrap: "wrap", borderBottom: "1px solid var(--border)", paddingBottom: 12 }}>
        {[["records", "Records"], ["search", "Search"], ["ontology", "Ontology"], ["diagnostics", "Activity & issues"]].map(([k, l]) => <KBtn key={k} pressed={tab === k} onClick={() => go(k)}>{l}</KBtn>)}
      </nav>
      {tab === "records" ? <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <input type="search" placeholder="Find by name, alias, or ID" aria-label="Filter records by name, alias, or ID" value={query} onChange={(e) => setQuery(e.target.value)} style={{ ...ctl, flex: 1, minWidth: 200 }} />
        <select aria-label="Record kind" value={kind} onChange={(e) => setKind(e.target.value)} style={ctl}><option value="">All record kinds</option><option value="page">Pages</option><option value="claim">Claims</option><option value="relationship">Relationships</option></select>
        <input placeholder="Type or ontology alias" aria-label="Filter by type or ontology alias" value={type} onChange={(e) => setType(e.target.value)} style={{ ...ctl, flex: 1, minWidth: 200 }} />
        <KBtn>Refresh</KBtn>
      </div> : null}
      {tab === "search" ? <form onSubmit={(e) => { e.preventDefault(); setRan({ ...sq }); setSelected(""); }} style={{ display: "flex", flexWrap: "wrap", gap: ".65rem", alignItems: "end", width: "100%" }}>
        <input type="search" maxLength={500} placeholder="Search titles, aliases and authored text" aria-label="Knowledge search query" value={sq.query} onChange={(e) => setSq({ ...sq, query: e.target.value })} style={{ ...ctl, flex: "1 1 100%" }} />
        <label style={lbl}>Match<select value={sq.mode} onChange={(e) => setSq({ ...sq, mode: e.target.value })} style={ctl}><option value="all">All words</option><option value="any">Any word</option><option value="phrase">Phrase</option><option value="exact">Exact ID, name or alias</option></select></label>
        <label style={lbl}>Kind<select value={sq.kind} onChange={(e) => setSq({ ...sq, kind: e.target.value })} style={ctl}><option value="">All kinds</option><option value="page">Pages</option><option value="claim">Claims</option><option value="relationship">Relationships</option></select></label>
        <label style={lbl}>Lifecycle<select value={sq.lifecycle} onChange={(e) => setSq({ ...sq, lifecycle: e.target.value })} style={ctl}><option value="active">Active</option><option value="superseded">Superseded</option><option value="all">Active and superseded</option></select></label>
        <input placeholder="Type or ontology alias" aria-label="Type or ontology alias" style={ctl} />
        <input placeholder="Exact tag" aria-label="Exact tag" style={ctl} />
        <button type="submit" style={{ ...ctl, cursor: "pointer" }}>Search</button>
      </form> : null}
      <div>
        {tab === "records" ? <RecordsTab selected={selected} setSelected={setSelected} query={query} kind={kind} type={type} /> : null}
        {tab === "search" ? <SearchTab ran={ran} selected={selected} setSelected={setSelected} /> : null}
        {tab === "ontology" ? <OntologyTab openRecord={openRecord} /> : null}
        {tab === "diagnostics" ? <ActivityTab /> : null}
      </div>
    </section>
  );
}
