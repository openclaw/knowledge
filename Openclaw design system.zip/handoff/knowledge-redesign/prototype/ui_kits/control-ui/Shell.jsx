import React, { useState } from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { IconButton } from "../../components/core/IconButton.jsx";
import { NavItem } from "../../components/navigation/NavItem.jsx";
import { SessionRow } from "../../components/navigation/SessionRow.jsx";
import { SectionHeader } from "../../components/navigation/SectionHeader.jsx";
/* Source: layout.css .shell (grid 258px | 1fr, 100vh), .sidebar (--sidebar-bg), .sidebar-shell (pad 9 10 8), .sidebar-brand (min-h 34, pad 0 2 10 0; 28px avatar/icons), .sidebar-brand__actions, .sidebar-nav, .sidebar-sessions (pad 0 8, gap 8, margin-top space-4), .sidebar-shell__footer (53px, hairline 55%), .sidebar-identity-card (28px avatar, 13.5/600 name, muted gateway line), .content (pad 16 20 32, scroll). DEFAULT_SIDEBAR_ENTRIES: agents-home, dashboards, systems, cron, plugins (app-navigation.ts). */
const PAGES = [
  { id: "home", icon: "home", label: "Home" },
  { id: "dashboards", icon: "layoutDashboard", label: "Dashboards" },
  { id: "systems", icon: "server", label: "Systems" },
  { id: "cron", icon: "clock", label: "Automations" },
  { id: "plugins", icon: "puzzle", label: "Plugins" },
  { id: "sessions", icon: "listChecks", label: "Sessions" },
  { id: "knowledge", icon: "book", label: "Knowledge" }, // plugin nav (knowledge: registerNavigation, icon "bookOpen")
];
export const SESSIONS = [
  { key: "s1", title: "Refactor gateway auth", subtitle: "Running · 2m", running: true, icon: "messageSquare" },
  { key: "s2", title: "Weekly digest", icon: "clock", color: "green", unread: true },
  { key: "s3", title: "Team standup notes", icon: "users" },
  { key: "s4", title: "Deploy notes for 2026.9", color: "purple" },
  { key: "s5", title: "iMessage: Mario", icon: "messageSquare" },
  { key: "s6", title: "Browser QA sweep", icon: "globe" },
];
export function Shell({ route, onNavigate, activeSession, onOpenSession, children, chat }) {
  const [recentOpen, setRecentOpen] = useState(true);
  const [brandHover, setBrandHover] = useState(false);
  const [idHover, setIdHover] = useState(false);
  return (
    <div style={{ height: "100vh", display: "grid", gridTemplateColumns: "258px minmax(0,1fr)", gridTemplateRows: "1fr", overflow: "hidden", background: "var(--bg)", color: "var(--text)", font: "400 14px/1.55 var(--font-body)", letterSpacing: "-0.01em" }}>
      <nav style={{ position: "relative", display: "flex", flexDirection: "column", minHeight: 0, minWidth: 0, overflow: "hidden", background: "var(--sidebar-bg)" }}>
        <div style={{ display: "flex", flexDirection: "column", minHeight: 0, flex: 1, padding: "9px 10px 8px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 2, minHeight: 34, padding: "0 2px 10px 0", flexShrink: 0 }}>
            <button type="button" onMouseEnter={() => setBrandHover(true)} onMouseLeave={() => setBrandHover(false)} style={{ display: "flex", alignItems: "center", gap: 6, flex: "0 1 auto", minWidth: 0, padding: "5px 6px", border: 0, borderRadius: "var(--radius-md)", background: brandHover ? "color-mix(in srgb, var(--bg-hover) 84%, transparent)" : "transparent", textAlign: "left", cursor: "var(--cursor-action)", font: "inherit", color: "inherit" }}>
              <span style={{ width: 28, height: 28, flex: "none", borderRadius: "var(--radius-full)", background: "var(--secondary)", color: "var(--secondary-foreground)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 19, fontWeight: 600, lineHeight: 1 }}>🦞</span>
              <span style={{ display: "flex", alignItems: "center", minWidth: 0, color: "var(--text-strong)", fontSize: 14, fontWeight: 650, lineHeight: 1.2, whiteSpace: "nowrap" }}>
                <span style={{ paddingInlineEnd: 8, overflow: "hidden" }}>Molty</span>
                <span style={{ display: "inline-flex", color: "var(--muted)", opacity: 0.58 }}><Icon name="chevronsUpDown" size={12} strokeWidth={1.5} /></span>
              </span>
            </button>
            <div style={{ display: "flex", alignItems: "center", marginInlineStart: "auto", flex: "0 0 auto" }}>
              <IconButton icon="panelLeftClose" label="Collapse sidebar (⌘B)" size={28} />
              <IconButton icon="search" label="Search (⌘K)" size={28} />
              <IconButton icon="plus" label="New conversation" size={28} iconSize={20} />
            </div>
          </div>
          <div style={{ minHeight: 0, flex: 1, display: "flex", flexDirection: "column", overflowY: "auto", overflowX: "hidden", marginRight: -10, paddingRight: 10 }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {PAGES.map((p) => <NavItem key={p.id} icon={p.icon} label={p.label} active={route === p.id} onClick={() => onNavigate(p.id)} />)}
            </div>
            <section style={{ display: "flex", flexDirection: "column", gap: 8, padding: "0 8px", marginTop: 16 }}>
              <SectionHeader label="Recent" collapsed={!recentOpen} onToggle={() => setRecentOpen(!recentOpen)} actions={<IconButton icon="listFilter" label="Sort" size={22} iconSize={12} />} />
              {recentOpen ? <div style={{ display: "flex", flexDirection: "column", gap: 0, margin: "0 -8px" }}>
                {SESSIONS.map((s) => <SessionRow key={s.key} {...s} active={route === "chat" && activeSession === s.key} onClick={() => onOpenSession(s.key)} />)}
              </div> : null}
            </section>
          </div>
          <div style={{ flexShrink: 0, minHeight: 53, marginInline: -10, marginBlockEnd: -8, padding: "4px 10px", borderBlockStart: "1px solid color-mix(in srgb, var(--border) 55%, transparent)" }}>
            <div style={{ position: "relative", display: "flex", alignItems: "center", gap: 4, minHeight: 44, padding: "3px 8px", paddingInlineEnd: 44 }}>
              <button type="button" onMouseEnter={() => setIdHover(true)} onMouseLeave={() => setIdHover(false)} style={{ display: "flex", alignItems: "center", gap: 8, flex: "1 1 auto", minWidth: 0, padding: "3px 6px", border: 0, borderRadius: "var(--radius-md)", background: idHover ? "color-mix(in srgb, var(--bg-hover) 84%, transparent)" : "transparent", color: "var(--text)", font: "inherit", textAlign: "left", cursor: "var(--cursor-action)" }}>
                <span style={{ width: 28, height: 28, flex: "none", borderRadius: "var(--radius-full)", background: "var(--accent-2-subtle)", color: "var(--accent-2)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, border: "1px solid var(--border)" }}>PS</span>
                <span style={{ display: "flex", flexDirection: "column", flex: "1 1 auto", minWidth: 0 }}>
                  <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: "var(--text-strong)", fontSize: 13.5, fontWeight: 600, lineHeight: "18px" }}>Peter</span>
                  <span style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--muted)", fontSize: 11, lineHeight: "14px" }}><span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--ok)" }} />studio-mac · 2026.9.1</span>
                </span>
              </button>
              <span style={{ position: "absolute", top: "50%", right: 8, transform: "translateY(-50%)", display: "flex", height: 32, alignItems: "center", gap: 8 }}>
                <IconButton icon="settings" label="Settings" size={32} iconSize={18} />
              </span>
            </div>
          </div>
        </div>
      </nav>
      <main style={{ minHeight: 0, minWidth: 0, display: "flex", flexDirection: "column", overflowY: chat ? "hidden" : "auto", overflowX: "hidden", padding: chat ? 0 : "16px 20px 32px", gap: chat ? 0 : 20 }}>
        {children}
      </main>
    </div>
  );
}
