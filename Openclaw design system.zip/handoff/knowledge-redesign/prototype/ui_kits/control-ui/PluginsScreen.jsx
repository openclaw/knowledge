import React, { useState } from "react";
import { Icon } from "../../components/core/Icon.jsx";
import { Button } from "../../components/core/Button.jsx";
import { IconButton } from "../../components/core/IconButton.jsx";
import { Chip } from "../../components/core/Chip.jsx";
import { PageHeader } from "../../components/settings/PageHeader.jsx";
import { SettingsSection } from "../../components/settings/SettingsSection.jsx";
import { SettingsRow } from "../../components/settings/SettingsRow.jsx";
import { HubTabs } from "../../components/navigation/HubTabs.jsx";
import { PluginCard } from "../../components/chat/PluginCard.jsx";
import { StatusDot } from "../../components/core/StatusDot.jsx";
import { Toggle } from "../../components/core/Toggle.jsx";
/* Source: plugins-hub-header.ts (title | tabs | secondary icon action), catalog-results.ts (.plugin-catalog-search 44px input with leading icon, .plugin-catalog-chips, .plugin-catalog-section h2 lg + "View all" ghost, .plugin-catalog-grid 4 cols), plugins.css; installed list follows settings-design.md rows with toggle. */
const INSTALLED = [
  { name: "Memory", author: "openclaw", official: true, state: "enabled", summary: "Long-term memory across sessions and channels.", icon: "brain" },
  { name: "GitHub", author: "openclaw", official: true, state: "enabled", summary: "Pull requests, issues and reviews from chat.", icon: "gitPullRequest" },
  { name: "Knowledge", author: "openclaw", state: "enabled", summary: "Evidence-backed knowledge, inspectable in OpenClaw.", icon: "book" },
  { name: "Browser", author: "steipete", state: "needs-setup", summary: "Drive a headless browser for research and QA.", icon: "globe" },
];
const CATALOG = [
  { name: "Workboard", author: "openclaw", official: true, summary: "Kanban boards your agent can plan and update.", icon: "kanban" },
  { name: "Calendar", author: "vincentkoc", summary: "Read and schedule events from Google or iCloud.", icon: "calendarClock" },
  { name: "Voice", author: "openclaw", official: true, summary: "Talk to your assistant with realtime speech.", icon: "mic" },
  { name: "Cloud workers", author: "openclaw", official: true, summary: "Run long tasks on remote sandboxes.", icon: "cloud" },
  { name: "Secrets", author: "obviyus", summary: "Store keys in your OS keychain, never in config.", icon: "key" },
  { name: "Dreams", author: "openclaw", official: true, summary: "Nightly reflection and diary entries.", icon: "moon" },
  { name: "Terminal", author: "openclaw", official: true, summary: "Operator terminal docked next to the chat.", icon: "squareTerminal" },
  { name: "Custodian", author: "openclaw", official: true, summary: "Health checks and self-repair for the gateway.", icon: "shieldCheck" },
];
export function PluginsScreen() {
  const [tab, setTab] = useState("plugins");
  const [cat, setCat] = useState("all");
  const [on, setOn] = useState({ Memory: true, GitHub: true, Knowledge: true, Browser: false });
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <PageHeader title="Plugins" subtitle="Extend what your assistant can do." learnMoreHref="https://docs.openclaw.ai/plugins/manage-plugins" tabs={<HubTabs value={tab} onChange={setTab} tabs={[{ value: "plugins", label: "Plugins", count: INSTALLED.length }, { value: "skills", label: "Skills" }, { value: "skill-workshop", label: "Workshop" }]} />} actions={<IconButton variant="bordered" icon="download" label="Install from path or URL" size={34} iconSize={18} />} />
      <div style={{ width: "100%", maxWidth: 1120, margin: "0 auto", display: "flex", flexDirection: "column", gap: 40, padding: "12px 16px 40px" }}>
        <SettingsSection title="Installed" description="Plugins loaded by this Gateway. Toggle to enable without uninstalling.">
          {INSTALLED.map((p, i) => (
            <SettingsRow key={p.name} first={i === 0} nav title={<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><span style={{ width: 28, height: 28, display: "grid", placeItems: "center", border: "1px solid var(--border)", borderRadius: 8, background: "var(--bg)", color: "var(--muted)" }}><Icon name={p.icon} size={14} strokeWidth={1.5} /></span>{p.name}{p.official ? <span style={{ color: "var(--info)", display: "inline-flex" }}><Icon name="badgeCheck" size={15} /></span> : null}</span>} description={p.summary}
              control={<><StatusDot tone={p.state === "enabled" ? "ok" : p.state === "needs-setup" ? "warn" : "muted"} label={p.state === "enabled" ? "Enabled" : p.state === "needs-setup" ? "Setup required" : "Disabled"} /><span onClick={(e) => e.stopPropagation()}><Toggle checked={!!on[p.name]} onChange={(v) => setOn({ ...on, [p.name]: v })} ariaLabel={"Enable " + p.name} /></span></>} />
          ))}
        </SettingsSection>
        <section style={{ display: "grid", gap: 16 }} aria-label="Explore">
          <label style={{ position: "relative", width: "100%" }}>
            <span style={{ position: "absolute", top: "50%", left: 11, zIndex: 1, display: "inline-flex", width: 16, color: "var(--muted)", pointerEvents: "none", transform: "translateY(-50%)" }}><Icon name="search" size={16} strokeWidth={1.7} /></span>
            <input placeholder="Search ClawHub for plugins…" style={{ width: "100%", minHeight: 44, padding: "8px 12px 8px 34px", border: "1px solid var(--input)", borderRadius: "var(--radius-md)", background: "var(--card)", color: "var(--text)", fontSize: 14, fontFamily: "var(--font-body)", outline: "none", boxShadow: "inset 0 1px 0 var(--card-highlight)" }} />
          </label>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {[["all", "All"], ["featured", "Featured", "star"], ["trending", "Trending", "zap"], ["productivity", "Productivity"], ["coding", "Coding"], ["channels", "Channels"], ["media", "Media"]].map(([v, l, ic]) => <Chip key={v} variant="catalog" icon={ic} active={cat === v} onClick={() => setCat(v)}>{l}</Chip>)}
          </div>
          <div style={{ display: "grid", gap: 24 }}>
            <section style={{ display: "grid", gap: 12 }}>
              <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}><h2 style={{ margin: 0, color: "var(--text-strong)", fontSize: 16, fontWeight: 600 }}>Featured</h2><Button variant="ghost" size="sm" style={{ padding: "4px 0" }}>View all</Button></header>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0,1fr))", gap: 12 }}>{CATALOG.slice(0, 4).map((p) => <PluginCard key={p.name} {...p} action="Install" />)}</div>
            </section>
            <section style={{ display: "grid", gap: 12 }}>
              <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}><h2 style={{ margin: 0, color: "var(--text-strong)", fontSize: 16, fontWeight: 600 }}>Trending</h2><Button variant="ghost" size="sm" style={{ padding: "4px 0" }}>View all</Button></header>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0,1fr))", gap: 12 }}>{CATALOG.slice(4, 8).map((p) => <PluginCard key={p.name} {...p} action="Install" />)}</div>
            </section>
          </div>
        </section>
      </div>
    </div>
  );
}
