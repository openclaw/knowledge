# Knowledge Control UI redesign: design handoff

Suggested location in the plugin repo: `docs/design/control-ui-redesign/`.

```
REPORT.md          Architecture changes this design needs (backend, format, ontology, host SDK, skills)
README.md          This file: how to run the prototype + screen-by-screen spec
prototype/         Interactive HTML/React mock of the Control UI with the Knowledge page
```

## Run the prototype

The page fetches its JSX at runtime, so serve it over HTTP instead of opening it as a file:

```sh
cd prototype
npx serve .          # or: python3 -m http.server
```

Then open:

- `ui_kits/control-ui/knowledge-v2.html`: **the redesign** (interactive)
- `ui_kits/control-ui/knowledge-current.html`: the page as currently shipped, rebuilt from `src/control-ui.ts` + `control-ui.css` for comparison

Both render inside the full Control UI shell (sidebar, Chat, Sessions, Plugins). The chat hand-off buttons actually navigate to Chat with a message pre-filled. Needs a network connection for React/Babel from unpkg. View at ≥1280px wide; the mock doesn't adapt to narrow screens yet.

**Main source file:** `prototype/ui_kits/control-ui/KnowledgeV2Screen.jsx`. It's one file with the mock data at the top and one function per view (`Recent`, `Browse`, `Entity`, `ClaimRow`, `Search`). Styles are inline and use host CSS variables (`--card`, `--border`, `--muted`, `--accent-subtle`, …) defined in `prototype/tokens/`. Host components used: `PageHeader`, `HubTabs`, `SettingsSection`/`SettingsRow`, `DataTable`, `Segmented`, `Chip`, `StatusDot`, `Button`, `IconButton`, `Icon`. These mirror Control UI source (`ui/src/styles/*.css`). See REPORT §6.2 for how a plugin could rely on them.

All data is made up (Mario Ferrante, Northwind Labs, etc.). The counts (2,418 pages, 6,905 claims) show scale and aren't real.

---

## Design principles

1. **The job is checking what the agent saved.** The page opens on what's new, not on a record inventory.
2. **People and things before storage concepts.** Users think in people, projects and meetings, not in page, claim or relationship. Storage details sit behind "File details".
3. **Evidence is the trust signal.** Every claim says whether it came from a source, from the user, or was the agent's inference. The quote is one click away.
4. **Chat is the only way to change things.** The UI never writes. Corrections, identifying people and questions all open Chat with a message pre-filled.
5. **Use the host's look.** Control UI headers, tabs, sections, tables and chips, not plugin-local styling.
6. **Honest labels.** Browse is a complete list and says so. Search is ranked and says so.

---

## Screens

### Header (all views)

- `PageHeader`: title "Knowledge", subtitle "What Molty has saved, and where it came from." (the agent name comes from the host).
- `HubTabs`: **Recent** | **Browse** (count badge = total pages). No tab is selected on an entity page.
- Actions: `StatusDot` "Live" (live watcher state; "Reconnecting…" or "Offline" otherwise), plus a bordered icon button that opens **Ontology & vault settings** (a secondary page, not designed yet; the current ontology atlas can live there).

### 1. Recent (default)

Top to bottom:

1. **Search box** (44px, full width). Placeholder "Find a person, project, or anything Molty saved…"; `/` focuses it.
   - Typing shows a dropdown: **Exact matches** (up to 5: type tile, title, type label, claim count) → opens the entity page.
   - Last row: "Search all text for '…'" → Browse filtered to that query. *(Backend: REPORT §4.4.)*
2. **Needs a look** (`SettingsSection` with rows). Appears only when there's something to show:
   - An unidentified mention: "'Sam' in Team standup — Sep 22", "Mentioned 4 times, but doesn't match anyone Molty knows." → **Tell Molty who** (chat hand-off).
   - Inferred claims: "1 claim is Molty's inference", "Saved without a quoted source. Worth a glance." → **Review**.
   - Room for: unverified sources, conflicts, saves not yet searchable. *(REPORT §3.1, §4.5.)*
3. **Feed**, grouped by day ("Today", "Yesterday", dates), then by **conversation**. Each group is a card:
   - Header: chat icon, conversation title, "8 saved · 2h ago · Meeting transcript", ghost button **Open conversation** (`host.sessions.open`).
   - Rows, one per saved item:
     - **New / updated page**: type tile, title, type label (+ change note, e.g. "Added alias 'Mario'"), chip **New** (accent) or **Updated**. Click → entity page.
     - **Claim**: see *Claim row* below.
     - **Relationships**: collapsed into one line ("Mario Ferrante, Lena Park and Dev Shah attended · 3 connections").
     - **Unidentified mention**: warn-tinted row, "'Sam' couldn't be matched to a person", **Tell Molty who**.
   - Edits made outside OpenClaw appear as their own group, "Edited outside OpenClaw".
   *(Backend: REPORT §3.2, §4.1.)*

### 2. Claim row (shared component)

Used in the feed, on entity pages and in Browse › Claims.

- **Collapsed**: claim-type icon (decision = flag, commitment = list-checks, preference = star, fact = info, opinion = brain), claim text (14px, strong), then a meta line:
  - type label ("Decision");
  - **where it came from**:
    - *From source* (paperclip, muted);
    - *You told Molty* (user icon, accent-2);
    - *Molty inferred* (spark, warn);
  - "About" + linked entity names (hidden on an entity page when the claim is only about that entity);
  - relative time.
  - Chevron on the right.
- **Expanded** (click anywhere on the row):
  - **Source or user origin**: a quote block with "— Speaker", mono `file · line N–M` (or "Chat message in '…'" for user claims), and ✓ "Original retained" when verified.
  - **Inferred**: a warn-tinted box, "**No quoted source.** Inferred from …" (the agent's stated reason).
  - Actions: **Open '<conversation>'**, **Original file** (download, when there's a file), ghost **Correct in chat** (pre-fills "This isn't right: '<claim>' — ").
- Superseded or withdrawn claims (after the corrections milestone): struck through or muted, with "Replaced by …" or "Withdrawn: <reason>". Not in the mock yet.

### 3. Entity page

Reached from the feed, search, Browse, connections, or "About" links.

- **Breadcrumb**: "← Knowledge › People" (plural of the type).
- **Header**:
  - 48px type tile;
  - title (26px / 650);
  - a meta line: type label, typed fields as "Role *Infra lead, Northwind Labs*", "Also called [Mario]" alias chips;
  - on the right, **Ask Molty** (pre-fills "What do you know about <title>?").
- **Unidentified-mention banner** (warn tint) when the page has any: "'Sam' spoke in this meeting but isn't linked to anyone." → **Tell Molty who**.
- **Two columns**: the main column is fluid, the side rail is 300px and sticky.
  - **Main**:
    - Summary paragraph (15px, max ~62ch) + "Summary written by Molty · updated 5h ago · revision 4". This is the page body rendered as safe Markdown; see REPORT §10 Q3.
    - **What Molty knows · N claims**: one card with sub-headers per claim type ("Decisions · 2", "Commitments · 1", …), each followed by claim rows. Empty state: "No claims about X yet. Tell Molty in chat and it will save them here."
  - **Rail**:
    - **Connections**: rows with a small type tile, the relationship label (muted, 11px, reverse wording for incoming, e.g. "Led by"), and the target title. Click → that entity. Typed relationships and wikilink-only links should be told apart (e.g. a "Mentioned in" group for the latter). *(REPORT §4.2, §5.1.)*
    - **Learned in**: conversations with a relative time. Click → open that conversation.
    - **File details** (collapsed by default): File path, ID, Revision, History ("Committed · 3f9a2c1"), buttons **View Markdown** and **History**. Everything from the current page's raw views lives here.

### 4. Browse

- **Left, 210px, sticky**: type filter.
  - "Everything" with the total count, then the ontology `primitive` categories as small uppercase headings (People & things, Ideas & projects, Sources & writing, Events & conversations, Annotations).
  - Each type row has a 20px tile, the plural label and a mono count.
  - Types with zero records are hidden, with a "12 empty types hidden" note.
- **Right**: one surface.
  - Toolbar: filter input ("Filter by name or alias" or "Search claim text"), `Segmented` **Pages | Claims**, and a bordered filter button for more filters (claim type, where claims came from, conversation, updated since, needs attention).
  - **Pages**: `DataTable`. Columns:
    - **Name**: tile + title;
    - **Type**;
    - **Claims**: mono;
    - **Connections**: mono;
    - **Last saved**: default sort, descending;
    - **Learned in**: the conversation title.
    - Row click → entity page. Footer: "1–25 of 2,418 · complete list", Previous/Next.
  - **Claims**: claim rows, footer "1–25 of 6,905 claims · complete list".
  *(Backend: REPORT §4.3.)*

### 5. Chat hand-off (all "Tell Molty", "Correct", "Ask", "Open conversation")

In the prototype these navigate to Chat with a message pre-filled (or open the named conversation). In production this needs the host API in REPORT §6.1. Nothing is sent automatically; the user reviews and presses send. Ideally the record or claim reference travels as a structured chip, not only as quoted text.

---

## Visual reference

| Element | Value (host tokens) |
|---|---|
| Content width | max 1120px, centered, 16px side padding |
| Surfaces | `--card`, 1px `--border` at 85%, `--radius-lg`; row separators `--border` at 60% |
| Section headings | 11px / 600, uppercase, 0.06em tracking, `--muted-strong` |
| Body / meta | 14px `--text` or `--text-strong`; 12px `--muted` |
| Type tiles | 24–48px, `--radius-sm` (`--radius-md` above 32px), tone text on tone-subtle fill |
| Type tones | person `--accent-2` · company `--info` · project `--ok` · concept `--warn` · meeting `--accent` · others `--muted-strong` on `--bg-hover` |
| Origin colors | source `--muted` · user `--accent-2` · inferred `--warn` |
| Row hover | `--bg-hover` at 60% |
| Needs-attention tint | `--warn-subtle` (55% in feed rows) |

Icons are host Lucide names: `circleUser`, `box`, `kanban`, `spark`, `users`, `mail`, `paperclip`, `fileText`, `flag`, `listChecks`, `star`, `info`, `brain`, `link`, `shieldQuestion`, `messageSquare`, `badgeCheck`, `book`. There's no `bookOpen` in the host set; see REPORT §6.3.

## Not designed yet

- Ontology & vault settings page (the current ontology atlas is a good starting point).
- Loading, empty-vault, disconnected and error states. Keep the current page's wording and the distinctions the spec requires: loading, empty, disconnected, invalid, unavailable.
- Superseded and withdrawn claim presentation.
- Narrow/mobile layout.
- Sample-vault indicator (suggest a `Chip` "Sample vault" next to Live, replacing today's banner).
