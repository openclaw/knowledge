import React from "react";
/* Source: settings.css .settings-section (gap space-3), __heading (xs, 600, .06em, uppercase, muted-strong), __desc, __actions; .settings-group is the only surface. */
export function SettingsSection({ title, description, actions, notice, children, danger }) {
  return (
    <section style={{ display: "flex", flexDirection: "column", gap: 12, minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: description ? "flex-start" : "center", justifyContent: "space-between", gap: 12 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 4, minWidth: 0, flex: "1 1 auto" }}>
          <h2 style={{ margin: 0, fontSize: 11, fontWeight: 600, letterSpacing: "0.06em", color: "var(--muted-strong)", textTransform: "uppercase", fontFamily: "var(--font-body)" }}>{title}</h2>
          {description ? <p style={{ margin: 0, fontSize: 12, lineHeight: 1.5, color: "var(--muted)" }}>{description}</p> : null}
        </div>
        {actions ? <div style={{ display: "flex", alignItems: "center", gap: 8, flex: "0 0 auto" }}>{actions}</div> : null}
      </div>
      {notice}
      <div style={{ background: "var(--card)", border: `1px solid ${danger ? "color-mix(in srgb, var(--danger) 35%, var(--border) 65%)" : "color-mix(in srgb, var(--border) 85%, transparent)"}`, borderRadius: "var(--radius-lg)", overflow: "hidden", minWidth: 0 }}>
        {children}
      </div>
    </section>
  );
}
