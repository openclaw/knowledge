Settings section: typography heading (no card header) + one group surface holding rows. Sections separated by --space-8 in a 760px (or 1120px wide) column.

```jsx
<SettingsSection title="Notifications" description="Where run results are delivered">
  <SettingsToggleRow title="System notifications" description="…" checked />
  <SettingsRow title="Sound" control={<Select …/>} />
</SettingsSection>
```