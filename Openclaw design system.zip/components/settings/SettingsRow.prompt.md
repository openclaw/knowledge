Settings row: title over description on the left, ONE control on the right. Also exports SettingsToggleRow (label-wrapped switch row — whole row toggles).

```jsx
<SettingsRow first title="Model" description="Default for new sessions" control={<Select …/>} />
<SettingsRow title="Version" value="v2026.9.1" mono />
<SettingsRow nav title="Advanced" onClick={open} />
<SettingsToggleRow title="Compact mode" checked={on} onChange={setOn} />
```