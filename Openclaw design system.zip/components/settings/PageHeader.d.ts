export interface PageHeaderProps {
  title: string;
  subtitle?: React.ReactNode;
  /** Appends a "Learn more ↗" link after the subtitle. */
  learnMoreHref?: string;
  /** Centered HubTabs for hub pages (Plugins / Skills / Workshop). */
  tabs?: React.ReactNode;
  /** Trailing action cluster. */
  actions?: React.ReactNode;
}
export function PageHeader(props: PageHeaderProps): JSX.Element;
