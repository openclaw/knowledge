import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
import { Toggle } from "../core/Toggle.jsx";
/* Source: settings.css .settings-row (12/16 pad, min-h 48, gap 16, hairline 60% between rows), __title md/500 strong, __desc sm muted, __control max-w 60%, --nav hover bg-hover + chevron, __value muted sm, --stacked. */
export function SettingsRow({ title, description, control, value, mono, nav, onClick, stacked, first, indent }) {
  const [hover, setHover] = useState(false);
  const Tag = nav ? "button" : "div";
  return (
    <Tag type={nav ? "button" : undefined} onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ display: "flex", flexDirection: stacked ? "column" : "row", alignItems: stacked ? "stretch" : "center", justifyContent: "space-between", gap: stacked ? 8 : 16, padding: "12px 16px", paddingLeft: indent ? 32 : 16, minHeight: 48, width: "100%", border: 0, borderTop: first ? 0 : "1px solid color-mix(in srgb, var(--border) 60%, transparent)", background: nav && hover ? "var(--bg-hover)" : "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: nav ? "var(--cursor-action)" : "default", transition: "background var(--duration-fast) var(--ease-out)" }}>
      {(title || description) ? <div style={{ display: "flex", flexDirection: "column", minWidth: 0, flex: "1 1 0" }}>
        {title ? <div style={{ fontSize: 14, fontWeight: 500, color: "var(--text-strong)", lineHeight: 1.35, overflowWrap: "anywhere" }}>{title}</div> : null}
        {description ? <div style={{ fontSize: 12, color: "var(--muted)", lineHeight: 1.45, overflowWrap: "anywhere" }}>{description}</div> : null}
      </div> : null}
      <div style={{ display: "flex", alignItems: "center", justifyContent: stacked ? "flex-start" : "flex-end", gap: 8, flex: "0 0 auto", minWidth: 0, maxWidth: stacked ? "none" : "60%", marginLeft: !title && !description ? "auto" : undefined }}>
        {value != null ? <span style={{ fontSize: mono ? 11 : 12, fontFamily: mono ? "var(--mono)" : "inherit", color: "var(--muted)", textAlign: "right", overflowWrap: "anywhere" }}>{value}</span> : null}
        {control}
        {nav ? <span style={{ display: "flex", alignItems: "center", color: "var(--muted)", opacity: 0.5 }}><Icon name="chevronRight" size={14} strokeWidth={2} /></span> : null}
      </div>
    </Tag>
  );
}
export function SettingsToggleRow({ title, description, checked, onChange, disabled, first, indent }) {
  const [hover, setHover] = useState(false);
  return (
    <label onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, padding: "12px 16px", paddingLeft: indent ? 32 : 16, minHeight: 48, borderTop: first ? 0 : "1px solid color-mix(in srgb, var(--border) 60%, transparent)", cursor: disabled ? "not-allowed" : "var(--cursor-action)", userSelect: "none" }}>
      <div style={{ display: "flex", flexDirection: "column", minWidth: 0, flex: "1 1 0" }}>
        <div style={{ fontSize: 14, fontWeight: 500, color: "var(--text-strong)", lineHeight: 1.35 }}>{title}</div>
        {description ? <div style={{ fontSize: 12, color: "var(--muted)", lineHeight: 1.45 }}>{description}</div> : null}
      </div>
      <Toggle checked={checked} onChange={onChange} disabled={disabled} ariaLabel={title} />
    </label>
  );
}
