import React from "react";
import { Icon } from "../core/Icon.jsx";
/* Source: layout.css .content-header/.page-title (26px in settings takeover), hub-tabs.css .hub-page-header (3-col grid: title | tabs | actions), renderLearnMoreLink. */
export function PageHeader({ title, subtitle, learnMoreHref, tabs, actions }) {
  return (
    <section style={{ display: "grid", gridTemplateColumns: tabs ? "minmax(0,1fr) auto minmax(0,1fr)" : "minmax(0,1fr) auto", alignItems: "flex-end", gap: 16, padding: "4px 8px", width: "100%", maxWidth: 1120, marginInline: "auto" }}>
      <div style={{ minWidth: 0 }}>
        <h1 style={{ margin: 0, fontSize: 26, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15, color: "var(--text-strong)", fontFamily: "var(--font-display)" }}>{title}</h1>
        {subtitle ? <div style={{ marginTop: 4, fontSize: 13, color: "var(--muted)", display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>{subtitle}{learnMoreHref ? <a href={learnMoreHref} style={{ color: "var(--link)", display: "inline-flex", alignItems: "center", gap: 3, textDecoration: "none", fontSize: 12, fontWeight: 500 }}>Learn more <Icon name="externalLink" size={12} /></a> : null}</div> : null}
      </div>
      {tabs ? <div style={{ minWidth: 0, justifySelf: "center" }}>{tabs}</div> : null}
      <div style={{ minWidth: 0, justifySelf: "end", display: "flex", gap: 8, alignItems: "center" }}>{actions}</div>
    </section>
  );
}
