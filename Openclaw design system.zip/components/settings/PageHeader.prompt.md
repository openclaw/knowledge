Page header (.content-header): 26px title + muted subtitle; hub pages center a HubTabs strip and right-align actions.

```jsx
<PageHeader title="Plugins" subtitle="Extend what your assistant can do" learnMoreHref="#" tabs={<HubTabs …/>} actions={<IconButton variant="bordered" icon="download" label="Import" />} />
```