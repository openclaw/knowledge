export interface SettingsRowProps {
  title?: string;
  description?: string;
  /** Exactly one control on the right: Select, Segmented, Button, Toggle, Input. */
  control?: React.ReactNode;
  /** Plain right-aligned value text instead of a control ("Default", "v2026.7.1"). */
  value?: string;
  /** Render value in --mono 11px. */
  mono?: boolean;
  /** Drill-in row: whole row is a button with hover bg + trailing chevron. */
  nav?: boolean;
  onClick?: () => void;
  /** Title/description above a full-width control (textareas, wide inputs). */
  stacked?: boolean;
  /** Omit the top hairline (first row in a group). */
  first?: boolean;
  /** Indented sub-row (.settings-subrows, padding-left 32). */
  indent?: boolean;
}
export function SettingsRow(props: SettingsRowProps): JSX.Element;
