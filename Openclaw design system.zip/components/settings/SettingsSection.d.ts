/** @startingPoint section="Settings" subtitle="Eyebrow heading + single card group" viewport="700x260" */
export interface SettingsSectionProps {
  /** Uppercase eyebrow heading, outside the surface. */
  title: string;
  description?: string;
  /** Header actions (buttons) right of the heading. */
  actions?: React.ReactNode;
  /** Alert between heading and group. */
  notice?: React.ReactNode;
  /** SettingsRow children — the group is the ONLY surface. */
  children?: React.ReactNode;
  /** Red-tinted group border for destructive sections (page bottom). */
  danger?: boolean;
}
export function SettingsSection(props: SettingsSectionProps): JSX.Element;
