Passive notification (.app-toast). One at a time, fixed top-right (20px inset) in the app; this component renders the card only.

```jsx
<Toast icon="check" tone="ok" onDismiss={close}>Settings saved</Toast>
```