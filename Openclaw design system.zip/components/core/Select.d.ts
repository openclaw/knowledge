export interface SelectProps {
  value?: string;
  options: { value: string; label: string }[];
  onChange?: (value: string) => void;
  /** Required: row titles are not <label>s. */
  ariaLabel: string;
  disabled?: boolean;
  width?: number | string;
  style?: React.CSSProperties;
}
export function Select(props: SelectProps): JSX.Element;
