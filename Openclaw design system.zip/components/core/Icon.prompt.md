Lucide-style stroke icon from the Control UI's own icon set (160 names, see assets/icons/icons.json); use for every glyph — never hand-draw SVGs.

```jsx
<Icon name="search" size={16} strokeWidth={1.7} />
```

Common names: home, messageSquare, layoutDashboard, coins, clock, listChecks, server, activity, puzzle, layoutGrid, globe, users, settings, search, plus, panelLeftClose, penLine, chevronDown/Right/Left, chevronsUpDown, x, check, copy, send, mic, paperclip, moreHorizontal, trash, terminal, gitBranch, shieldCheck, badgeCheck, info, alertTriangle, archive, pin.