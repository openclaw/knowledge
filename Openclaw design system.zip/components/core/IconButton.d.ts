export interface IconButtonProps {
  icon: string;
  /** chrome = .sidebar-brand__icon 30px chromeless (default). bordered = .btn--icon 36px with 1px border + white 6% fill. rail = .rail-header__action 28px bare glyph. composer = 28px circular wash inside the chat composer. */
  variant?: "chrome" | "bordered" | "rail" | "composer";
  /** Override box size in px. */
  size?: number;
  iconSize?: number;
  strokeWidth?: number;
  /** Accessible name (also used as tooltip title). Required for a11y. */
  label: string;
  active?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export function IconButton(props: IconButtonProps): JSX.Element;
