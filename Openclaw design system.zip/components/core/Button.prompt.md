Control UI button (.btn). Quiet by default; `primary` is the single filled accent action per view; `danger` is a soft red tint used for archive/delete rows.

```jsx
<Button>Cancel</Button>
<Button variant="primary" icon="plus">New session</Button>
<Button variant="danger" size="sm" icon="trash">Delete selected</Button>
<Button variant="ghost" size="sm">View all</Button>
```

Sizes: md (default, 13px), sm (12px), xs. Disabled = opacity .5.