import React from "react";
import { Icon } from "./Icon.jsx";
/* Source: components.css .callout + .danger/.warn/.info/.success */
export function Callout({ children, tone = "neutral", icon, action, onDismiss, style }) {
  const t = tone === "success" ? "ok" : tone;
  const strong = tone === "danger" || tone === "warn";
  const s = tone === "neutral" ? { border: "1px solid var(--border)", background: "var(--secondary)", color: "var(--text)" }
    : strong ? { border: `1px solid color-mix(in srgb, var(--${t}) 34%, var(--border))`, background: `linear-gradient(135deg, color-mix(in srgb, var(--${t}) 14%, var(--bg-elevated)) 0%, color-mix(in srgb, var(--${t}) 8%, var(--bg-elevated)) 100%)`, color: `color-mix(in srgb, var(--${t}) 82%, var(--text-strong))` }
    : { border: `1px solid color-mix(in srgb, var(--${t}) 25%, transparent)`, background: `linear-gradient(135deg, color-mix(in srgb, var(--${t}) 8%, transparent) 0%, color-mix(in srgb, var(--${t}) 4%, transparent) 100%)`, color: `var(--${t})` };
  return (
    <div role={tone === "danger" ? "alert" : "status"} style={{ display: "flex", alignItems: "center", gap: 10, padding: "14px 16px", borderRadius: "var(--radius-md)", fontSize: 13, lineHeight: 1.5, position: "relative", ...s, ...style }}>
      {icon ? <Icon name={icon} size={16} strokeWidth={1.75} /> : null}
      <div style={{ minWidth: 0, flex: 1 }}>{children}</div>
      {action}
      {onDismiss ? <button type="button" aria-label="Dismiss" onClick={onDismiss} style={{ width: 28, height: 28, display: "inline-flex", alignItems: "center", justifyContent: "center", border: 0, background: "transparent", color: "inherit", opacity: 0.7, borderRadius: "var(--radius-sm)", cursor: "var(--cursor-action)" }}><Icon name="x" size={14} /></button> : null}
    </div>
  );
}
