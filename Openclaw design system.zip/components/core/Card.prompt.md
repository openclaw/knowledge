Surface tier 2. Exactly one level of elevation — never nest cards. `variant="group"` is the settings group that hosts SettingsRow children.

```jsx
<Card title="Gateway" sub="Local control plane">…</Card>
<Card variant="group"><SettingsRow …/><SettingsRow …/></Card>
```