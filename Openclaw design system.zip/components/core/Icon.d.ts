export interface IconProps {
  /** Icon name from ui/src/components/icons.ts, e.g. "home", "search", "plus", "send", "chevronDown". */
  name: string;
  /** Rendered box in px. Chrome uses 16; buttons 16–18; composer send 21. Default 16. */
  size?: number;
  /** Stroke width. Source uses 2 by default, 1.5 inside .btn/.nav-item. */
  strokeWidth?: number;
  style?: React.CSSProperties;
  className?: string;
}
export function Icon(props: IconProps): JSX.Element;
