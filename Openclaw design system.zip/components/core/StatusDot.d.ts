export interface StatusDotProps {
  /** ok, warn, danger, accent, info, or muted. */
  tone?: "ok" | "warn" | "danger" | "accent" | "info" | "muted";
  /** When set, renders the .settings-status "● Connected" pattern (7px dot + 12px text). Without label it is the bare 8px .statusDot. */
  label?: string;
  /** .statusDot glow (0 0 8px tone 50%). */
  glow?: boolean;
  size?: number;
}
export function StatusDot(props: StatusDotProps): JSX.Element;
