import React, { useState } from "react";
/* Source: components.css .card (18px pad, --card, radius-lg), .stat (14/16, radius-md), settings.css .settings-group (border 85%, overflow hidden). */
export function Card({ children, variant = "card", padding, style, title, sub, hoverable = true }) {
  const [hover, setHover] = useState(false);
  const group = variant === "group", stat = variant === "stat", elevated = variant === "elevated";
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ background: elevated ? "var(--bg-elevated)" : "var(--card)", border: `1px solid ${hoverable && hover && !group ? "var(--border-strong)" : group ? "color-mix(in srgb, var(--border) 85%, transparent)" : "var(--border)"}`, borderRadius: stat ? "var(--radius-md)" : "var(--radius-lg)", padding: padding != null ? padding : group ? 0 : stat ? "14px 16px" : 18, overflow: group ? "hidden" : undefined, minWidth: 0, boxShadow: hoverable && hover && !group ? "var(--shadow-sm)" : "none", transition: "border-color var(--duration-normal) var(--ease-out), box-shadow var(--duration-normal) var(--ease-out)", ...style }}>
      {title ? <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: "-0.02em", color: "var(--text-strong)" }}>{title}</div> : null}
      {sub ? <div style={{ color: "var(--muted)", fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>{sub}</div> : null}
      {children}
    </div>
  );
}
