Segmented control (.settings-segmented). Used for filters inside pages (Active / Archived / All) and enum settings.

```jsx
<Segmented ariaLabel="Session state" value="active" options={[{value:"active",label:"Active"},{value:"archived",label:"Archived"},{value:"all",label:"All"}]} />
```