Text input. Use `variant="settings"` inside settings groups (32px control height), `variant="search"` for table/list search with a leading magnifier.

```jsx
<Input variant="search" icon="search" placeholder="Search sessions…" />
<Input variant="settings" value="8080" mono ariaLabel="Port" width={110} />
```