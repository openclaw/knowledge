import React, { useState } from "react";
/* Source: settings-controls.css .settings-segmented (+ --accent, --primary, --compact). */
export function Segmented({ value, options = [], onChange, variant = "default", ariaLabel, disabled }) {
  const [hov, setHov] = useState(null);
  const accent = variant === "accent", primary = variant === "primary", compact = variant === "compact";
  const track = primary ? { background: "var(--bg-elevated)", border: "1px solid var(--border)", padding: 3, gap: 1, display: "flex" }
    : accent ? { background: "var(--bg-muted)", border: "1px solid var(--border)", padding: 3, gap: 2 }
    : { background: "color-mix(in srgb, var(--bg) 80%, var(--bg-elevated) 20%)", border: "1px solid color-mix(in srgb, var(--border) 50%, transparent)", padding: 2, gap: 2, minHeight: compact ? 24 : 32 };
  return (
    <div role="radiogroup" aria-label={ariaLabel} style={{ display: "inline-flex", alignItems: "stretch", flexWrap: "wrap", maxWidth: "100%", borderRadius: "var(--radius-md)", boxSizing: "border-box", opacity: disabled ? 0.5 : 1, ...track }}>
      {options.map((o) => {
        const on = o.value === value, h = hov === o.value;
        let s = { background: on ? "var(--bg-elevated)" : "transparent", color: on ? "var(--text-strong)" : h ? "var(--text)" : "var(--muted)", boxShadow: on ? "var(--shadow-sm)" : "none", fontWeight: 550, fontSize: compact ? 10 : 12, padding: compact ? "0 6px" : "0 12px", border: "1px solid transparent" };
        if (accent) s = { minHeight: 28, padding: "4px 12px", fontSize: 12, fontWeight: on ? 600 : 500, color: on ? "var(--accent)" : "var(--text)", background: on ? "var(--accent-subtle)" : h ? "var(--bg-hover)" : "transparent", border: `1px solid ${on ? "color-mix(in srgb, var(--accent) 30%, var(--border))" : "transparent"}`, boxShadow: on ? "0 1px 3px color-mix(in srgb, var(--accent) 20%, transparent)" : "none" };
        if (primary) s = { flex: 1, padding: "6px 12px", fontSize: 12, fontWeight: 600, whiteSpace: "normal", color: on ? "var(--primary-foreground)" : h ? "var(--text)" : "var(--muted)", background: on ? "var(--primary)" : h ? "var(--bg-hover)" : "transparent", boxShadow: on ? "0 1px 3px var(--accent-subtle)" : "none", border: 0 };
        return (
          <button key={o.value} type="button" role="radio" aria-checked={on} disabled={disabled} title={o.title} onClick={() => onChange && onChange(o.value)} onMouseEnter={() => setHov(o.value)} onMouseLeave={() => setHov(null)}
            style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: "calc(var(--radius-md) - 3px)", whiteSpace: "nowrap", cursor: "var(--cursor-action)", fontFamily: "var(--font-body)", transition: "color var(--duration-normal) var(--ease-out), background var(--duration-normal) var(--ease-out), box-shadow var(--duration-normal) var(--ease-out)", ...s }}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
