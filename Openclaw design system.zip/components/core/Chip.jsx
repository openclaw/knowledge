import React, { useState } from "react";
import { Icon } from "./Icon.jsx";
/* Source: components.css .chip/.chip-ok/.chip-warn/.pill/.pill.danger; plugins.css .plugin-catalog-chip; layout.css .control-ui-environment-pill; hub-tabs.css .hub-tab__badge */
export function Chip({ children, tone = "neutral", variant = "chip", icon, active, onClick, style }) {
  const [hover, setHover] = useState(false);
  let s;
  if (variant === "catalog") s = { minHeight: 32, gap: 7, padding: "5px 11px", borderRadius: "var(--radius-md)", border: `1px solid ${active || hover ? "var(--border-strong)" : "var(--border)"}`, background: active ? "var(--bg-elevated)" : hover ? "var(--bg-hover)" : "transparent", color: active || hover ? "var(--text-strong)" : "var(--muted)", fontSize: 12, fontWeight: 400 };
  else if (variant === "environment") s = { padding: "2px 6px", borderRadius: "var(--radius-full)", background: "color-mix(in srgb, var(--accent-2) 16%, transparent)", color: "#5eead4", fontSize: 11, fontWeight: 500, lineHeight: 1, border: 0 };
  else if (variant === "count") s = { minHeight: 16, padding: "0 5px", borderRadius: "var(--radius-full)", background: active ? "var(--accent-subtle)" : "var(--bg-hover)", color: active ? "var(--accent)" : "var(--muted)", fontSize: 10, fontWeight: 700, lineHeight: 1, border: 0 };
  else {
    const toneColor = tone === "neutral" ? null : `var(--${tone})`;
    s = { padding: variant === "pill" ? "5px 11px" : "5px 12px", borderRadius: "var(--radius-full)", fontSize: 12, fontWeight: 500, gap: 5,
      border: `1px solid ${toneColor ? `color-mix(in srgb, ${toneColor} 30%, transparent)` : hover ? "var(--border-strong)" : "var(--border)"}`,
      background: toneColor ? `var(--${tone}-subtle)` : "var(--secondary)", color: toneColor || (variant === "pill" ? "var(--text)" : "var(--muted)"),
      transform: variant === "chip" && hover && onClick ? "translateY(-1px)" : "none" };
  }
  const Tag = onClick ? "button" : "span";
  return (
    <Tag type={onClick ? "button" : undefined} onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ display: "inline-flex", alignItems: "center", whiteSpace: "nowrap", fontFamily: "var(--font-body)", cursor: onClick ? "var(--cursor-action)" : "default", transition: "border-color var(--duration-fast) var(--ease-out), background var(--duration-fast) var(--ease-out), transform var(--duration-fast) var(--ease-out)", ...s, ...style }}>
      {icon ? <Icon name={icon} size={15} strokeWidth={1.7} /> : null}
      {children}
    </Tag>
  );
}
