export interface CalloutProps {
  children: React.ReactNode;
  /** neutral = .callout; danger/warn = tinted gradient with strong text; info/success = lighter tint with tone text. */
  tone?: "neutral" | "danger" | "warn" | "info" | "success";
  icon?: string;
  /** Trailing action (a Button). */
  action?: React.ReactNode;
  onDismiss?: () => void;
  style?: React.CSSProperties;
}
export function Callout(props: CalloutProps): JSX.Element;
