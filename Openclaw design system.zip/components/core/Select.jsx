import React from "react";
/* Source: settings-controls.css select.settings-select — 32px, blended bg, chevron data-URI at right 10px. */
const CHEVRON = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23a1a1aa' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E\")";
export function Select({ value, options = [], onChange, ariaLabel, disabled, style, width }) {
  return (
    <select aria-label={ariaLabel} value={value} disabled={disabled} onChange={(e) => onChange && onChange(e.target.value)}
      style={{ height: 32, minWidth: width || "min(220px, 100%)", padding: "0 36px 0 10px", appearance: "none", WebkitAppearance: "none", border: "1px solid color-mix(in srgb, var(--border) 70%, transparent)", borderRadius: "var(--radius-md)", background: `${CHEVRON} no-repeat right 10px center, color-mix(in srgb, var(--bg) 80%, var(--bg-elevated) 20%)`, color: "var(--text)", fontSize: 12, fontFamily: "var(--font-body)", outline: "none", cursor: "var(--cursor-action)", opacity: disabled ? 0.5 : 1, ...style }}>
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}
