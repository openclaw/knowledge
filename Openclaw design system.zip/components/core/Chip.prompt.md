Compact rounded label. `chip`/`pill` are the full-radius tags; `catalog` is the radius-md filter chip on the plugin catalog; `count` the tiny hub-tab count badge. No status pills in settings — use SettingsStatus (dot + text) there.

```jsx
<Chip tone="ok">Connected</Chip>
<Chip variant="catalog" icon="zap" active>Featured</Chip>
<Chip variant="count" active>12</Chip>
```