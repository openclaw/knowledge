import React, { useState } from "react";
import { Icon } from "./Icon.jsx";
/* Source: .sidebar-brand__icon (30px, transparent, muted → bg-hover 84%), .btn--icon (36px, rgba white 6%), .rail-header__action (28px bare glyph), .topbar-icon-btn */
export function IconButton({ icon, variant = "chrome", size, label, active, disabled, onClick, style, iconSize, strokeWidth }) {
  const [hover, setHover] = useState(false);
  const box = size || (variant === "bordered" ? 36 : variant === "rail" ? 28 : 30);
  const glyph = iconSize || (variant === "bordered" ? 18 : 16);
  let s;
  if (variant === "bordered") s = { border: `1px solid ${hover ? "rgba(255,255,255,0.2)" : "var(--border)"}`, background: hover ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.06)", color: "var(--text)", borderRadius: "var(--radius-md)" };
  else if (variant === "rail") s = { border: 0, background: "transparent", color: active ? "var(--accent)" : hover ? "var(--text)" : "var(--muted)", borderRadius: "var(--radius-md)" };
  else if (variant === "composer") s = { border: 0, background: hover ? "color-mix(in srgb, var(--text-strong) 8%, transparent)" : "transparent", color: hover ? "var(--text-strong)" : "color-mix(in srgb, var(--text-strong) 65%, var(--popover))", borderRadius: "var(--radius-full)" };
  else s = { border: 0, background: hover ? "color-mix(in srgb, var(--bg-hover) 84%, transparent)" : "transparent", color: hover ? "var(--text)" : "var(--muted)", borderRadius: "var(--radius-md)" };
  return (
    <button type="button" aria-label={label} title={label} disabled={disabled} onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: box, height: box, padding: 0, flexShrink: 0, cursor: disabled ? "not-allowed" : "var(--cursor-action)", opacity: disabled ? 0.42 : 1, transition: "background var(--duration-fast) ease, color var(--duration-fast) ease", ...s, ...style }}>
      <Icon name={icon} size={glyph} strokeWidth={strokeWidth || (variant === "chrome" ? 1.7 : 1.5)} style={{ opacity: variant === "chrome" && !hover ? 0.72 : 1 }} />
    </button>
  );
}
