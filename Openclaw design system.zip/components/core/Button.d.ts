/** @startingPoint section="Core" subtitle="Quiet default, primary, danger, ghost" viewport="700x200" */
export interface ButtonProps {
  /** default = quiet .btn (bg-elevated + border). primary = filled --primary, white text (at most once per view). danger = soft red tint text. ghost = chromeless muted. destructive = solid --destructive fill. */
  variant?: "default" | "primary" | "danger" | "ghost" | "destructive";
  /** md 8/14 13px · sm 6/10 12px · xs 4/6 12px */
  size?: "md" | "sm" | "xs";
  /** Leading icon name (Icon component). */
  icon?: string;
  /** .btn.active — accent outline + accent-subtle fill. */
  active?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
  type?: "button" | "submit";
  title?: string;
  ariaLabel?: string;
}
export function Button(props: ButtonProps): JSX.Element;
