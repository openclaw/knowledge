export interface CardProps {
  children?: React.ReactNode;
  /** card = .card (18px pad). group = .settings-group (no pad, clips rows, the ONLY surface in settings). stat = .stat. elevated = --bg-elevated fill (.plugin-catalog-card). */
  variant?: "card" | "group" | "stat" | "elevated";
  padding?: number | string;
  /** .card-title 15/600 -0.02em */
  title?: string;
  /** .card-sub muted 13px */
  sub?: string;
  hoverable?: boolean;
  style?: React.CSSProperties;
}
export function Card(props: CardProps): JSX.Element;
