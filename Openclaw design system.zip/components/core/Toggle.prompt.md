Switch (wa-switch recolored to --accent). Prefer SettingsToggleRow so the whole row is clickable.

```jsx
<Toggle checked ariaLabel="Enable" onChange={setOn} />
```