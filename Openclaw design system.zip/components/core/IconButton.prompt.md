Square icon-only button. `chrome` (default) is the sidebar/brand header control; `bordered` is .btn--icon for page actions; `rail` is the 28px bare-glyph rail-header action; `composer` is the circular wash button inside the chat composer.

```jsx
<IconButton icon="panelLeftClose" label="Collapse sidebar" />
<IconButton icon="search" label="Search" />
<IconButton variant="bordered" icon="download" label="Export" />
```