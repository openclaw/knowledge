export interface SegmentedProps {
  value: string;
  options: { value: string; label: string; title?: string }[];
  onChange?: (value: string) => void;
  /** default = neutral track, active is --bg-elevated tile. accent = active gets accent tint + accent text. primary = filled --primary, equal-width. compact = 24px, 10px text. */
  variant?: "default" | "accent" | "primary" | "compact";
  ariaLabel: string;
  disabled?: boolean;
}
export function Segmented(props: SegmentedProps): JSX.Element;
