import React, { useState } from "react";
import { Icon } from "./Icon.jsx";
/* Source: ui/src/styles/components.css .btn / .btn.primary / .btn.danger / .btn.active / .btn--ghost / .btn--sm / .btn--xs */
export function Button({ variant = "default", size = "md", icon, children, disabled, active, onClick, style, type = "button", title, ariaLabel }) {
  const [hover, setHover] = useState(false);
  const [press, setPress] = useState(false);
  const pad = size === "xs" ? "4px 6px" : size === "sm" ? "6px 10px" : "8px 14px";
  const fs = size === "md" ? 13 : 12;
  let s = { border: "1px solid var(--border)", background: hover ? "var(--bg-hover)" : "var(--bg-elevated)", color: "inherit", boxShadow: "none" };
  if (hover) s.border = "1px solid var(--border-strong)";
  if (press && !hover) s.background = "var(--secondary)";
  if (variant === "primary") s = { border: `1px solid ${hover ? "var(--accent-hover)" : "var(--accent)"}`, background: hover ? "var(--primary-hover)" : "var(--primary)", color: "var(--primary-foreground)", boxShadow: hover ? "0 2px 12px var(--accent-glow)" : "0 1px 3px var(--accent-subtle)" };
  if (variant === "danger") s = { border: "1px solid transparent", background: hover ? "color-mix(in srgb, var(--danger) 15%, transparent)" : "var(--danger-subtle)", color: "var(--danger)" };
  if (variant === "ghost") s = { border: "1px solid transparent", background: hover ? "var(--bg-hover)" : "transparent", color: hover ? "var(--text)" : "var(--muted)" };
  if (variant === "destructive") s = { border: "1px solid transparent", background: hover ? "var(--destructive-hover)" : "var(--destructive)", color: "var(--destructive-foreground)" };
  if (active) s = { border: "1px solid var(--accent)", background: "var(--accent-subtle)", color: "var(--accent)" };
  return (
    <button type={type} title={title} aria-label={ariaLabel} disabled={disabled} onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => { setHover(false); setPress(false); }} onMouseDown={() => setPress(true)} onMouseUp={() => setPress(false)}
      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, padding: pad, borderRadius: "var(--radius-md)", fontSize: fs, fontWeight: 500, letterSpacing: "-0.01em", whiteSpace: "nowrap", lineHeight: size === "xs" ? 1 : "normal", fontFamily: "var(--font-body)", cursor: disabled ? "not-allowed" : "var(--cursor-action)", opacity: disabled ? 0.5 : 1, transition: "border-color var(--duration-fast) var(--ease-out), background var(--duration-fast) var(--ease-out), box-shadow var(--duration-fast) var(--ease-out)", ...s, ...style }}>
      {icon ? <Icon name={icon} size={16} strokeWidth={1.5} /> : null}
      {children}
    </button>
  );
}
