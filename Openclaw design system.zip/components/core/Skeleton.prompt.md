Loading placeholder bar (--bg-hover, 1.4s pulse). Reduced-motion users get a static bar.

```jsx
<Skeleton width={150} />
```