export interface ToastProps {
  children: React.ReactNode;
  icon?: string;
  tone?: "neutral" | "ok" | "warn" | "danger" | "info";
  action?: React.ReactNode;
  onDismiss?: () => void;
  style?: React.CSSProperties;
}
export function Toast(props: ToastProps): JSX.Element;
