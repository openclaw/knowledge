export interface InputProps {
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  onChange?: (value: string) => void;
  /** default = .input (38px, --card). settings = .settings-input (32px, blended bg, accent focus ring). search = .data-table-search input (34px, radius-sm). */
  variant?: "default" | "settings" | "search";
  type?: string;
  /** Leading icon inside the field (search magnifier). */
  icon?: string;
  disabled?: boolean;
  mono?: boolean;
  ariaLabel?: string;
  width?: number | string;
  style?: React.CSSProperties;
}
export function Input(props: InputProps): JSX.Element;
