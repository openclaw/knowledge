Status is a dot plus plain text, never a pill, on settings-language surfaces (renderSettingsStatus).

```jsx
<StatusDot tone="ok" label="Live" />
<StatusDot tone="danger" glow />
```