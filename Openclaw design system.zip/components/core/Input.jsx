import React, { useState } from "react";
import { Icon } from "./Icon.jsx";
/* Source: components.css .input/.field input (38px, --card bg, 1px --input border, radius-md, inset highlight) and settings-controls.css .settings-input (32px, bg 80/20 mix, border 70%). */
export function Input({ value, defaultValue, placeholder, onChange, variant = "default", type = "text", icon, disabled, mono, style, ariaLabel, width }) {
  const [focus, setFocus] = useState(false);
  const settings = variant === "settings";
  const search = variant === "search";
  const base = settings
    ? { height: 32, padding: "0 10px", border: `1px solid ${focus ? "color-mix(in srgb, var(--accent) 55%, var(--border) 45%)" : "color-mix(in srgb, var(--border) 70%, transparent)"}`, background: "color-mix(in srgb, var(--bg) 80%, var(--bg-elevated) 20%)", boxShadow: focus ? "0 0 0 2px color-mix(in srgb, var(--accent) 18%, transparent)" : "none", fontSize: 14 }
    : search
    ? { height: 34, padding: "6px 10px", border: `1px solid ${focus ? "var(--border-strong)" : "var(--border)"}`, background: "var(--card)", borderRadius: "var(--radius-sm)", fontSize: 13 }
    : { height: 38, padding: "8px 12px", border: `1px solid ${focus ? "var(--ring)" : "var(--input)"}`, background: "var(--card)", boxShadow: focus ? "var(--focus-ring)" : "inset 0 1px 0 var(--card-highlight)", fontSize: 14 };
  return (
    <span style={{ position: "relative", display: "inline-flex", width: width || "100%", minWidth: 0 }}>
      {icon ? <Icon name={icon} size={14} strokeWidth={1.8} style={{ position: "absolute", left: 9, top: "50%", transform: "translateY(-50%)", color: "var(--muted)", pointerEvents: "none" }} /> : null}
      <input type={type} value={value} defaultValue={defaultValue} placeholder={placeholder} disabled={disabled} aria-label={ariaLabel} onChange={(e) => onChange && onChange(e.target.value)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{ width: "100%", minWidth: 0, borderRadius: "var(--radius-md)", color: "var(--text)", outline: "none", fontFamily: mono ? "var(--mono)" : "var(--font-body)", transition: "border-color var(--duration-fast) ease, box-shadow var(--duration-fast) ease", opacity: disabled ? 0.55 : 1, ...base, paddingLeft: icon ? 30 : undefined, ...style }} />
    </span>
  );
}
