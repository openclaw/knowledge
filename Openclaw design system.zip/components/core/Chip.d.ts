export interface ChipProps {
  children: React.ReactNode;
  /** neutral (default) or a status: ok, warn, danger, info, accent. Tints border 30% + subtle bg + tone text (.chip-ok/.chip-warn). */
  tone?: "neutral" | "ok" | "warn" | "danger" | "info" | "accent" | "accent-2";
  /** chip = .chip (muted text). pill = .pill (text color, 5/11 padding). catalog = .plugin-catalog-chip (radius-md filter chip). environment = .control-ui-environment-pill. count = .hub-tab__badge count badge. */
  variant?: "chip" | "pill" | "catalog" | "environment" | "count";
  icon?: string;
  active?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export function Chip(props: ChipProps): JSX.Element;
