import React from "react";
/* Source: components.css .statusDot (8px, glow) and settings.css .settings-status (7px dot + text). */
export function StatusDot({ tone = "muted", label, glow, size }) {
  const d = size || (label ? 7 : 8);
  const color = tone === "muted" ? "var(--muted)" : `var(--${tone})`;
  const dot = <span aria-hidden="true" style={{ width: d, height: d, flexShrink: 0, borderRadius: "50%", background: color, opacity: tone === "muted" && !label ? 0.5 : 1, boxShadow: glow && tone !== "muted" ? `0 0 8px color-mix(in srgb, ${color} 50%, transparent)` : "none" }} />;
  if (!label) return dot;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, color: tone === "ok" ? "var(--text)" : "var(--muted)", whiteSpace: "nowrap", fontFamily: "var(--font-body)" }}>
      {dot}<span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{label}</span>
    </span>
  );
}
