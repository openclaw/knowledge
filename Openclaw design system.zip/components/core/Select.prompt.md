Native select styled as .settings-select (32px, baked chevron). Use in settings row control slots.

```jsx
<Select ariaLabel="Theme" value="dark" options={[{value:"dark",label:"Dark"},{value:"light",label:"Light"}]} />
```