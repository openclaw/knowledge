import React from "react";
/* Source: wa-switch with --wa-form-control-activated-color: var(--accent) (base.css); Web Awesome default geometry ≈ 36×20 track, 16px thumb. */
export function Toggle({ checked = false, onChange, disabled, ariaLabel, size = "md" }) {
  const w = size === "sm" ? 30 : 36, h = size === "sm" ? 16 : 20, t = h - 4;
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={ariaLabel} disabled={disabled} onClick={() => onChange && onChange(!checked)}
      style={{ position: "relative", width: w, height: h, flex: "none", padding: 0, border: `1px solid ${checked ? "var(--accent)" : "var(--border-strong)"}`, borderRadius: "var(--radius-full)", background: checked ? "var(--accent)" : "var(--bg-muted)", cursor: disabled ? "not-allowed" : "var(--cursor-action)", opacity: disabled ? 0.5 : 1, transition: "background var(--duration-fast) ease, border-color var(--duration-fast) ease" }}>
      <span style={{ position: "absolute", top: 1, left: checked ? w - t - 3 : 1, width: t, height: t, borderRadius: "50%", background: checked ? "#fff" : "var(--muted)", boxShadow: "0 1px 2px rgba(0,0,0,.3)", transition: "left var(--duration-fast) var(--ease-out), background var(--duration-fast) ease" }} />
    </button>
  );
}
