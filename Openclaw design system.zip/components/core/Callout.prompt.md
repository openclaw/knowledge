Inline notice banner (.callout). In settings pages a notice sits above the group, between heading and group.

```jsx
<Callout tone="warn" icon="alertTriangle" action={<Button size="sm">Retry</Button>}>Gateway unreachable — retrying…</Callout>
```