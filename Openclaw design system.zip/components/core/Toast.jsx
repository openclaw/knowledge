import React from "react";
import { Icon } from "./Icon.jsx";
/* Source: components.css .app-toast — popover bg, border-strong, radius-md, shadow-lg, padding 10 12 10 16. */
export function Toast({ children, icon, tone = "neutral", action, onDismiss, style }) {
  const iconColor = tone === "neutral" ? "var(--muted)" : `var(--${tone})`;
  return (
    <div role="status" style={{ display: "flex", alignItems: "center", gap: 12, maxWidth: 520, padding: "10px 12px 10px 16px", border: "1px solid var(--border-strong)", borderRadius: "var(--radius-md)", background: "var(--popover)", color: "var(--popover-foreground)", boxShadow: "var(--shadow-lg)", fontSize: 13, lineHeight: 1.45, ...style }}>
      {icon ? <Icon name={icon} size={16} strokeWidth={1.75} style={{ color: iconColor }} /> : null}
      <div style={{ flex: 1, minWidth: 0 }}>{children}</div>
      {action}
      {onDismiss ? <button type="button" aria-label="Dismiss" onClick={onDismiss} style={{ width: 28, height: 28, display: "inline-flex", alignItems: "center", justifyContent: "center", border: 0, background: "transparent", color: "var(--muted)", borderRadius: "var(--radius-sm)", cursor: "var(--cursor-action)" }}><Icon name="x" size={14} /></button> : null}
    </div>
  );
}
