export interface ToggleProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
  /** Required unless wrapped by SettingsToggleRow. */
  ariaLabel?: string;
  size?: "md" | "sm";
}
export function Toggle(props: ToggleProps): JSX.Element;
