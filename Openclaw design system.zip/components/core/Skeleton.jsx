import React from "react";
/* Source: sessions.css .session-skeleton (12px bar, --bg-hover, radius-full, pulse 1.4s). */
export function Skeleton({ width = "72%", height = 12, radius = "var(--radius-full)", style }) {
  return <span aria-hidden="true" style={{ display: "block", width, height, background: "var(--bg-hover)", borderRadius: radius, animation: "oc-skeleton-pulse 1.4s ease-in-out infinite", ...style }}>
    <style>{"@keyframes oc-skeleton-pulse{0%,100%{opacity:1}50%{opacity:.45}}"}</style>
  </span>;
}
