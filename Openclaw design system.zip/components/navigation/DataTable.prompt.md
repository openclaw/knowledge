Dense data table (.data-table) with sticky uppercase headers, hover rows, optional checkbox column and pagination footer. Also exports PaginationButton.

```jsx
<DataTable selectable columns={[{key:"name",label:"Key",sortable:true},{key:"kind",label:"Kind"}]} rows={rows} pagination={<><span>1–10 of 42</span><div style={{display:"flex",gap:8}}><PaginationButton disabled>Previous</PaginationButton><PaginationButton>Next</PaginationButton></div></>} />
```