import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
/* Source: components.css .data-table (13px; th sticky 10/12 pad, 12px 600 uppercase .04em muted on --bg-elevated; td 10/12, 1px --border; row hover bg-hover), .data-table-pagination, .data-table-bulk-bar. */
export function DataTable({ columns = [], rows = [], selectable, selected = new Set(), onToggle, onToggleAll, sort, onSort, pagination, bulkBar, emptyMessage, renderRow }) {
  const [hov, setHov] = useState(null);
  const allSelected = rows.length > 0 && rows.every((r) => selected.has(r.key));
  return (
    <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
      {bulkBar}
      <div style={{ overflow: "auto", maxHeight: "min(70vh, 860px)" }}>
        <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: 0, fontSize: 13 }}>
          <thead>
            <tr>
              {selectable ? <th style={{ ...TH, width: 36, minWidth: 36, paddingLeft: 12, paddingRight: 4, textAlign: "center" }}><input type="checkbox" checked={allSelected} onChange={onToggleAll} aria-label="Select all on page" style={{ width: 16, height: 16, margin: 0, accentColor: "var(--accent)", verticalAlign: "middle" }} /></th> : null}
              {columns.map((c) => {
                const active = sort && sort.column === c.key;
                return (
                  <th key={c.key} style={{ ...TH, width: c.width, cursor: c.sortable ? "var(--cursor-action)" : "default" }} onClick={c.sortable && onSort ? () => onSort(c.key) : undefined}>
                    {c.label}
                    {c.sortable ? <span style={{ display: "inline-flex", verticalAlign: "middle", marginLeft: 4, opacity: active ? 1 : 0.4, color: active ? "var(--text)" : "inherit", transform: active && sort.dir === "desc" ? "rotate(180deg)" : "none" }}><Icon name="arrowUp" size={14} strokeWidth={1.5} /></span> : null}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? <tr><td colSpan={columns.length + (selectable ? 1 : 0)} style={{ padding: "46px 16px", color: "var(--muted)", textAlign: "center" }}>{emptyMessage || "Nothing here"}</td></tr> : null}
            {rows.map((r, i) => {
              const last = i === rows.length - 1;
              const h = hov === r.key;
              const bg = h || r.expanded ? "var(--bg-hover)" : "transparent";
              return (
                <tr key={r.key} onMouseEnter={() => setHov(r.key)} onMouseLeave={() => setHov(null)} style={{ background: bg, opacity: r.archived ? (h ? 0.82 : 0.62) : 1, transition: "background var(--duration-fast) ease", cursor: r.onClick ? "var(--cursor-action)" : "default" }} onClick={r.onClick}>
                  {selectable ? <td style={{ ...TD(last), width: 36, paddingLeft: 12, paddingRight: 4, textAlign: "center" }}><input type="checkbox" checked={selected.has(r.key)} onChange={() => onToggle && onToggle(r.key)} onClick={(e) => e.stopPropagation()} style={{ width: 16, height: 16, margin: 0, accentColor: "var(--accent)", verticalAlign: "middle" }} /></td> : null}
                  {renderRow ? renderRow(r, TD(last)) : columns.map((c) => <td key={c.key} style={{ ...TD(last), whiteSpace: c.nowrap ? "nowrap" : undefined }}>{r[c.key]}</td>)}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {pagination ? <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, padding: "10px 12px", borderTop: "1px solid var(--border)", background: "var(--bg-elevated)", fontSize: 13, color: "var(--muted)" }}>{pagination}</div> : null}
    </div>
  );
}
const TH = { position: "sticky", top: 0, zIndex: 3, padding: "10px 12px", textAlign: "left", fontWeight: 600, fontSize: 12, color: "var(--muted)", background: "var(--bg-elevated)", borderBottom: "1px solid var(--border)", whiteSpace: "nowrap", userSelect: "none", textTransform: "uppercase", letterSpacing: "0.04em" };
const TD = (last) => ({ padding: "10px 12px", borderBottom: last ? "none" : "1px solid var(--border)", color: "var(--text)", verticalAlign: "middle" });
export function PaginationButton({ children, disabled, onClick }) {
  const [h, setH] = useState(false);
  return <button type="button" disabled={disabled} onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ padding: "4px 12px", fontSize: 13, border: `1px solid ${h && !disabled ? "var(--border-strong)" : "var(--border)"}`, borderRadius: "var(--radius-sm)", background: h && !disabled ? "var(--bg-hover)" : "var(--card)", color: "var(--text)", opacity: disabled ? 0.4 : 1, cursor: disabled ? "not-allowed" : "var(--cursor-action)", fontFamily: "var(--font-body)" }}>{children}</button>;
}
