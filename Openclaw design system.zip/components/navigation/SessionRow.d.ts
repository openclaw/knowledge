export interface SessionRowProps {
  title: string;
  /** Optional meta line (11px muted) e.g. "Running · 2m". */
  subtitle?: string;
  /** Session glyph icon name (messageSquare, users, clock, globe, bot). */
  icon?: string;
  /** Current route session: neutral --text 10% fill. */
  active?: boolean;
  /** Multi-select: accent 14% wash. */
  selected?: boolean;
  unread?: boolean;
  /** Running ring around the glyph. */
  running?: boolean;
  /** Session color stripe: red blue green yellow purple orange pink cyan. */
  color?: string;
  onClick?: () => void;
  showActions?: boolean;
}
export function SessionRow(props: SessionRowProps): JSX.Element;
