export interface HubTabsProps {
  tabs: { value: string; label: string; count?: number }[];
  value: string;
  onChange?: (value: string) => void;
  /** .hub-tabs--sub: 11px, tighter. */
  sub?: boolean;
}
export function HubTabs(props: HubTabsProps): JSX.Element;
