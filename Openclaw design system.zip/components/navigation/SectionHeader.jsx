import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
/* Source: layout.css .sidebar-session-toolbar (min-h 24), .sidebar-recent-sessions__label-text, .sidebar-session-group-toggle (chevron lead), .sidebar-session-toolbar__button 22px muted .55 opacity. */
export function SectionHeader({ label, collapsed, onToggle, actions }) {
  const [hover, setHover] = useState(false);
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ display: "flex", alignItems: "center", gap: 2, minHeight: 24, padding: "0 2px 0 4px" }}>
      <button type="button" onClick={onToggle} aria-expanded={!collapsed} style={{ display: "inline-flex", alignItems: "center", gap: 6, flex: "1 1 auto", minWidth: 0, height: 22, padding: "0 4px", border: 0, background: "transparent", color: "var(--muted)", fontSize: 11, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase", cursor: "var(--cursor-action)", borderRadius: "var(--radius-sm)", fontFamily: "var(--font-body)" }}>
        <Icon name={collapsed ? "chevronRight" : "chevronDown"} size={12} strokeWidth={1.7} style={{ opacity: 0.7 }} />
        <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
      </button>
      <span style={{ display: "inline-flex", gap: 2, opacity: hover ? 1 : 0.55, transition: "opacity var(--duration-fast) ease" }}>{actions}</span>
    </div>
  );
}
