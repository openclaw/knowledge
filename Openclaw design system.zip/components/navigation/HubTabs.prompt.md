Route-level hub tabs (Plugins · Skills · Workshop / Sessions · Worktrees): quiet text on a hairline track, accent indicator. Not for in-page filters — use Segmented for those.

```jsx
<HubTabs value="plugins" tabs={[{value:"plugins",label:"Plugins",count:12},{value:"skills",label:"Skills"},{value:"skill-workshop",label:"Workshop"}]} />
```