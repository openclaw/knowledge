export interface DataTableProps {
  columns: { key: string; label: string; width?: number | string; sortable?: boolean; nowrap?: boolean }[];
  /** Each row needs a unique key; other fields map to column keys unless renderRow is given. */
  rows: Array<{ key: string; archived?: boolean; expanded?: boolean; onClick?: () => void; [k: string]: any }>;
  selectable?: boolean;
  selected?: Set<string>;
  onToggle?: (key: string) => void;
  onToggleAll?: () => void;
  sort?: { column: string; dir: "asc" | "desc" };
  onSort?: (column: string) => void;
  /** Footer content (info left, controls right) — rendered inside the pagination bar. */
  pagination?: React.ReactNode;
  /** Rendered above the table (bulk-select bar). */
  bulkBar?: React.ReactNode;
  emptyMessage?: string;
  /** Custom cell renderer: (row, tdStyle) => <td>…</td>[] */
  renderRow?: (row: any, tdStyle: React.CSSProperties) => React.ReactNode;
}
export function DataTable(props: DataTableProps): JSX.Element;
