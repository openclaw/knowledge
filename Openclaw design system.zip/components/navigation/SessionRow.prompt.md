Sidebar session thread row. Selection is a filled neutral pill (not an accent border). Kebab appears on hover.

```jsx
<SessionRow title="Refactor gateway auth" active running />
<SessionRow title="Weekly digest" icon="clock" color="green" unread />
```