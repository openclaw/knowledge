export interface NavItemProps {
  icon: string;
  label: string;
  active?: boolean;
  /** Unread count pill. */
  badge?: number | string;
  trailing?: React.ReactNode;
  onClick?: () => void;
  href?: string;
}
export function NavItem(props: NavItemProps): JSX.Element;
