import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
/* Source: layout.css .nav-item (min-h 32, pad 0 8, radius-md, 1px transparent border, muted; icon 20×16 slot, opacity .72; text 13/500). hover: bg-hover 84% + border 72%. active: accent-subtle 88% + bg-elevated 12%, border accent 16%, icon accent, text strong. */
export function NavItem({ icon, label, active, badge, trailing, onClick, href }) {
  const [hover, setHover] = useState(false);
  const Tag = href ? "a" : "button";
  return (
    <Tag href={href} type={href ? undefined : "button"} onClick={onClick} aria-current={active ? "page" : undefined} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "flex-start", gap: 8, minHeight: 32, width: "100%", padding: "0 8px", borderRadius: "var(--radius-md)", border: `1px solid ${active ? "color-mix(in srgb, var(--accent) 16%, transparent)" : hover ? "color-mix(in srgb, var(--border) 72%, transparent)" : "transparent"}`, background: active ? "color-mix(in srgb, var(--accent-subtle) 88%, var(--bg-elevated) 12%)" : hover ? "color-mix(in srgb, var(--bg-hover) 84%, transparent)" : "transparent", color: active ? "var(--text-strong)" : hover ? "var(--text)" : "var(--muted)", textDecoration: "none", font: "inherit", textAlign: "left", cursor: "var(--cursor-action)", userSelect: "none", transition: "border-color var(--duration-fast) ease, background var(--duration-fast) ease, color var(--duration-fast) ease" }}>
      <span style={{ width: 20, height: 16, display: "flex", alignItems: "center", justifyContent: "center", flex: "0 0 20px", opacity: active || hover ? 1 : 0.72, color: active ? "var(--accent)" : "inherit", transition: "opacity var(--duration-fast) ease" }}><Icon name={icon} size={16} strokeWidth={1.5} /></span>
      <span style={{ fontSize: 13, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", flex: "1 1 auto", minWidth: 0 }}>{label}</span>
      {badge != null ? <span style={{ minWidth: 16, height: 16, padding: "0 5px", borderRadius: "var(--radius-full)", background: "var(--accent)", color: "#fff", fontSize: 10, fontWeight: 700, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>{badge}</span> : null}
      {trailing}
    </Tag>
  );
}
