Sidebar shelf header (Pages / Recent / Pinned / Online): uppercase 11px label with a chevron, quiet toolbar buttons reveal on hover.

```jsx
<SectionHeader label="Recent" actions={<IconButton icon="listFilter" label="Sort" size={22} iconSize={12} />} />
```