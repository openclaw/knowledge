export interface RailHeaderProps {
  eyebrow?: string;
  title: string;
  /** IconButton variant="rail" cluster. */
  actions?: React.ReactNode;
  leading?: React.ReactNode;
  divider?: boolean;
}
export function RailHeader(props: RailHeaderProps): JSX.Element;
