import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
import { IconButton } from "../core/IconButton.jsx";
/* Source: layout.css .sidebar-recent-session (min-h 30, radius-md, muted; hover bg-hover 78%; active text 10% fill + strong; selected accent 14%), __link (gap 8, pad 4 2 4 8), --colored::before 3px stripe; components.css .session-glyph (16px icon), __badge--unread. */
export function SessionRow({ title, subtitle, icon = "messageSquare", active, selected, unread, running, color, onClick, showActions }) {
  const [hover, setHover] = useState(false);
  const bg = selected ? "color-mix(in srgb, var(--accent) 14%, transparent)" : active ? "color-mix(in srgb, var(--text) 10%, transparent)" : hover ? "color-mix(in srgb, var(--bg-hover) 78%, transparent)" : "transparent";
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} onClick={onClick}
      style={{ position: "relative", display: "flex", alignItems: "center", minWidth: 0, minHeight: 30, paddingRight: 2, borderRadius: "var(--radius-md)", background: bg, color: active || selected ? "var(--text-strong)" : hover ? "var(--text)" : "var(--muted)", cursor: "var(--cursor-action)", transition: "background var(--duration-fast) ease, color var(--duration-fast) ease" }}>
      {color ? <span aria-hidden="true" style={{ position: "absolute", top: 5, bottom: 5, left: 2, width: 3, borderRadius: "var(--radius-full)", background: `var(--session-color-${color})` }} /> : null}
      <a style={{ display: "flex", alignItems: "center", gap: 8, flex: "1 1 auto", minWidth: 0, minHeight: 30, padding: "4px 2px 4px 8px", color: "inherit", textDecoration: "none" }}>
        <span style={{ position: "relative", width: 16, height: 16, display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "0 0 16px", opacity: hover || active ? 1 : 0.72 }}>
          <Icon name={icon} size={16} strokeWidth={1.5} />
          {running ? <span style={{ position: "absolute", inset: -3, borderRadius: "50%", border: "1.5px solid var(--ok)", opacity: 0.8 }} /> : null}
          {unread && !running ? <span style={{ position: "absolute", top: -2, right: -3, width: 7, height: 7, borderRadius: "50%", background: "var(--accent)", border: "1.5px solid var(--sidebar-bg)" }} /> : null}
        </span>
        <span style={{ display: "flex", flexDirection: "column", minWidth: 0, flex: 1 }}>
          <span style={{ fontSize: 13, lineHeight: "18px", fontWeight: active ? 500 : 400, color: active ? "var(--text-strong)" : "var(--text)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</span>
          {subtitle ? <span style={{ fontSize: 11, lineHeight: "14px", color: "var(--muted)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{subtitle}</span> : null}
        </span>
      </a>
      {(showActions || hover) ? <IconButton icon="moreHorizontal" label="Session actions" size={24} iconSize={14} style={{ marginRight: 2, opacity: hover ? 1 : 0 }} /> : null}
    </div>
  );
}
