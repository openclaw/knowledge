import React from "react";
/* Source: rail-header.css .rail-header (48px, pad 0 8 0 12, 1px divider, --bg), __eyebrow (xs uppercase .04em muted), __title (sm 600 text). */
export function RailHeader({ eyebrow, title, actions, leading, divider = true }) {
  return (
    <div style={{ display: "flex", height: 48, minHeight: 48, flex: "0 0 auto", alignItems: "center", justifyContent: "space-between", gap: 8, padding: "0 8px 0 12px", borderBottom: divider ? "1px solid var(--border)" : 0, background: "var(--bg)", userSelect: "none" }}>
      {leading}
      <div style={{ display: "flex", minWidth: 0, flex: "1 1 auto", flexDirection: "column", justifyContent: "center", gap: 2 }}>
        {eyebrow ? <span style={{ overflow: "hidden", color: "var(--muted)", fontSize: 11, letterSpacing: "0.04em", lineHeight: 1, textOverflow: "ellipsis", textTransform: "uppercase", whiteSpace: "nowrap" }}>{eyebrow}</span> : null}
        <span style={{ overflow: "hidden", color: "var(--text)", fontSize: 12, fontWeight: 600, lineHeight: 1.2, textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{title}</span>
      </div>
      <div style={{ display: "flex", flex: "0 0 auto", alignItems: "center", gap: 2 }}>{actions}</div>
    </div>
  );
}
