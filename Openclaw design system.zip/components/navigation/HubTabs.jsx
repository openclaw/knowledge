import React, { useState } from "react";
/* Source: hub-tabs.css — quiet text tabs (sm 550 muted; active text-strong; accent indicator) on hairline track (border 60%); badge .hub-tab__badge. */
export function HubTabs({ tabs = [], value, onChange, sub }) {
  const [hov, setHov] = useState(null);
  return (
    <div role="tablist" style={{ display: "flex", gap: sub ? 4 : 8, borderBottom: "1px solid color-mix(in srgb, var(--border) 60%, transparent)" }}>
      {tabs.map((t) => {
        const on = t.value === value;
        return (
          <button key={t.value} role="tab" type="button" aria-selected={on} onClick={() => onChange && onChange(t.value)} onMouseEnter={() => setHov(t.value)} onMouseLeave={() => setHov(null)}
            style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: 6, padding: sub ? "3px 8px 4px" : "4px 8px 8px", border: 0, background: "transparent", color: on ? "var(--text-strong)" : hov === t.value ? "var(--text)" : "var(--muted)", fontSize: sub ? 11 : 12, fontWeight: 550, fontFamily: "var(--font-body)", cursor: "var(--cursor-action)", transition: "color var(--duration-normal) var(--ease-out)" }}>
            {t.label}
            {t.count != null ? <span style={{ display: "inline-flex", alignItems: "center", minHeight: 16, padding: "0 5px", borderRadius: "var(--radius-full)", background: on ? "var(--accent-subtle)" : "var(--bg-hover)", color: on ? "var(--accent)" : "var(--muted)", fontSize: 10, fontWeight: 700, lineHeight: 1 }}>{t.count}</span> : null}
            {on ? <span aria-hidden="true" style={{ position: "absolute", left: 0, right: 0, bottom: -1, height: 2, background: "var(--accent)", borderRadius: 1 }} /> : null}
          </button>
        );
      })}
    </div>
  );
}
