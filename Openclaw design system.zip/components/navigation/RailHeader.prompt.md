48px pane/rail header: optional eyebrow + 12px/600 title, bare-glyph actions right. Used for chat pane header and side panels.

```jsx
<RailHeader eyebrow="Main" title="Refactor gateway auth" actions={<IconButton variant="rail" icon="search" label="Search" />} />
```