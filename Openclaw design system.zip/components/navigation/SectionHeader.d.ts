export interface SectionHeaderProps {
  label: string;
  collapsed?: boolean;
  onToggle?: () => void;
  /** 22px toolbar buttons (IconButton size 22, iconSize 12). */
  actions?: React.ReactNode;
}
export function SectionHeader(props: SectionHeaderProps): JSX.Element;
