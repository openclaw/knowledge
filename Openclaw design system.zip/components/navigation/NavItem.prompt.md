Sidebar page link (.nav-item). Active state is an accent wash with accent icon; hover is a neutral wash with a faint border.

```jsx
<NavItem icon="home" label="Home" active />
<NavItem icon="layoutDashboard" label="Dashboards" />
```