// Preview-only fallback: when _ds_bundle.js is absent, fetch the component sources,
// transpile with Babel standalone, and expose them as window.OpenClawUI.
(function () {
  var FILES = [
    "core/Icon.jsx","core/Button.jsx","core/IconButton.jsx","core/Input.jsx","core/Select.jsx","core/Toggle.jsx","core/Segmented.jsx","core/Chip.jsx","core/StatusDot.jsx","core/Card.jsx","core/Callout.jsx","core/Skeleton.jsx","core/Toast.jsx",
    "settings/SettingsSection.jsx","settings/SettingsRow.jsx","settings/PageHeader.jsx",
    "navigation/NavItem.jsx","navigation/SessionRow.jsx","navigation/SectionHeader.jsx","navigation/RailHeader.jsx","navigation/HubTabs.jsx","navigation/DataTable.jsx",
    "chat/Composer.jsx","chat/Message.jsx","chat/ToolRow.jsx","chat/ChatDivider.jsx","chat/PluginCard.jsx"
  ];
  function findBundleNs() {
    for (var k in window) { try { var v = window[k]; if (v && typeof v === "object" && v !== window && typeof v.Button === "function" && typeof v.Icon === "function") return v; } catch (e) {} }
    return null;
  }
  // Prefer the compiled bundle when the design-system compiler has produced it (root _ds_bundle.js).
  function tryBundle(base) {
    return new Promise(function (resolve) {
      var s = document.createElement("script"); s.src = base + "../_ds_bundle.js";
      s.onload = function () { resolve(findBundleNs()); }; s.onerror = function () { s.remove(); resolve(null); };
      document.head.appendChild(s);
    });
  }
  window.loadOpenClawUI = function (base) {
    var existing = findBundleNs();
    if (existing) return Promise.resolve(existing);
    return tryBundle(base).then(function (ns) { return ns || compileSources(base); });
  };
  function compileSources(base) {
    var mods = {};
    var ns = {};
    function req(from, spec) {
      if (spec === "react") return window.React;
      var path = new URL(spec, "http://x/" + from).pathname.slice(1);
      if (!mods[path]) throw new Error("module not loaded: " + path + " from " + from);
      return mods[path];
    }
    return Promise.all(FILES.map(function (f) { return fetch(base + f).then(function (r) { return r.text(); }); })).then(function (srcs) {
      srcs.forEach(function (src, i) {
        var file = FILES[i];
        var out = Babel.transform(src, { presets: [["react", { runtime: "classic" }], ["env", { modules: "commonjs" }]], filename: file }).code;
        var module = { exports: {} };
        new Function("require", "module", "exports", "React", out)(function (s) { return req(file, s); }, module, module.exports, window.React);
        mods[file] = module.exports;
        Object.assign(ns, module.exports);
      });
      window.OpenClawUI = ns;
      return ns;
    });
  }
})();
