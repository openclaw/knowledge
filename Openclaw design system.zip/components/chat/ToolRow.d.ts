export interface ToolRowProps {
  /** Glyph: terminal, fileText, fileDiff, globe, search, wrench, brain. */
  icon?: string;
  /** "Ran", "Read", "Edited", "Searched" … shimmers while running. */
  verb?: string;
  /** Mono target (path or command). */
  target?: string;
  detail?: string;
  status?: "running" | "done" | "error";
  /** Expanded body (terminal output / diff), mono block. */
  children?: React.ReactNode;
  defaultOpen?: boolean;
  /** [added, removed] line counts. */
  diffstat?: [number, number];
}
export function ToolRow(props: ToolRowProps): JSX.Element;
