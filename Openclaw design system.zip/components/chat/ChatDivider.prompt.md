Hairline divider with centered muted label — timestamps, compaction boundaries, "history loaded".

```jsx
<ChatDivider label="Today" />
<ChatDivider icon="foldVertical" label="Context compacted" metric="38k → 12k" />
```