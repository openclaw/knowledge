Plugin catalog tile (.plugin-catalog-card) laid out in a 4-column grid on the Plugins hub. Art tile 40px, title 14/600, optional official badge, @author, two-line summary, sm Install button.

```jsx
<PluginCard name="GitHub" author="openclaw" official summary="Pull requests, issues and reviews from chat." action="Install" />
<PluginCard name="Memory" state="enabled" installed summary="Long-term memory across sessions." />
```