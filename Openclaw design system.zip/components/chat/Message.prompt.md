Chat turn. User messages are right-aligned cards; assistant replies render as a flat text stream (no bubble), max 68% / 900px wide for user, full width for assistant.

```jsx
<Message role="user" time="09:41">Summarise the gateway logs.</Message>
<Message role="assistant">Three reconnects, no errors.</Message>
```