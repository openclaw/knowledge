export interface ChatDividerProps {
  label: string;
  icon?: string;
  /** Mono metric e.g. "38k → 12k tokens". */
  metric?: string;
}
export function ChatDivider(props: ChatDividerProps): JSX.Element;
