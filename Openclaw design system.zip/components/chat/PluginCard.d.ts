/** @startingPoint section="Plugins" subtitle="Catalog tile: art, title, badge, author, 2-line summary" viewport="700x140" */
export interface PluginCardProps {
  name: string;
  /** ClawHub handle; rendered as @handle. */
  author?: string;
  summary: string;
  /** Blue badgeCheck after the title. */
  official?: boolean;
  /** Installed state dot: enabled ok, disabled muted, needs-setup warn, error danger. */
  state?: "enabled" | "disabled" | "needs-setup" | "error";
  /** Fallback glyph when no art. */
  icon?: string;
  /** Image URL for the 40px art tile. */
  art?: string;
  /** Trailing sm button label; null hides it. */
  action?: string | null;
  onAction?: () => void;
  installed?: boolean;
}
export function PluginCard(props: PluginCardProps): JSX.Element;
