/** @startingPoint section="Chat" subtitle="Two-region composer with model/effort chips and send" viewport="700x180" */
export interface ComposerProps {
  value?: string;
  placeholder?: string;
  onChange?: (value: string) => void;
  onSend?: (value: string) => void;
  /** Model chip label. */
  model?: string;
  /** Reasoning-effort chip label. */
  effort?: string;
  /** Swap send for the soft-danger Stop square. */
  running?: boolean;
  disabled?: boolean;
  /** Resting surface floor (112 in main chat; lower for side panels). */
  minHeight?: number;
  maxWidth?: number | string;
}
export function Composer(props: ComposerProps): JSX.Element;
