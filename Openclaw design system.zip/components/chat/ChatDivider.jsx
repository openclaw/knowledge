import React from "react";
import { Icon } from "../core/Icon.jsx";
/* Source: grouped.css .chat-divider (rule + centered label), .chat-group-timestamp. */
export function ChatDivider({ label, icon, metric }) {
  return (
    <div role="separator" style={{ display: "flex", alignItems: "center", gap: 10, margin: "8px 0 20px", color: "var(--muted)", fontSize: 11 }}>
      <span style={{ flex: 1, height: 1, background: "color-mix(in srgb, var(--border) 80%, transparent)" }} />
      <span style={{ display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap" }}>{icon ? <Icon name={icon} size={12} strokeWidth={1.75} /> : null}{label}{metric ? <span style={{ fontFamily: "var(--mono)", color: "var(--muted-strong)" }}>{metric}</span> : null}</span>
      <span style={{ flex: 1, height: 1, background: "color-mix(in srgb, var(--border) 80%, transparent)" }} />
    </div>
  );
}
