import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
/* Source: chat/tool-cards.css .chat-tool-msg-summary (inline-flex gap 7, pad 3 0), __chevron 14px muted .55 rotates 90°, .chat-tool-row__verb/__target/__cmd, .chat-tool-term (mono block), .chat-diffstat. */
export function ToolRow({ icon = "terminal", verb = "Ran", target, detail, status = "done", children, defaultOpen = false, diffstat }) {
  const [open, setOpen] = useState(defaultOpen);
  const [hover, setHover] = useState(false);
  const running = status === "running";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4, fontSize: 13, lineHeight: 1.45, color: "var(--text)", fontFamily: "var(--font-body)" }}>
      <button type="button" aria-expanded={open} onClick={() => setOpen(!open)} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ display: "inline-flex", alignItems: "center", gap: 7, width: "fit-content", maxWidth: "100%", padding: "3px 0", border: 0, background: "transparent", color: "inherit", font: "inherit", textAlign: "left", cursor: "var(--cursor-action)" }}>
        <span style={{ display: "inline-flex", width: 14, height: 14, marginInlineStart: -3, alignItems: "center", justifyContent: "center", color: "var(--muted)", opacity: hover || open ? 1 : 0.55, transform: open ? "rotate(90deg)" : "none", transition: "opacity 150ms ease-out, transform 150ms ease-out" }}><Icon name="chevronRight" size={14} /></span>
        <span style={{ display: "inline-flex", width: 16, height: 16, alignItems: "center", justifyContent: "center", color: status === "error" ? "var(--danger)" : "var(--muted)" }}><Icon name={icon} size={14} strokeWidth={1.75} /></span>
        <span style={{ display: "inline-flex", alignItems: "baseline", gap: 6, minWidth: 0, overflow: "hidden", whiteSpace: "nowrap" }}>
          <span style={running ? { fontWeight: 500, background: "linear-gradient(90deg, var(--muted) 0%, var(--text-strong) 50%, var(--muted) 100%)", backgroundSize: "200% 100%", WebkitBackgroundClip: "text", color: "transparent", animation: "oc-text-shimmer 2.2s linear infinite" } : { color: "var(--muted)", fontWeight: 500 }}>{verb}</span>
          {target ? <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis" }}>{target}</span> : null}
          {detail ? <span style={{ color: "var(--muted)", fontSize: 12 }}>{detail}</span> : null}
          {diffstat ? <span style={{ fontFamily: "var(--mono)", fontSize: 11 }}><span style={{ color: "var(--ok)" }}>+{diffstat[0]}</span> <span style={{ color: "var(--danger)" }}>−{diffstat[1]}</span></span> : null}
        </span>
        {running ? <style>{"@keyframes oc-text-shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}"}</style> : null}
      </button>
      {open && children ? <div style={{ marginLeft: 21, padding: "8px 10px", borderRadius: "var(--radius-md)", background: "color-mix(in srgb, var(--bg) 72%, transparent)", border: "1px solid var(--border)", fontFamily: "var(--mono)", fontSize: 12, lineHeight: 1.5, color: "var(--text)", whiteSpace: "pre-wrap", overflowWrap: "anywhere", maxHeight: 240, overflow: "auto" }}>{children}</div> : null}
    </div>
  );
}
