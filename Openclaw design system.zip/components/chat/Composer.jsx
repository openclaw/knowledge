import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
import { IconButton } from "../core/IconButton.jsx";
/* Source: chat/composer-surface.css .agent-chat__input — --popover surface, 1px hairline (text-strong 9%), radius 20px, shadow 0 4px 16px 5%, min-h 112, editor inset 6/14 at 16px/1.5; footer: 28px controls, 32px circular send (--primary), chips 30px radius-full 14px text. */
export function Composer({ value, placeholder = "Message OpenClaw…", onChange, onSend, model = "Claude Opus 4", effort = "Medium", running, disabled, minHeight = 112, maxWidth }) {
  const [focus, setFocus] = useState(false);
  const [text, setText] = useState(value || "");
  const v = value != null ? value : text;
  const canSend = v.trim().length > 0 && !disabled;
  return (
    <div style={{ position: "relative", zIndex: 1, display: "flex", flexDirection: "column", minWidth: 0, minHeight, width: "100%", maxWidth, background: "var(--popover)", border: `1px solid ${focus ? "color-mix(in srgb, var(--text-strong) 16%, transparent)" : "color-mix(in srgb, var(--text-strong) 9%, transparent)"}`, borderRadius: 20, boxShadow: "0 4px 16px rgb(0 0 0 / 5%)", flexShrink: 0, transition: "border-color var(--duration-fast) ease, box-shadow var(--duration-fast) ease" }}>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 4, minWidth: 0, padding: "6px 14px 0" }}>
        <textarea rows={1} value={v} placeholder={placeholder} disabled={disabled} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} onChange={(e) => { setText(e.target.value); onChange && onChange(e.target.value); }} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && canSend) { e.preventDefault(); onSend && onSend(v); } }}
          style={{ flex: 1, minWidth: 0, minHeight: 24, maxHeight: 200, padding: "6px 0", border: 0, outline: "none", background: "transparent", resize: "none", color: "var(--text-strong)", fontFamily: "var(--font-chat)", fontSize: 16, lineHeight: 1.5 }} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,auto) minmax(0,1fr)", alignItems: "center", columnGap: 5, minHeight: 28, marginTop: "auto", marginBottom: 4, padding: "6px 8px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 4, minWidth: 0 }}>
          <IconButton variant="composer" icon="plus" label="Add" iconSize={22} strokeWidth={1.5} />
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 4, minWidth: 0, overflow: "hidden" }}>
          <ComposerChip label={model} icon="brain" />
          <ComposerChip label={effort} />
          <div style={{ display: "flex", alignItems: "center", gap: 8, flex: "0 0 auto", marginLeft: 4 }}>
            <IconButton variant="composer" icon="mic" label="Dictate" />
            <SendButton running={running} disabled={!canSend && !running} onClick={() => running ? null : onSend && onSend(v)} />
          </div>
        </div>
      </div>
    </div>
  );
}
export function ComposerChip({ label, icon, onClick }) {
  const [h, setH] = useState(false);
  return (
    <button type="button" onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{ display: "flex", alignItems: "center", gap: 6, height: 30, minHeight: 30, padding: "0 8px", border: 0, borderRadius: "var(--radius-full)", background: h ? "color-mix(in srgb, var(--text) 7%, transparent)" : "transparent", color: h ? "var(--text-strong)" : "var(--text)", fontSize: 14, lineHeight: 1.35, fontFamily: "var(--font-body)", cursor: "var(--cursor-action)", userSelect: "none", maxWidth: 220, minWidth: 0, flex: "0 1 auto" }}>
      {icon ? <Icon name={icon} size={16} strokeWidth={1.5} style={{ color: "var(--muted)" }} /> : null}
      <span style={{ minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{label}</span>
      <Icon name="chevronDown" size={12} strokeWidth={2} style={{ color: "var(--muted)" }} />
    </button>
  );
}
export function SendButton({ running, disabled, onClick }) {
  const [h, setH] = useState(false);
  const stop = running;
  return (
    <button type="button" aria-label={stop ? "Stop" : "Send"} disabled={disabled} onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 32, height: 32, padding: 5, border: 0, borderRadius: "var(--radius-full)", flexShrink: 0, cursor: disabled ? "not-allowed" : "var(--cursor-action)", transition: "background var(--duration-fast) ease, color var(--duration-fast) ease",
        background: stop ? "color-mix(in srgb, var(--danger) 14%, transparent)" : disabled ? "color-mix(in srgb, var(--text-strong) 8%, transparent)" : h ? "color-mix(in srgb, var(--primary) 86%, var(--text-strong))" : "var(--primary)",
        color: stop ? "var(--danger)" : disabled ? "color-mix(in srgb, var(--text-strong) 48%, var(--popover))" : "var(--primary-foreground)" }}>
      {stop ? <span style={{ width: 10, height: 10, borderRadius: 2, background: "currentColor" }} /> : <Icon name="arrowUp" size={21} strokeWidth={2} />}
    </button>
  );
}
