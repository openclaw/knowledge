Collapsible inline tool activity row in an assistant turn: chevron · icon · verb (shimmers while running) · mono target. Expands to a mono output block.

```jsx
<ToolRow icon="terminal" verb="Ran" target="pnpm test" detail="12s">…output…</ToolRow>
<ToolRow icon="fileDiff" verb="Edited" target="src/gateway.ts" diffstat={[14,3]} />
<ToolRow verb="Searching" target="docs/" status="running" />
```