export interface MessageProps {
  /** user = right-aligned --card bubble (16px pad). assistant = flat text stream, no bubble. */
  role?: "user" | "assistant";
  children: React.ReactNode;
  /** Show the 36px circle avatar (group threads only; 1:1 threads hide it). */
  showAvatar?: boolean;
  avatar?: string;
  name?: string;
  time?: string;
  /** Footer actions (copy, reply) — small ghost IconButtons. */
  actions?: React.ReactNode;
}
export function Message(props: MessageProps): JSX.Element;
