import React from "react";
/* Source: chat/startup-layout.css .chat-group (gap 10, turn gap 28, user row-reverse, messages max 68%/900), .chat-bubble (--card, radius-md, pad 16; assistant: transparent, pad 4 0), .chat-avatar (36px circle, panel-strong, 1px border, 13/600); grouped.css .chat-group-footer meta. */
export function Message({ role = "assistant", children, avatar, name, time, showAvatar = false, actions }) {
  const user = role === "user";
  return (
    <div style={{ display: "flex", flexDirection: user ? "row-reverse" : "row", gap: 10, alignItems: "flex-start", paddingBottom: 28, marginInline: showAvatar ? "4px 16px" : 0, justifyContent: "flex-start" }}>
      {showAvatar ? <span style={{ width: 36, height: 36, borderRadius: "var(--radius-full)", background: "var(--panel-strong)", display: "grid", placeItems: "center", fontWeight: 600, fontSize: 13, flexShrink: 0, alignSelf: "flex-end", marginBottom: 4, border: "1px solid var(--border)", color: "var(--text)" }}>{avatar || (name || (user ? "Y" : "O"))[0]}</span> : null}
      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 2, flex: "1 1 auto", alignItems: user ? "flex-end" : "flex-start", width: "100%", maxWidth: user ? "min(900px, 68%)" : "min(980px, 100%)", minWidth: 0 }}>
        <div style={{ position: "relative", display: "block", border: "1px solid transparent", background: user ? "var(--card)" : "transparent", borderRadius: "var(--radius-md)", padding: user ? 16 : "4px 0", width: "auto", maxWidth: "100%", minWidth: 0, overflowWrap: "break-word", fontFamily: "var(--font-chat)", fontSize: 14, lineHeight: 1.5, color: "var(--chat-text)" }}>
          {children}
        </div>
        {(time || name || actions) ? <div style={{ display: "flex", alignItems: "center", gap: 8, minHeight: 20, padding: "2px 4px", fontSize: 11, color: "var(--muted)", flexDirection: user ? "row-reverse" : "row" }}>
          {name ? <span style={{ fontWeight: 500 }}>{name}</span> : null}{time ? <span>{time}</span> : null}{actions}
        </div> : null}
      </div>
    </div>
  );
}
