Chat composer (.agent-chat__input): editor on top, docked control row at the bottom; 20px radius on --popover with a 9% hairline. Send is the only brand-filled control. Also exports ComposerChip and SendButton.

```jsx
<Composer model="Claude Opus 4" effort="Medium" onSend={send} />
<Composer running />
```