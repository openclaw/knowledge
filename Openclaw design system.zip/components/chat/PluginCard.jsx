import React, { useState } from "react";
import { Icon } from "../core/Icon.jsx";
import { Button } from "../core/Button.jsx";
import { StatusDot } from "../core/StatusDot.jsx";
/* Source: plugins.css .plugin-catalog-card (grid, gap 8, pad 12, 1px border, radius-lg, --bg-elevated; hover border-strong + shadow-sm + translateY(-1px)), .installed-plugins-card__art 40px radius 10 --bg, __identity h3 md/600, .plugin-official-badge (info, 15px badgeCheck), .plugin-card-author xs muted, __summary sm muted 2-line clamp. */
export function PluginCard({ name, author, summary, official, state, icon = "puzzle", art, action = "Install", onAction, installed }) {
  const [hover, setHover] = useState(false);
  const tone = state === "enabled" ? "ok" : state === "disabled" ? "muted" : state === "needs-setup" ? "warn" : state === "error" ? "danger" : null;
  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ position: "relative", minWidth: 0, display: "grid", gridTemplateRows: "auto auto", alignContent: "start", gap: 8, padding: 12, border: `1px solid ${hover ? "var(--border-strong)" : "var(--border)"}`, borderRadius: "var(--radius-lg)", background: "var(--bg-elevated)", boxShadow: hover ? "var(--shadow-sm)" : "none", transform: hover ? "translateY(-1px)" : "none", transition: "border-color var(--duration-fast) ease, box-shadow var(--duration-fast) ease, transform var(--duration-fast) ease", fontFamily: "var(--font-body)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, minWidth: 0 }}>
        <div style={{ display: "grid", gridTemplateColumns: "auto minmax(0,1fr)", alignItems: "center", gap: 12, minWidth: 0 }}>
          <span style={{ width: 40, height: 40, display: "grid", placeItems: "center", overflow: "hidden", border: "1px solid var(--border)", borderRadius: 10, background: "var(--bg)", color: "var(--muted)" }}>{art ? <img src={art} alt="" style={{ width: "100%", height: "100%", objectFit: "contain", padding: 7 }} /> : <Icon name={icon} size={18} strokeWidth={1.5} />}</span>
          <div style={{ minWidth: 0, display: "grid", alignContent: "center" }}>
            <div style={{ display: "flex", minWidth: 0, alignItems: "center", gap: 6 }}>
              <h3 style={{ margin: 0, minWidth: 0, color: "var(--text-strong)", fontSize: 14, fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</h3>
              {official ? <span title="Official" style={{ display: "inline-flex", width: 16, height: 16, flex: "0 0 16px", alignItems: "center", justifyContent: "center", color: "var(--info)" }}><Icon name="badgeCheck" size={15} /></span> : null}
              {tone ? <span style={{ marginInlineStart: "auto" }}><StatusDot tone={tone} size={7} /></span> : null}
            </div>
            {author ? <span style={{ overflow: "hidden", color: "var(--muted)", fontSize: 11, lineHeight: 1.3, textOverflow: "ellipsis", whiteSpace: "nowrap" }}>@{author.replace(/^@+/, "")}</span> : null}
          </div>
        </div>
        {action ? <Button size="sm" onClick={onAction} style={{ position: "relative", zIndex: 3 }}>{installed ? "Installed" : action}</Button> : null}
      </div>
      <p style={{ display: "-webkit-box", minHeight: "calc(2 * 1.4em)", margin: 0, color: "var(--muted)", fontSize: 12, lineHeight: 1.4, WebkitBoxOrient: "vertical", WebkitLineClamp: 2, overflow: "hidden" }}>{summary}</p>
    </div>
  );
}
